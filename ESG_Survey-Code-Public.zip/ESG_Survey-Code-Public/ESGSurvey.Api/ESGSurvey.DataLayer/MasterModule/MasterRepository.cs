﻿using Dapper;
using ESGSurvey.BusinessLayer.DTO.Common;
using ESGSurvey.BusinessLayer.DTO.MasterModule;
using ESGSurvey.BusinessLayer.Extensions;
using ESGSurvey.BusinessLayer.Interfaces.MasterModule;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace ESGSurvey.DataLayer.MasterModule
{
    public class MasterRepository : IMasterRepository
    {
        private readonly IConfiguration _config;
        public MasterRepository(IConfiguration config)
        {
            _config = config;
        }
        /// <summary>
        /// GetAllOrganizationSector
        /// </summary>
        /// <returns></returns>
        public async Task<GroupedOptionsResponseDto> GetAllOrganizationSector()
        {
            GroupedOptionsResponseDto organizationSectorResponseDto = new GroupedOptionsResponseDto();
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            List<SubGroupDropdownDto> lstDropdownData = new List<SubGroupDropdownDto>();
            using (var multi = await db.QueryMultipleAsync("sp_esg_OrganizationSectorSelect", commandType: CommandType.StoredProcedure))
            {
                var sectors = await multi.ReadAsync<SubGroupDropdownDbDto>();
                var subSectors = await multi.ReadAsync<SubGroupDropdownDbDto>();
                foreach (var item in sectors)
                {
                    lstDropdownData.Add(new SubGroupDropdownDto()
                    {
                        Label = item.Label,
                        Options = subSectors.Where(x => x.OrganizationGroupSectorId == item.Value).Select(x => new CommonDropdownDto() { Label = x.Label, Value = x.Value }).ToList()
                    });
                }
            }
            organizationSectorResponseDto.LstDropdownData = lstDropdownData;
            return organizationSectorResponseDto;

        }

        /// <summary>
        /// GetAllCompanyTurnover
        /// </summary>
        /// <returns></returns>
        public async Task<CommonDropdownResponseDto> GetAllCompanyTurnover()
        {
            CommonDropdownResponseDto companyTurnoverResponseDto = new CommonDropdownResponseDto();
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var lstDropDownData=await  db.QueryAsync<CommonDropdownDto>("sp_esg_CompanyTurnoverSelect", commandType: CommandType.StoredProcedure);
            lstDropDownData ??= new List<CommonDropdownDto>();
            companyTurnoverResponseDto.LstDropdownData = lstDropDownData.ToList();
            return companyTurnoverResponseDto;

        }
        /// <summary>
        /// GetAllQuestion
        /// </summary>
        /// <returns></returns>
        public async Task<AllQuestionResponseDto> GetAllQuestion()
        {
            var result = new AllQuestionResponseDto();
            var pillars = new List<PillarDto>();
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            using (var multiResultSet = await db.QueryMultipleAsync("sp_esg_SurveyQuestionsSelect", commandType: CommandType.StoredProcedure))
            {
                var pillarDetail = await multiResultSet.ReadAsync<PillarDto>();
                var questionDetail = await multiResultSet.ReadAsync<QuestionsDto>();
                var questionsTypeDetail = await multiResultSet.ReadAsync<QuestionsTypeDto>();
                var predefinedAnswersDetail = await multiResultSet.ReadAsync<PredefinedAnswersDto>();
               
                if (pillarDetail != null && questionDetail != null)
                {
                    pillars = pillarDetail.ToList();
                    pillars.ForEach(y => { y.Questions = questionDetail.Where(x=>x.PillarId == y.PillarId).Select(
                    x => new QuestionsDto
                    {
                        PillarId = x.PillarId,
                        PillarName = x.PillarName,
                        QuestionsId = x.QuestionsId,
                        QuestionsName = x.QuestionsName,
                        Guideline = x.Guideline,
                        DisplayOrder = x.DisplayOrder,
                        QuestionsTypeId = x.QuestionsTypeId,
                        QuestionsTypeName = x.QuestionsTypeName,
                        PredefinedAnswers = BuildPredefinedAnswerHierarchy(predefinedAnswersDetail, x.QuestionsTypeId)
                    }).ToList();
                    });
                }
                result.Pillers = pillars;
                return result;
            }


        }

        private List<PredefinedAnswersDto> BuildPredefinedAnswerHierarchy(IEnumerable<PredefinedAnswersDto> predefinedAnswersDetail, byte questionsTypeId)
        {
            return predefinedAnswersDetail.Where(x => x.QuestionsTypeId == questionsTypeId).ToList();

        }
        /// <summary>
        /// GetAllOrganizationUnGroupSector
        /// </summary>
        /// <returns></returns>
        public async Task<CommonDropdownResponseDto> GetAllOrganizationUnGroupSector()
        {
            CommonDropdownResponseDto organizationSectorResponseDto = new CommonDropdownResponseDto();
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var lstDropDownData = await db.QueryAsync<CommonDropdownDto>("sp_esg_OrganizationUnGroupSectorSelect", commandType: CommandType.StoredProcedure);
            lstDropDownData ??= new List<CommonDropdownDto>();
            organizationSectorResponseDto.LstDropdownData = lstDropDownData.ToList();
            return organizationSectorResponseDto;

        }
    }
}
