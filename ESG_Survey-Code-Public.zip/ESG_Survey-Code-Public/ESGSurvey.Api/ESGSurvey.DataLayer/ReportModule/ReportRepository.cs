﻿using Dapper;
using ESGSurvey.BusinessLayer.DTO.Common;
using ESGSurvey.BusinessLayer.DTO.MasterModule;
using ESGSurvey.BusinessLayer.DTO.ReportModule;
using ESGSurvey.BusinessLayer.Extensions;
using ESGSurvey.BusinessLayer.Interfaces.ReportModule;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Reflection.Metadata;
using System.Security.Cryptography;

namespace ESGSurvey.DataLayer.MasterModule
{
    public class ReportRepository : IReportRepository
    {
        private readonly IConfiguration _config;
        public ReportRepository(IConfiguration config)
        {
            _config = config;
        }
        /// <summary>
        /// GetEsgSustainabilityReport
        /// </summary>
        /// <param name="ReportGuid"></param>
        /// <returns></returns>
        public async Task<EsgSustainabilityReportResponseDto> GetEsgSustainabilityReport(Guid ReportGuid)
        {
            var result = new EsgSustainabilityReportResponseDto();
            var pillars = new List<PillarNameDto>();
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new 
            { 
                ReportGuid 
            };
            using (var multiResultSet = await db.QueryMultipleAsync("sp_esg_RecommendationReportSelect", parameters, commandType: CommandType.StoredProcedure))
            {
                var scoreData = await multiResultSet.ReadFirstOrDefaultAsync<EsgSustainabilityReportResponseDto>();
                if (scoreData != null)
                {
                    result.Score = scoreData.Score;
                    result.MaturityLevel = scoreData.MaturityLevel;
                }
                var tokenList = await multiResultSet.ReadAsync<TokenDto>();
                result.TokenList = tokenList.ToList();
                var pillarList = await multiResultSet.ReadAsync<PillarNameDto>();
                pillars = pillarList.ToList();
                var recommendationList = await multiResultSet.ReadAsync<RecommendationDto>();
                var productList = await multiResultSet.ReadAsync<ProductDto>();
                var pillarScoreList = await multiResultSet.ReadAsync<PillarScoreDto>();
                if (pillars != null && recommendationList != null && productList != null)
                {
                    pillars.ForEach(pillar =>
                    {
                        pillar.RecommendationList = recommendationList
                            .Where(r => r.PillarId == pillar.PillarId)
                            .Select(r => new RecommendationDto
                            {
                                PillarId = r.PillarId,
                                PillarName = r.PillarName,
                                Recommendation = r.Recommendation
                            }).ToList();

                        pillar.ProductList = productList
                            .Where(p => p.PillarId == pillar.PillarId)
                            .Select(p => new ProductDto
                            {
                                PillarId = p.PillarId,
                                ProductName = p.ProductName,
                                ProductURL = p.ProductURL,
                                ProductDescription = p.ProductDescription
                            }).ToList();
                    });
                }
                result.PillarScoreList = pillarScoreList != null ? pillarScoreList.ToList() : new List<PillarScoreDto>();
                result.PillarList = pillars;

                return result;
            }
        }
        /// <summary>
        /// GetEsgReportSummary
        /// </summary>
        /// <param name="ReportGuid"></param>
        /// <returns></returns>
        public async Task<ReportSummaryDto> GetEsgReportSummary(Guid ReportGuid)
        {
            var result = new ReportSummaryDto();
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new
            {
                ReportGuid
            };
            using (var multiResultSet = await db.QueryMultipleAsync("sp_esg_ReportSummarySelect", parameters, commandType: CommandType.StoredProcedure))
            {
                result = await multiResultSet.ReadFirstAsync<ReportSummaryDto>();
                var pillarReportList = await multiResultSet.ReadAsync<PillarReportSummaryDto>();
                result.PillarReportList = pillarReportList.ToList();

            }
            return result;
        }

    }
}