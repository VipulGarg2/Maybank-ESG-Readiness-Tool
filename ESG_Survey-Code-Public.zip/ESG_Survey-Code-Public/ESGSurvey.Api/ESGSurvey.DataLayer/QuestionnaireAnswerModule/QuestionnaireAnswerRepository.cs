﻿using Dapper;
using ESGSurvey.BusinessLayer.DTO.Common;
using ESGSurvey.BusinessLayer.DTO.MasterModule;
using ESGSurvey.BusinessLayer.DTO.UserModule;
using ESGSurvey.BusinessLayer.Extensions;
using ESGSurvey.BusinessLayer.Interfaces.QuestionnaireAnswerModule;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Data;

namespace ESGSurvey.DataLayer.QuestionnaireAnswerModule
{
    public class QuestionnaireAnswerRepository : IQuestionnaireAnswerRepository
    {
        private readonly IConfiguration _config;
        public QuestionnaireAnswerRepository(IConfiguration config)
        {
            _config = config;
        }
        /// <summary>
        /// SaveQuestionnaireAnswer
        /// </summary>
        /// <param name="allQuestionRequest"></param>
        /// <returns></returns>
        public async Task<Guid> SaveQuestionnaireAnswer(AllQuestionResponseDto allQuestionRequest, Guid parsedGuid)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            DataTable surveyAnswerDT = new();
            surveyAnswerDT.Columns.Add("QuestionsId", typeof(byte));
            surveyAnswerDT.Columns.Add("QuestionsTypeId", typeof(byte));
            surveyAnswerDT.Columns.Add("PredefinedAnswersId", typeof(byte));

            allQuestionRequest.Pillers?.ForEach(pillerDetail =>
            {
                pillerDetail.Questions?.ForEach(questionDetail =>
                {
                    questionDetail.PredefinedAnswers?.ForEach(predefinedAnswerDetail =>
                    {
                        if(predefinedAnswerDetail != null && predefinedAnswerDetail.IsSelected == true)
                        {
                            var row = surveyAnswerDT.NewRow();
                            row["QuestionsId"] = questionDetail.QuestionsId;
                            row["QuestionsTypeId"] = questionDetail.QuestionsTypeId;
                            row["PredefinedAnswersId"] = predefinedAnswerDetail.PredefinedAnswersId;
                            surveyAnswerDT.Rows.Add(row);
                        }
                    });
                });
            });
            var parameters = new
            {
                allQuestionRequest.BusinessEntityName,
                allQuestionRequest.BusinessUEN,
                allQuestionRequest.CompanyTurnoverId,
                allQuestionRequest.OrganizationSectorId,
                allQuestionRequest.NameOfPrimaryContact,
                allQuestionRequest.RoleOfPrimaryContact,
                allQuestionRequest.CorporateEmailAddressPrimaryContact,
                allQuestionRequest.PhoneNumberPrimaryContact,
                allQuestionRequest.IsExistingMaybankCustomer,
                allQuestionRequest.IsExploringGreenSolution,
                allQuestionRequest.ScaleOfTransitionToGreenerSolutions,
                allQuestionRequest.IsConsentTermsAccepted,
                RequestKey = parsedGuid,
                SurveyAnswerType = surveyAnswerDT.AsTableValuedParameter("[dbo].[type_esg_SurveyAnswerType]")
            };
             return await db.ExecuteScalarAsync<Guid>("sp_esg_QuestionnaireAnswerInsert", parameters, commandType: CommandType.StoredProcedure);

        }

        /// <summary>
        /// GetEndUserInfo
        /// </summary>
        /// <param name="guid"></param>
        /// <returns></returns>
        public async Task<UserInfoDto> GetEndUserInfo(Guid guid)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@ReportGuid", guid);
            return await db.QueryFirstOrDefaultAsync<UserInfoDto>("sp_esg_EndUserInfoSelect", parameters, commandType: CommandType.StoredProcedure);

        }
        /// <summary>
        /// VerifyRequestId
        /// </summary>
        /// <param name="requestId"></param>
        /// <returns></returns>
        public async Task<int> VerifyRequestId(Guid parsedGuid)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@RequestId", parsedGuid);
            return await db.QueryFirstOrDefaultAsync<int>("sp_esg_RequestIdVerify", parameters, commandType: CommandType.StoredProcedure);
        }
    }
}
