using ESGSurvey.Api.Extensions;
using ESGSurvey.Api.Helper.Implementations;
using ESGSurvey.Api.Helper.Interfaces;
using ESGSurvey.BusinessLayer.Interfaces.MasterModule;
using ESGSurvey.BusinessLayer.Interfaces.QuestionnaireAnswerModule;
using ESGSurvey.BusinessLayer.Interfaces.ReportModule;
using ESGSurvey.DataLayer.MasterModule;
using ESGSurvey.DataLayer.QuestionnaireAnswerModule;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Serilog;
using System.Text;
var builder = WebApplication.CreateBuilder(args);
var logger = new LoggerConfiguration()
    .ReadFrom.Configuration(builder.Configuration)
    .Enrich.FromLogContext()
    .CreateLogger();

logger.Debug("init main");
try
{
    builder.Logging.ClearProviders();
    builder.Logging.SetMinimumLevel(LogLevel.Warning);
    builder.Host.UseSerilog(logger);
   
    
    builder.Services.AddCors(options =>
    {
        options.AddPolicy("AllowAll", corsBuilder => corsBuilder
          .AllowAnyOrigin()
          .AllowAnyMethod()
          .AllowAnyHeader()
          .SetPreflightMaxAge(TimeSpan.FromDays(7))
          );
    });

    builder.Services.AddAuthentication(options =>
    {
        options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    })
           .AddJwtBearer(options =>
           {
               options.RequireHttpsMetadata = false;
               options.SaveToken = true;
               options.TokenValidationParameters = new TokenValidationParameters
               {
                   ValidateLifetime = true,
                   ValidateIssuerSigningKey = true,
                   ValidateIssuer = false,
                   ValidateAudience = false,
                   ClockSkew = TimeSpan.FromSeconds(0)
               };
               options.Events = new JwtBearerEvents
               {
                   OnAuthenticationFailed = context =>
                   {
                       var logger = context.HttpContext.RequestServices.GetRequiredService<ILogger<Program>>();
                       logger.LogError("Authentication failed. Exception: {Exception}", context.Exception);
                       return Task.CompletedTask;
                   },
               };
           });
    builder.Services.AddControllersWithViews().AddSessionStateTempDataProvider();
    builder.Services.AddSession();
    builder.Services.AddHttpContextAccessor();
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen(options =>
    {
        options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
        {
            In = ParameterLocation.Header,
            Description = "Please enter a valid token",
            Name = "Authorization",
            Type = SecuritySchemeType.Http,
            BearerFormat = "JWT",
            Scheme = "Bearer"
        });
        options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type=ReferenceType.SecurityScheme,
                    Id="Bearer"
                }
            },
            new string[]{}
        }
    });
    });

    builder.Services.AddScoped<IEmailSender, EmailSender>();
    builder.Services.AddScoped<IMasterRepository, MasterRepository>();
    builder.Services.AddScoped<IReportRepository, ReportRepository>();
    builder.Services.AddScoped<IQuestionnaireAnswerRepository, QuestionnaireAnswerRepository>();
	builder.Services.AddControllers();

    builder.Services.AddSingleton<CacheHelper>();

    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen();

    var app = builder.Build();
    var env = app.Environment;
   
    app.UseSwagger();
    app.UseSwaggerUI();
    

    app.UseHttpsRedirection();
    app.UseStaticFiles();
    app.UseCors("AllowAll");

    app.UseAuthentication();

    app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
    Rotativa.AspNetCore.RotativaConfiguration.Setup(env.WebRootPath, "Rotativa");

    app.UseAuthorization();

    app.MapControllers();

    app.Run();
}
catch (Exception exception)
{
    logger.Error(exception, "Stopped program because of exception");
    throw;
}
finally
{
    logger.Dispose();
}