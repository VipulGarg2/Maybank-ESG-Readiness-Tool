using ESGSurvey.Api.Filters;
using ESGSurvey.BusinessLayer;
using ESGSurvey.BusinessLayer.DTO.Common;
using ESGSurvey.BusinessLayer.DTO.MasterModule;
using ESGSurvey.BusinessLayer.DTO.ReportModule;
using ESGSurvey.BusinessLayer.Interfaces.MasterModule;
using ESGSurvey.BusinessLayer.Interfaces.ReportModule;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace ESGSurvey.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [ApiKeyCheck]
    public class MasterController : ControllerBase
    {
        #region Declaration & Constructor
        private readonly IMasterRepository _masterRepository;
        private readonly IReportRepository _reportRepository;
        public MasterController(
            IMasterRepository masterRepository,
            IReportRepository reportRepository)
        {
            _masterRepository = masterRepository;
            _reportRepository = reportRepository;
        }
        #endregion Declaration & Constructor

        #region Public Methods
        
        [AllowAnonymous]
        [HttpGet("GetAllOrganizationSector")]
        public async Task<ActionResult<GroupedOptionsResponseDto>> GetAllOrganizationSector()
        {
            var LstSector = await _masterRepository.GetAllOrganizationSector();
            return Ok(LstSector);
        }

        [AllowAnonymous]
        [HttpGet("GetAllOrganizationUnGroupSector")]
        public async Task<ActionResult<CommonDropdownResponseDto>> GetAllOrganizationUnGroupSector()
        {
            var LstSector = await _masterRepository.GetAllOrganizationUnGroupSector();
            return Ok(LstSector);
        }

        [AllowAnonymous]
        [HttpGet("GetAllCompanyTurnover")]
        public async Task<ActionResult<CommonDropdownResponseDto>> GetAllCompanyTurnover()
        {

            var LstTurnOver = await _masterRepository.GetAllCompanyTurnover();
            return Ok(LstTurnOver);
        }

        [AllowAnonymous]
        [HttpGet("GetAllQuestion")]
        public async Task<ActionResult<AllQuestionResponseDto>> GetAllQuestion()
        {

            AllQuestionResponseDto response = new AllQuestionResponseDto();
            response = await _masterRepository.GetAllQuestion();
            return Ok(response);
        }

        [AllowAnonymous]
        [HttpGet("GetEsgReportSummary")]
        public async Task<ActionResult<ReportSummaryDto>> GetEsgReportSummary(Guid guid)
        {
            var response = await _reportRepository.GetEsgReportSummary(guid);
            return Ok(response);
        }
        #endregion Public Methods


    }
}
