﻿using ESGSurvey.BusinessLayer.DTO.ReportModule;
using ESGSurvey.BusinessLayer.Interfaces.ReportModule;
using iText.Kernel.Colors;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Action;
using iText.Kernel.Pdf.Annot;
using iText.Kernel.Pdf.Canvas;
using iText.Kernel.Pdf.Canvas.Parser.Listener;
using iText.Kernel.Pdf.Canvas.Parser;
using iText.Kernel.Pdf.Navigation;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Mvc;
using Rotativa.AspNetCore;
using Rotativa.AspNetCore.Options;
using System.IO;
using ESGSurvey.Api.Helper;
using iText.Kernel.Pdf.Canvas.Parser.Data;
using System.Text;
using System.Reflection.PortableExecutable;



namespace ESGSurvey.Api.Controllers
{
    [Route("api/pdf")]
    public class PDFController : Controller
    {
        private readonly IConfiguration _config;
        private readonly IReportRepository _reportRepository;
        private IWebHostEnvironment _hostingEnvironment;
        public PDFController(IReportRepository reportRepository, IConfiguration config, IWebHostEnvironment hostingEnvironment)
        {
            _reportRepository = reportRepository;
            _config = config;
            _hostingEnvironment = hostingEnvironment;
        }

        [HttpGet]
        [Route("GetESGMaturityAssessmentReport")]
        public async Task<IActionResult> GetEsgSustainabilityReport(Guid guid)
        {
            EsgSustainabilityReportResponseDto result =await  _reportRepository.GetEsgSustainabilityReport(guid);
            if (result != null)
                {
                string footerPath = System.IO.Path.Combine(_hostingEnvironment.ContentRootPath, "Views", "PDF", "Footer.html");
                string customSwitches = $"--enable-internal-links --footer-html {footerPath} --zoom 1.1";
                var pdfResult = new ViewAsPdf("ESGMaturityAssessmentReport", result)
                    {
                        PageOrientation = Orientation.Portrait,
                        PageSize = Rotativa.AspNetCore.Options.Size.A4,
                        CustomSwitches = customSwitches,
                        PageMargins = new Rotativa.AspNetCore.Options.Margins(12, 12, 12, 12)
                };

                // Get the PDF as a byte array
                var pdfBytes =await pdfResult.BuildFile(ControllerContext);

                var pageNumberList = new int[4] {4,5,6,7};
                // Modify the generated PDF to add or change links
                for (int i = 0; i < pageNumberList.Length; i++)
                {
                    int linkedPageNumber = pageNumberList[i];
                    pdfBytes = ModifyPdfAndReplaceLink(pdfBytes, "GHG emissions", linkedPageNumber, 21);
                    pdfBytes = ModifyPdfAndReplaceLink(pdfBytes, "Government Grants", linkedPageNumber, 19);
                    pdfBytes = ModifyPdfAndReplaceLink(pdfBytes, "Sustainability Trainings", linkedPageNumber, 17);
                    pdfBytes = ModifyPdfAndReplaceLink(pdfBytes, "Sustainability Reporting", linkedPageNumber, 14);
                    pdfBytes = ModifyPdfAndReplaceLink(pdfBytes, "Sustainability Certifications", linkedPageNumber, 16);
                    pdfBytes = ModifyPdfAndReplaceLink(pdfBytes, "Sustainable Financing", linkedPageNumber, 18);
                    pdfBytes = ModifyPdfAndReplaceLink(pdfBytes, "Singapore Green Plan", linkedPageNumber, 11);

                }

                // Return the modified PDFv
                return File(pdfBytes, "application/pdf", guid+ ".pdf");
            }
                return View();
        }

        private byte[] ModifyPdfAndReplaceLink(byte[] pdfBytes, string linkText, int linkPageNumber, int targetPageNumber)
        {
            using (var memoryStream = new MemoryStream())
            {
                using (var reader = new PdfReader(new MemoryStream(pdfBytes)))
                using (var writer = new PdfWriter(memoryStream))
                using (var pdfDoc = new PdfDocument(reader, writer))
                {

                    // Get the page where you want to place the link
                    PdfPage linkPage = pdfDoc.GetPage(linkPageNumber);

                    // Create a canvas to draw the link text
                    PdfCanvas canvas = new PdfCanvas(linkPage);
                    Rectangle pageSize = linkPage.GetPageSize();

                    // Dynamic text placement coordinates (adjust to your needs)
                    var lstCoordinateResult = FindSentenceInPdf(pdfBytes, linkText, linkPageNumber);

                    foreach (var resultCoordinate in lstCoordinateResult)
                    {
                        // Get the first page of the PDF
                        PdfPage page = pdfDoc.GetPage(resultCoordinate.PageNumber); // Adjust page number as needed
                        PdfPage page2 = pdfDoc.GetPage(targetPageNumber);


                        // Create a link annotation
                        PdfLinkAnnotation linkAnnotation = new PdfLinkAnnotation(new iText.Kernel.Geom.Rectangle(resultCoordinate.X, resultCoordinate.Y, resultCoordinate.X1 - resultCoordinate.X, 10));
                        // Make the border transparent by setting the border width to 0
                        linkAnnotation.SetBorder(new PdfArray(new float[] { 0, 0, 0 }));

                        // Set the destination to Page 2
                        PdfAction goToPage2 = PdfAction.CreateGoTo(PdfExplicitDestination.CreateFit(page2));
                        linkAnnotation.SetAction(goToPage2);


                        // Add the annotation to the page
                        page.AddAnnotation(linkAnnotation);
                    }
                  

                    // Close the document
                    pdfDoc.Close();

                }

                return memoryStream.ToArray();
            }
        }
        public class PositionOfText
        {
            public float x { get; set; }
            public float y { get; set; }
            public float width { get; set; }
            public float height { get; set; }
        }
        private List<TextSearchResult> FindSentenceInPdf(byte[] pdfBytes, string searchText, int linkPageNumber)
        {
            List<TextSearchResult> lstTextSearchResult = new List<TextSearchResult>();
            PdfDocument pdfDoc = new PdfDocument(new PdfReader(new MemoryStream(pdfBytes)));
            PdfPage page = pdfDoc.GetPage(linkPageNumber);
            TextExtractionStrategyWithPosition strategy = new TextExtractionStrategyWithPosition();

            // Parse the page with the strategy
            PdfCanvasProcessor processor = new PdfCanvasProcessor(strategy);
            processor.ProcessPageContent(page);
            var allPageContent = string.Join("",   strategy.TextChunks.Select(x => x.Text));
            var sentenceToSearch = String.Format("{0} can be found in the Sustainability Playbook", searchText);
            if (allPageContent.Contains(sentenceToSearch, StringComparison.OrdinalIgnoreCase))
            {
                var lstLocationIndex = ArrayStringSearch.SearchStringInCharArray(strategy.TextChunks.ToArray(), searchText);
                foreach (var location in lstLocationIndex)
                {
                    lstTextSearchResult.Add(new TextSearchResult
                    {
                        PageNumber = linkPageNumber,
                        X = strategy.TextChunks[location.StartIndex].Location.Start.Get(Vector.I1),
                        Y = strategy.TextChunks[location.StartIndex].Location.Start.Get(Vector.I2),
                        X1 = strategy.TextChunks[location.EndIndex].Location.End.Get(Vector.I1),
                        Y1 = strategy.TextChunks[location.EndIndex].Location.End.Get(Vector.I2),
                    });
                }
            }

            pdfDoc.Close();

            return lstTextSearchResult;
        }




    [HttpGet]
        [Route("GetEsgSustainabilityReportHTML")]
        public IActionResult GetEsgSustainabilityReportHTML(Guid guid)
        {
            EsgSustainabilityReportResponseDto result = _reportRepository.GetEsgSustainabilityReport(guid).Result;
            if (result != null)
            {
                return View("ESGMaturityAssessmentReport", result);
            }
            return View();
        }
    }
}
