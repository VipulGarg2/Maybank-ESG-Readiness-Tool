using Azure;
using ESGSurvey.Api.Extensions;
using ESGSurvey.Api.Filters;
using ESGSurvey.Api.Helper.Crypto;
using ESGSurvey.Api.Helper.Interfaces;
using ESGSurvey.BusinessLayer;
using ESGSurvey.BusinessLayer.DTO.Common;
using ESGSurvey.BusinessLayer.DTO.MasterModule;
using ESGSurvey.BusinessLayer.DTO.UserModule;
using ESGSurvey.BusinessLayer.Interfaces.MasterModule;
using ESGSurvey.BusinessLayer.Interfaces.QuestionnaireAnswerModule;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using RestSharp;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace ESGSurvey.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [ApiKeyCheck]
    public class QuestionnaireAnswerController : Controller
    {
        #region Declaration & Constructor
        private readonly IQuestionnaireAnswerRepository _questionnaireAnswerRepository;
        private readonly IConfiguration _config;
        private IWebHostEnvironment _hostingEnvironment;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IEmailSender _emailSender;
        private readonly AesEncryption _aesEncryption;
        private readonly IMasterRepository _masterRepository;
        public QuestionnaireAnswerController(IQuestionnaireAnswerRepository questionnaireAnswerRepository,
            IConfiguration config, IWebHostEnvironment hostingEnvironment, IHttpContextAccessor httpContextAccessor,
            IEmailSender emailSender,IMasterRepository masterRepository)
        {
            _questionnaireAnswerRepository = questionnaireAnswerRepository;
            _config = config;
            _hostingEnvironment = hostingEnvironment;
            _httpContextAccessor = httpContextAccessor;
            _emailSender = emailSender;
            _aesEncryption = new AesEncryption(_config["AppSettings:CryptoKey"]!);
            _masterRepository = masterRepository;
        }
        private string GetUploadFolderPath()
        {
            return _config["FileStorage:Path"];
        }

        #endregion Declaration & Constructor

        #region Public Methods
        /// <summary>
        /// AllQuestionResponseDto
        /// </summary>
        /// <param name="allQuestionRequest"></param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpPost("SaveQuestionnaireAnswer")]
        public async Task<ActionResult<CustomSuccessResponse>> SaveQuestionnaireAnswer([FromBody] AllQuestionResponseDto allQuestionRequest)
        {
            CustomSuccessResponse response = new CustomSuccessResponse();
            if (!string.IsNullOrEmpty(allQuestionRequest.RequestKey) && !string.IsNullOrWhiteSpace(allQuestionRequest.RequestKey))
            {
                var decrypted = _aesEncryption.Decrypt(allQuestionRequest.RequestKey);
                if (Guid.TryParse(decrypted, out Guid parsedGuid))
                {
                    var verifyRequestId = await _questionnaireAnswerRepository.VerifyRequestId(parsedGuid);
                    if (verifyRequestId == 1)
                    {
                        var guid = await _questionnaireAnswerRepository.SaveQuestionnaireAnswer(allQuestionRequest, parsedGuid);

                        await SendPdf(guid);
                        await SendBusinessInformationEmailAsync(allQuestionRequest);


                        return Ok(guid);
                    }
                    else
                    {
                        response.ErrorMessage = "Unauthorized request";
                    }
                }
                else
                {
                    response.ErrorMessage = "Unauthorized request";
                }
            }
            else
            {
                response.ErrorMessage = "Unauthorized request";
            }
            return Ok(response);
        }

     
        /// <summary>
        /// Retrieves the ESG Maturity Assessment Report by GUID.
        /// </summary>
        /// <param name="guid">The unique identifier for the report.</param>
        /// <returns>An ActionResult containing the report file if found; otherwise, returns a NotFound result.</returns>
        /// <response code="200">Returns the report file.</response>
        /// <response code="404">If the report file does not exist.</response>
        [AllowAnonymous]
        [HttpGet("GetEsgMaturityAssessmentReport")]
        public async Task<ActionResult> GetEsgMaturityAssessmentReport(string guid)
        {
            try
            {
                if (!Guid.TryParse(guid, out _))
                {
                    return BadRequest("Invalid GUID format.");
                }
                var filePath = Path.Combine(GetUploadFolderPath(), $"ESGReadinessAssessmentReport_{guid}.pdf");
                if (!System.IO.File.Exists(filePath))
                {
                    return NotFound("Report not found.");
                }

                var fileBytes = await System.IO.File.ReadAllBytesAsync(filePath);
                return File(fileBytes, "application/pdf", $"ESGReadinessAssessmentReport.pdf");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving report: {ex.Message}");
                return StatusCode(500, "Internal server error.");
            }
        }
        #endregion Public Methods

        #region Private Methods
        private async Task<bool> SendPdf(Guid guid)
        {
            string protocol = _httpContextAccessor.HttpContext.Request.IsHttps ? "https" : "http";
            string requestUrl = _config["SendPdfApiControllerUrl"]!;

            var restClient = new RestClient(requestUrl);
            var request = new RestRequest($"api/pdf/GetESGMaturityAssessmentReport?guid={guid}", Method.Get);

            byte[] response = restClient.DownloadData(request);
            if (response != null)
            {
                byte[] byteArray = response;

                string filePath = GetUploadFolderPath();
                if (!Directory.Exists(filePath))
                {
                    Directory.CreateDirectory(filePath);
                }
                string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                String uniqueFileName = $"ESGReadinessAssessmentReport_{guid}.pdf";
                string fullPath = Path.Combine(filePath, uniqueFileName);
                System.IO.File.WriteAllBytes(fullPath, byteArray);

                var userInfo = await _questionnaireAnswerRepository.GetEndUserInfo(guid);

                var emailBody = await this.RenderViewToStringAsync("ESGMaturityAssessmentReportEmailTemplate", userInfo, TempData);
                await _emailSender.SendPdfEmailAsync(userInfo.EmailAddress, "Your ESG Readiness Assessment Report is Ready!", emailBody, response, "ESGReadinessAssessmentReport.pdf");
            }
            return true;
        }

        private async Task SendBusinessInformationEmailAsync(AllQuestionResponseDto questionResponse)
        {
            var adminEmail=  _config["BusinessInformationEmail:AdminEmail"];
            if (!string.IsNullOrEmpty(adminEmail))
            {
                var LstTurnOver = await _masterRepository.GetAllCompanyTurnover();
                var CompanyTurnOver = LstTurnOver.LstDropdownData.Find(x => x.Value == questionResponse.CompanyTurnoverId)?.Label ?? string.Empty;
                questionResponse.AdminName= _config["BusinessInformationEmail:AdminName"]??string.Empty;
                questionResponse.CompanyTurnover = CompanyTurnOver;
                var emailBody = await this.RenderViewToStringAsync("ESGBusinessInformationEmailTemplate", questionResponse, TempData);
                await _emailSender.SendEmailAsync(adminEmail, "New ESG Readiness Assessment Survey Submission", emailBody);

            }

        }
        #endregion Private Methods
    }
}
