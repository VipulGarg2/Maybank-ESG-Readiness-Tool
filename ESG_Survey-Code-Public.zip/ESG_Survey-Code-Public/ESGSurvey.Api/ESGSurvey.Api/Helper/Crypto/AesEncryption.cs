﻿using System.Security.Cryptography;
using System.Text;

namespace ESGSurvey.Api.Helper.Crypto
{
    public class AesEncryption
    {
        private readonly byte[] _key;

        public AesEncryption(string hexKey)
        {
            _key = Encoding.UTF8.GetBytes(hexKey);
        }

        public string Decrypt(string cipherText)
        {
            var parts = cipherText.Split(':');
            var iv = Convert.FromBase64String(parts[0]); // Extract IV
            var encrypted = parts[1]; // Get the actual encrypted text

            byte[] fullCipher = Convert.FromBase64String(encrypted);

            using (Aes aes = Aes.Create())
            {
                aes.Key = _key;
                aes.IV = iv;

                using (var ms = new MemoryStream(fullCipher))
                {
                    using (var cryptoStream = new CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Read))
                    {
                        using (var reader = new StreamReader(cryptoStream))
                        {
                            return reader.ReadToEnd();
                        }
                    }
                }
            }
        }
    
    }
}
