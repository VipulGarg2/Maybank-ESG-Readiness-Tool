﻿using Microsoft.Extensions.Options;
using System.Net.Mail;
using System.Net;
using ESGSurvey.Api.Helper.Interfaces;
using ESGSurvey.BusinessLayer.DTO.Common;
using System.Net.Mime;
using System.Net.Http;

namespace ESGSurvey.Api.Helper.Implementations
{
	public class EmailSender : IEmailSender
	{
		private readonly EmailSenderOptions _options;
        private readonly IConfiguration _config;
        private readonly ILogger<EmailSender> _emailSenderLogger;
		public EmailSender(IOptions<EmailSenderOptions> options, ILogger<EmailSender> emailSenderLogger, IConfiguration config)
		{
			_options = options.Value;
			_emailSenderLogger = emailSenderLogger;
			_config = config;

        }

		public async Task SendEmailAsync(string email, string subject, string message)
		{
			try
			{
                SmtpClient smtpClient;
                MailMessage mailMessage;
                if (_config["EmailSender:SmtpUsername"] != null && _config["EmailSender:SmtpUsername"] != "")
                {
                    smtpClient = new SmtpClient(_config["EmailSender:SmtpServer"]!, Convert.ToInt32(_config["EmailSender:SmtpPort"]!))
                    {
                        UseDefaultCredentials = false,
                        Credentials = new NetworkCredential(_config["EmailSender:SmtpUsername"]!, _config["EmailSender:SmtpPassword"]!),
                        EnableSsl = Convert.ToBoolean(_config["EmailSender:UseSsl"]!)
                    };

                    mailMessage = new MailMessage
                    {
                        From = new MailAddress(_config["EmailSender:SmtpUsername"]!),
                        Subject = subject,
                        Body = message,
                        IsBodyHtml = true
                    };

                    mailMessage.To.Add(new MailAddress(email));

                    
                }
                else
                {
                    smtpClient = new SmtpClient(_config["EmailSender:SmtpServer"]!, Convert.ToInt32(_config["EmailSender:SmtpPort"]!))
                    {
                        EnableSsl = Convert.ToBoolean(_config["EmailSender:UseSsl"]!)
                    };

                    mailMessage = new MailMessage
                    {
                        From = new MailAddress(_config["EmailSender:SmtpUsername"]!),
                        Subject = subject,
                        Body = message,
                        IsBodyHtml = true
                    };

                    mailMessage.To.Add(new MailAddress(email));
                   
                }

                Task.Factory.StartNew(() => { smtpClient.SendMailAsync(mailMessage); });

            }
			catch (Exception ex)
			{
				_emailSenderLogger.LogError(ex, "Error Log while sending email : ");

            }
		}

        public async Task SendPdfEmailAsync(string email, string subject, string message, Byte[] file, string fileName)
        {
            try
            {
                if (_config["EmailSender:SmtpUsername"] != null && _config["EmailSender:SmtpUsername"] != "")
                {
                    var smtpClient = new SmtpClient(_config["EmailSender:SmtpServer"]!, Convert.ToInt32(_config["EmailSender:SmtpPort"]!))
                    {
                        UseDefaultCredentials = false,
                        Credentials = new NetworkCredential(_config["EmailSender:SmtpUsername"]!, _config["EmailSender:SmtpPassword"]!),
                        EnableSsl = Convert.ToBoolean(_config["EmailSender:UseSsl"]!)
                    };

                    var mailMessage = new MailMessage
                    {
                        From = new MailAddress(_config["EmailSender:SmtpUsername"]!),
                        Subject = subject,
                        Body = message,
                        IsBodyHtml = true
                    };
                    var attachment = new Attachment(new MemoryStream(file),
                                            fileName,
                                            MediaTypeNames.Application.Pdf);
                    attachment.ContentDisposition.FileName = fileName;
                    mailMessage.Attachments.Add(attachment);

                    mailMessage.To.Add(new MailAddress(email));

                    Task.Factory.StartNew(() => { smtpClient.SendMailAsync(mailMessage); });
                }
                else
                {
                    var smtpClient = new SmtpClient(_config["EmailSender:SmtpServer"]!, Convert.ToInt32(_config["EmailSender:SmtpPort"]!))
                    {
                        EnableSsl = Convert.ToBoolean(_config["EmailSender:UseSsl"]!)
                    };

                    var mailMessage = new MailMessage
                    {
                        From = new MailAddress(_config["EmailSender:SmtpUsername"]!),
                        Subject = subject,
                        Body = message,
                        IsBodyHtml = true
                    };
                    var attachment = new Attachment(new MemoryStream(file),
                                            fileName,
                                            MediaTypeNames.Application.Pdf);
                    attachment.ContentDisposition.FileName = fileName;
                    mailMessage.Attachments.Add(attachment);

                    mailMessage.To.Add(new MailAddress(email));

                    Task.Factory.StartNew(() => { smtpClient.SendMailAsync(mailMessage); });
                }
                    
            }
            catch (Exception ex)
            {
                _emailSenderLogger.LogError(ex, "Error Log while sending email : ");

            }
        }
    }

}
