﻿using iText.Kernel.Pdf.Canvas.Parser.Data;
using iText.Kernel.Pdf.Canvas.Parser.Listener;
using iText.Kernel.Pdf.Canvas.Parser;
using iText.Kernel.Geom;

namespace ESGSurvey.Api.Helper
{
    public class TextExtractionStrategyWithPosition : ITextExtractionStrategy
    {
        public List<TextChunk> TextChunks = new List<TextChunk>();

        public void EventOccurred(IEventData data, EventType type)
        {
            if (type != EventType.RENDER_TEXT)
                return;

            TextRenderInfo renderInfo = (TextRenderInfo)data;
            Vector start = renderInfo.GetBaseline().GetStartPoint();
            Vector end = renderInfo.GetBaseline().GetEndPoint();
            TextChunks.Add(new TextChunk(renderInfo.GetText(), new TextChunkLocation(start, end)));
        }

        public string GetResultantText()
        {
            return string.Join(" ", TextChunks.Select(tc => tc.Text));
        }

        public bool Equals(TextRenderInfo other) => false;
        public void EndTextBlock() { }
        public void BeginTextBlock() { }

        public ICollection<EventType> GetSupportedEvents()
        {
            return new HashSet<EventType> { EventType.RENDER_TEXT };
        }
    }
    // Custom class to hold the search result
    public class TextSearchResult
    {
        public int PageNumber { get; set; }
        public float X { get; set; }
        public float Y { get; set; }

        public float X1 { get; set; }
        public float Y1 { get; set; }
    }
    public class TextChunk
    {
        public string Text { get; }
        public TextChunkLocation Location { get; }

        public TextChunk(string text, TextChunkLocation location)
        {
            Text = text;
            Location = location;
        }
    }

    public class TextChunkLocation
    {
        public Vector Start { get; }
        public Vector End { get; }

        public TextChunkLocation(Vector start, Vector end)
        {
            Start = start;
            End = end;
        }

        public Vector GetStartLocation() => Start;
    }


    public class TextLocation
    {
        public string Text { get; set; }
        public float X { get; set; }
        public float Y { get; set; }
    }


    public class ArrayStringSearch
    {

        // Function to search for a string in a character array and return the start and end positions
        public static List<TextSearchIndexDto> SearchStringInCharArray(TextChunk[] charArray, string searchString)
        {
            List<TextSearchIndexDto> lstSearchIndex = new List<TextSearchIndexDto>();
            int charArrayLength = charArray.Length;
            int searchStringLength = searchString.Length;

            // Convert the search string to a character array for comparison
            char[] searchCharArray = searchString.ToCharArray();

            // Loop through the character array
            for (int i = 0; i <= charArrayLength - searchStringLength; i++)
            {
                // Check if the substring of charArray starting from index 'i' matches the searchString
                bool matchFound = true;
                for (int j = 0; j < searchStringLength; j++)
                {
                    if (charArray[i + j].Text[0] != searchCharArray[j])
                    {
                        matchFound = false;
                        break;
                    }
                }

                // If a match is found, return the start and end indices
                if (matchFound)
                {
                    lstSearchIndex.Add(new TextSearchIndexDto { StartIndex = i, EndIndex = i + searchStringLength - 1 });
                }
            }

            // Return null if the search string is not found
            return lstSearchIndex;
        }
    }

    public class TextSearchIndexDto
    {
        public int StartIndex { get; set; }
        public int EndIndex { get; set; }
    }


}
