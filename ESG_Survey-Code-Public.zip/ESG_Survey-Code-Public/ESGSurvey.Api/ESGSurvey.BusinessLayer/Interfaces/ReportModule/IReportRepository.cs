﻿using ESGSurvey.BusinessLayer.DTO.Common;
using ESGSurvey.BusinessLayer.DTO.ReportModule;

namespace ESGSurvey.BusinessLayer.Interfaces.ReportModule
{
    public interface IReportRepository
    {
        /// <summary>
        /// GetEsgSustainabilityReport
        /// </summary>
        /// <param name="ReportGuid"></param>
        /// <returns></returns>
        Task<EsgSustainabilityReportResponseDto> GetEsgSustainabilityReport(Guid ReportGuid);
        /// <summary>
        /// GetEsgReportSummary
        /// </summary>
        /// <param name="guid"></param>
        /// <returns></returns>
        Task<ReportSummaryDto> GetEsgReportSummary(Guid guid);
    }
}
