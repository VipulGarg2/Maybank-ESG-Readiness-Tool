﻿using ESGSurvey.BusinessLayer.DTO.Common;
using ESGSurvey.BusinessLayer.DTO.MasterModule;

namespace ESGSurvey.BusinessLayer.Interfaces.MasterModule
{
    public interface IMasterRepository
    {
        /// <summary>
        /// GetAllOrganizationSector
        /// </summary>
        /// <returns></returns>
        Task<GroupedOptionsResponseDto> GetAllOrganizationSector();
        /// <summary>
        /// GetAllOrganizationUnGroupSector
        /// </summary>
        /// <returns></returns>
        Task<CommonDropdownResponseDto> GetAllOrganizationUnGroupSector();
        /// <summary>
        /// GetAllCompanyTurnover
        /// </summary>
        /// <returns></returns>
        Task<CommonDropdownResponseDto> GetAllCompanyTurnover();
        /// <summary>
        /// GetAllQuestion
        /// </summary>
        /// <returns></returns>
        Task<AllQuestionResponseDto> GetAllQuestion();


    }
}
