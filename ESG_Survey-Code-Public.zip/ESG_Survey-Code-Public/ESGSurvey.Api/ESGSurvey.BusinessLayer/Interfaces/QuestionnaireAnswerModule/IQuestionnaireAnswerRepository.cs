﻿using ESGSurvey.BusinessLayer.DTO.Common;
using ESGSurvey.BusinessLayer.DTO.MasterModule;
using ESGSurvey.BusinessLayer.DTO.UserModule;

namespace ESGSurvey.BusinessLayer.Interfaces.QuestionnaireAnswerModule
{
    public interface IQuestionnaireAnswerRepository
    {
        /// <summary>
        /// SaveQuestionnaireAnswer
        /// </summary>
        /// <param name="allQuestionRequest"></param>
        /// <returns></returns>
        Task<Guid> SaveQuestionnaireAnswer(AllQuestionResponseDto allQuestionRequest, Guid parsedGuid);
        /// <summary>
        /// GetEndUserInfo
        /// </summary>
        /// <param name="guid"></param>
        /// <returns></returns>
        Task<UserInfoDto> GetEndUserInfo(Guid guid);
        /// <summary>
        /// VerifyRequestId
        /// </summary>
        /// <param name="requestId"></param>
        /// <returns></returns>
        Task<int> VerifyRequestId(Guid parsedGuid);
    }
}
