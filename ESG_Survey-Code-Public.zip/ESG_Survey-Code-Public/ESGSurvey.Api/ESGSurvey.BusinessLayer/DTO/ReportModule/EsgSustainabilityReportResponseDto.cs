﻿using ESGSurvey.BusinessLayer.DTO.MasterModule;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.DTO.ReportModule
{
    public class TokenDto
    {
        public string TokenKey { get; set; } = string.Empty;
        public string TokenValue { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;

    }
    public class PillarNameDto
    {
        public byte PillarId { get; set; } = 0;
        public string PillarName { get; set; } = string.Empty;
        public List<RecommendationDto> RecommendationList { get; set; } = new List<RecommendationDto>();
        public List<ProductDto> ProductList { get; set; } = new List<ProductDto>();


    }


    public class RecommendationDto
    {
        public string Recommendation { get; set; } = string.Empty;
        public byte PillarId { get; set; } = 0;
        public string PillarName { get; set; } = string.Empty;

    }
    
    public class ProductDto
    {
        public byte PillarId { get; set; } = 0;
        public string ProductName { get; set; } = string.Empty;
        public string ProductURL { get; set; } = string.Empty;
        public string ProductDescription { get; set; } = string.Empty;

    }


    public class EsgSustainabilityReportResponseDto
    {
        public decimal Score { get; set; } = 0;
        public string MaturityLevel { get; set; } = string.Empty;
        public List<TokenDto> TokenList { get; set; } = new List<TokenDto>();
        public List<PillarNameDto> PillarList { get; set; } = new List<PillarNameDto>();
        public List<PillarScoreDto> PillarScoreList { get; set; } = new List<PillarScoreDto>();
    }

    public class PillarScoreDto
    {
        public decimal Score { get; set; } = 0;
        public string MaturityLevel { get; set; } = string.Empty;
        public int PillarId { get; set; }
        public string PillarName { get; set; } = string.Empty;
    }
    public class ReportSummaryDto
    {
       
        public decimal SurveyScore { get; set; } = 0;
        public string SurveyMaturityLevel { get; set; } = string.Empty; 
        public int OrganizationDetailsId { get; set; } = 0;
        public List<PillarReportSummaryDto> PillarReportList { get; set; } = new List<PillarReportSummaryDto>();



    }

    public class PillarReportSummaryDto
    {
        public byte PillarId { get; set; } = 0;
        public string PillarName { get; set; } = string.Empty;

        public string PillarTitle { get; set; } = string.Empty;

        public decimal Score { get; set; } = 0;
        public string MaturityLevel { get; set; } = string.Empty;
        public int OrganizationDetailsId { get; set; } = 0;

    }
}
