import React, { Suspense } from "react";
import { BrowserRouter as Router, Route, Routes, Navigate } from "react-router-dom";
const StartQuizPage = React.lazy(()=> import("./components/Pages/StartQuizPage"));
const QuizPage = React.lazy(()=> import( "./components/Pages/QuizPage"));
const BusinessInformationPage = React.lazy(()=> import( "./components/Pages/BusinessInformationPage"));
const DownloadReportPage = React.lazy(()=> import( "./components/Pages/DownloadReportPage"));
const StepsPage = React.lazy(()=> import( "./components/Pages/StepsPage"));

function AppRouter() {
 
  return (
      <Suspense fallback={<></>}>
      <Routes>
          <Route path="/esgsurvey" element={<QuizPage />} />
          {/* <Route path="/start-quiz" element={<StartQuizPage />} /> */}
          <Route path="/esgsurvey/quiz" element={<QuizPage />} />
          <Route
              path="/esgsurvey/business-information"
              element={<BusinessInformationPage />} />
          <Route path="/esgsurvey/download-report" element={<DownloadReportPage />} />
          {/* <Route path="/steps" element={<StepsPage />} /> */}
      </Routes>
      </Suspense>
       
  );
}

export default AppRouter;
