
  export const API_ENDPOINTS = {
    FORGOT_PASSWORD: '/AdminAuth/ForgotPassword',
    LOGIN: '/AdminAuth/Login',
    RESET_PASSWORD: '/AdminAuth/ChangePassword',
    GET_QUESTIONNAIR_LIST: "/AdminQuestionnaire/GetQuestionnaireList",
    GET_QUESTIONNAIR_BY_ID: "AdminQuestionnaire/GetQuestionnaireSelect",
    UPDATE_QUESTIONNAIRE: "AdminQuestionnaire/QuestionnaireUpdate",
    PRODUCT_LIST: "Product/ProductGridSelect",
    GET_PRODUCT_BY_ID: "Product/ProductSelect",
    EXTERNAL_LINK_LIST: "Token/TokenGridSelect",
    GET_EXTERNAL_LINK_BY_ID: "Token/TokenSelect",
    TOKEN_UPDATE: "Token/TokenUpsert",
    PRODUCT_UPDATE: "Product/ProductUpdate",
    CHECK_RESET_PASSWORD : '/AdminAuth/CheckResetTokenStatus'
  };


    export const TOAST_TYPES = {
        SUCCESS: 'success',
        ERROR: 'error',
        INFO: 'info',
        WARNING: 'warning',
    };
  
  
  export const MESSAGES = {
    LOGIN_SUCCESS: 'logged in successfully!',
    ERROR: 'There was an error completing the action.',
    LOGIN_FAILED : 'Please enter valid credentials',
    FORGOT_PASSWORD_SUCCESS : "forgot password reset link has been successfully sent.",
    RESET_PASSWORD_SUCCESS : "Password has been successfully reset.",
    QUESTIONNAIRE_UPDATE_SUCCESS: "Questionnaire details updated successfully.",
    EXTRNAL_LINK_UPDATE_SUCCESS: "External Link details updated successfully.",
    PRODUCT_LIST_UPDATE_SUCCESS: "Product details updated successfully."
  };
  