import { combineReducers } from "@reduxjs/toolkit";
import loaderSlice from "./loaderSlice";
import queSlice from "./queSlice";

const rootReducer = combineReducers({
  que:queSlice,
  loader: loaderSlice
});

export default rootReducer;
