// src/store/authSlice.js
import { createSlice } from "@reduxjs/toolkit";

const queSlice = createSlice({
  name: "que",
  initialState: {
    businessEntityName: "",
    businessUEN: "",
    companyTurnoverId: 0,
    organizationSectorId: 0,
    nameOfPrimaryContact: "",
    roleOfPrimaryContact: "",
    corporateEmailAddressPrimaryContact: "",
    phoneNumberPrimaryContact: "",
    isExistingMaybankCustomer: false,
    isExploringGreenSolution: false,
    scaleOfTransitionToGreenerSolutions: 0,
    isConsentTermsAccepted: false,
    captchaToken: "",
    pillers: [], // Array of PillarDto objects
    GUID:null,
  },
  reducers: {
    setAllQuestions: (state, action) => {
      // Spread current state and update with new data immutably
      return {
        ...state,
        ...action.payload,
        pillers: action.payload.pillers.map((pillar) => ({
          ...pillar,
          questions: pillar.questions.map((question) => ({
            ...question,
            predefinedAnswers: question.predefinedAnswers.map((answer) => ({
              ...answer, // Ensuring that we create a new object for each answer
            })),
          })),
        })),
      };
    },

    setGUIDKey: (state, action) => {
      state.GUID = action.payload;
    },
  // Action to clear the slice (reset to initial state)
  clearAllQuestions: () => {
    return {
      businessEntityName: "",
      businessUEN: "",
      companyTurnoverId: 0,
      organizationSectorId: 0,
      nameOfPrimaryContact: "",
      roleOfPrimaryContact: "",
      corporateEmailAddressPrimaryContact: "",
      phoneNumberPrimaryContact: "",
      isExistingMaybankCustomer: false,
      isExploringGreenSolution: false,
      scaleOfTransitionToGreenerSolutions: 0,
      isConsentTermsAccepted: false,
      captchaToken: "",
      pillers: [], // Array of PillarDto objects
    };
  },
},
});

export const { setAllQuestions, clearAllQuestions, setGUIDKey } = queSlice.actions;
export default queSlice.reducer;
