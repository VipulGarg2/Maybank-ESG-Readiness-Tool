// Header.jsx
import React,{useEffect} from "react";
import { useAuth } from "../../context/AuthContext";
import { useSelector } from "react-redux";
import { useLocation } from "react-router-dom"; // Import useLocation
import MenuIcon from "../../../public/menu-icon.svg";
import { Dropdown } from "react-bootstrap";

const Header = ({ showSidebar, toggleSidebar }) => {
  const { logout } = useAuth();
  const userName = useSelector((state) => state.auth.userName);
  const location = useLocation(); // Get the current location

  const setPageTitle = () => {
    const path = location.pathname; // Get the current path
    switch (path) {
      case "/admin-surveys":
        document.title = "Surveys";
        break;
      case "/admin-questionnaire":
        document.title = "Questionnaire";
        break;
      case "/products":
        document.title = "Products";
        break;
      default:
        document.title = "ESG Surveys"; // Fallback title
        break;
    }
  };
  // Set the page title whenever the location changes
  useEffect(() => {
    setPageTitle();
  }, [location]);

  const handleLogout = (e) => {
    logout();
  };
  return (
    <header className="admin-header">
      <div className="header-container d-flex align-items-center">
        <div className="nav-toggle-icon">
          <a className="sidenav-fold-toggler cursor" onClick={toggleSidebar}>
            <img src={MenuIcon} />
          </a>
          <span className="page-title">{document.title}</span>
        </div>

        <div className="ms-auto d-flex align-items-center top-user-action">
          <Dropdown>
            <Dropdown.Toggle variant="success" id="dropdown-basic">
              <span>{userName}</span>
            </Dropdown.Toggle>

            <Dropdown.Menu>
              <Dropdown.Item href="#" onClick={handleLogout}>
                {" "}
                Logout
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>

          
        </div>
      </div>
    </header>
  );
};

export default Header;
