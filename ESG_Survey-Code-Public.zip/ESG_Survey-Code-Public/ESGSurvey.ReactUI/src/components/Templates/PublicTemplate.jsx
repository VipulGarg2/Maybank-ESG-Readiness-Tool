import React from "react";
import Logo from '../../../public/new-logo.png';

const PublicTemplate = ({ children }) => (
  <div className="layout">
    <div className="public-header">
      <div className="logo">
        <a tabIndex="-1" className="d-block" target="_blank" href="https://www.maybank2u.com.sg/en/myimpact/index.page"> 
        <img src={Logo} />
        
        </a>
     
      </div>
      <h2>ESG Readiness Assessment</h2>
    </div>
    <div className="main">{children}</div>
  </div>
);

export default PublicTemplate;
