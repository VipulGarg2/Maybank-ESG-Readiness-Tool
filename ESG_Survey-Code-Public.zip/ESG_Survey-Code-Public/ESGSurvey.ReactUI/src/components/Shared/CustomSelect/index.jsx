import React from "react";
import Select from "react-select";
import { FormControl, Form } from "react-bootstrap";
import "./style.scss";

const CustomSelect = ({
  id,
  name,
  value,
  label,
  options,
  isRequired,
  controlId,
  ariaDescribedby,
  error,
  className,
  isMulti = false,
  onChange,
  isDisabled,
  isMenuOpen,
  ...props
}) => {
  const customStyles = {
    control: (styles, { isDisabled }) => ({
      ...styles,
      minHeight: 30,
      borderRadius: 4,
      borderWidth: 1,
      borderStyle: "solid",
      borderColor: "#ededf5",
      fontSize: 14,
      fontWeight: 500,
      display: "flex",
      cursor: isDisabled ? "not-allowed" : "default",
      // This is an example: backgroundColor: isDisabled ? 'rgba(206, 217, 224, 0.5)' : 'white'
      color: isDisabled ? "#aaa" : "#4d5875",
    }),

    Input: () => ({
      color: "#4d5875",
    }),
    menuList: () => ({
      color: "#4d5875",
      fontSize: 14,
      fontWeight: 500,
      maxHeight: 300,
      overflowY: "auto",
    }),
  };
  return (
    <>
      <Select
        id={controlId}
        name={name}
        value={value}
        label={label}
        options={options}
        className={"form-select-re"}
        styles={customStyles}
        CommonProps={isMulti}
        placeholder={"select"}
        onChange={onChange}
        isDisabled={isDisabled}
        isClearable={false}
        required={isRequired}
        menuIsOpen={isMenuOpen}
        classNamePrefix="select"
        {...props}
      />
      <Form.Label>
        {label} {isRequired && <span aria-hidden="true">*</span>}
      </Form.Label>
      <Form.Control.Feedback
        type="invalid"
        id={ariaDescribedby}
        aria-live="assertive"
      >
        {error}
      </Form.Control.Feedback>
    </>
  );
};

export default CustomSelect;
