import React, { useState, useEffect } from "react";
import "./style.scss";
import { useSelector } from "react-redux";
import { useMediaQuery } from "../../Shared/MediaQuery";

const StepperTwo = () => {
  const isRowBased = useMediaQuery("(max-width: 500px)");

  const [stepsArray, setStepsArray] = useState([
    { id: 1, label: "Organisation Sector", progress: 0 },
    { id: 2, label: "1. Leadership and Governance", progress: 0 },
    { id: 3, label: "2. Strategy and Objective Setting", progress: 0 },
    { id: 4, label: "3. Risk and Opportunity<br> Management", progress: 0 },
    { id: 5, label: "4. Performance Monitoring<br> and Reporting", progress: 0 },
  ]);
  const progressStep = useSelector((state) => state.que);
  useEffect(() => {
    setProgressBar();
  }, [progressStep]);

  const setProgressBar = () => {
    const stepsArray = [
      { id: 1, label: "Organisation Sector", progress: 0 },
      { id: 2, label: "1. Leadership and Governance", progress: 0 },
      { id: 3, label: "2. Strategy and Objective Setting", progress: 0 },
      { id: 4, label: "3. Risk and Opportunity Management", progress: 0 },
      { id: 5, label: "4. Performance Monitoring and Reporting", progress: 0 },
    ];
    for (let index = 0; index < stepsArray.length; index++) {
      if (index == 0 && progressStep.organizationSectorId > 0) {
        stepsArray[index].progress =
          progressStep.organizationSectorId > 0 ? 100 : 0;
      } else if (index == 0 && progressStep.organizationSectorId == 0) {
        stepsArray[index].progress = 50;
      } else if (index > 0 && progressStep.pillers.length > 0) {
        let pillerIndex = index - 1;
        let isSelectedCount = 0;
        progressStep.pillers[pillerIndex].questions.forEach((queElement) => {
          isSelectedCount += queElement.predefinedAnswers.filter(
            (x) => x.isSelected == true
          ).length;
        });
        stepsArray[index].progress =
          (isSelectedCount /
            progressStep.pillers[pillerIndex].questions.length) *
          100;
      } else {
        stepsArray[index].progress = 0;
      }
    }
    for (let index = 0; index < stepsArray.length; index++) {
      if(stepsArray[index].progress == 100 && index < stepsArray.length - 1  && stepsArray[index + 1].progress == 0){
        stepsArray[index + 1].progress  = 0.1;
      }
    }
    setStepsArray(stepsArray);
  };


  return (
    <>
      <div className="e-tabs">
        {stepsArray.map((item, index) => (
          <>
            <div
              key={index}
              className={`circle ${
                item.progress === 0
                  ? "gray"
                  : item.progress < 100
                  ? "yellow"
                  : "green"
              }`}
              style={{ "--progress": item.progress }}
              data-progress={item.progress}
            >
              <div className="text">{item.label}</div>
            </div>
            {index < stepsArray.length - 1 ? (
              <div
                className={`line  ${
                  stepsArray[index + 1].progress == 0
                    ? "gray"
                    : stepsArray[index + 1].progress < 100
                    ? "yellow"
                    : "green"
                }`}
              >
                <div
                  className="progress-line"
                  style={{
                    backgroundColor: "#00C569",
                    ...(isRowBased
                      ? { width: `${stepsArray[index + 1].progress}%` }
                      : { width: `${stepsArray[index + 1].progress}%` }),
                  }}
                ></div>
              </div>
            ) : (
              ""
            )}
          </>
        ))}
      </div>
    </>
  );
};

export default StepperTwo;
