import React, { useState, useEffect } from "react";
import "./style.scss";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import CustomSelect from "../../Shared/CustomSelect";
import axiosInstance from "../../../store/axiosConfig";
import { setAllQuestions, clearAllQuestions, setGUIDKey } from "../../../store/queSlice";

import Button from "react-bootstrap/Button";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import InputGroup from "react-bootstrap/InputGroup";
import Row from "react-bootstrap/Row";
import * as formik from "formik";
import * as yup from "yup";
import CryptoJS from 'crypto-js';
import { persistor } from "../../../store/store";
import { loadCaptchaEnginge, LoadCanvasTemplate, LoadCanvasTemplateNoReload, validateCaptcha } from 'react-simple-captcha';

const key = import.meta.env.VITE_CRYPTO_KEY;
import { v4 as uuidv4 } from 'uuid';
const BusinessInformation = () => {
  const dispatch = useDispatch();
  const storedAllQuestionResponseDto = useSelector((state) => state.que);
  const [formData, setFormData] = useState({
    businessEntityName: "",
    businessUEN: "",
    companyTurnoverId: 0,
    organizationSectorId: 0,
    nameOfPrimaryContact: "",
    roleOfPrimaryContact: "",
    corporateEmailAddressPrimaryContact: "",
    phoneNumberPrimaryContact: "",
    isExistingMaybankCustomer: false,
    isExploringGreenSolution: false,
    scaleOfTransitionToGreenerSolutions: 0,
    isConsentTermsAccepted: false,
    captchaToken: "",
    pillers: [], // Array of PillarDto objects
  });
  const navigate = useNavigate();
  const [annualTurnoverOption, setAnnualTurnoverOption] = useState([]);
  const [selectedAnnualTurnover, setSelectedAnnualTurnover] = useState(null);
  const [captchaValid, setCaptchaValid] = useState(false);
  const [captchaValue, setCaptchaValue] = useState(null);
  const [isSubmitted,setIsSubmitted]=useState(false);
  useEffect(() => {
    loadCaptchaEnginge(6); 
    setFormData(storedAllQuestionResponseDto);
    getAnnualTurnover();
    if(storedAllQuestionResponseDto != null){
      let count = 0
        var questions = storedAllQuestionResponseDto.pillers.flatMap((x) => x.questions);
        questions.forEach(element => {
          element.predefinedAnswers.forEach((answer) => {
            if(answer.isSelected == true){
              count++;
            }
          });
        });
        if(count != questions.length || count == 0){
          navigate("/esgsurvey/quiz");
        }
    }
    else{
      navigate("/esgsurvey/quiz");
    }
  }, []);

  const getAnnualTurnover = async () => {
    // Fetch the questionnaire list from the API
    const responseAnnualTurnover = await axiosInstance.get(
      "/Master/GetAllCompanyTurnover"
    ); // Adjust API call as per your backend

    setAnnualTurnoverOption(responseAnnualTurnover.data.lstDropdownData);
  };

  
  const encrypt = (text) => {
    const iv = CryptoJS.lib.WordArray.random(16); // Generate a random IV
    const encrypted = CryptoJS.AES.encrypt(text, CryptoJS.enc.Utf8.parse(key), {
        iv: iv,
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
    });

    // Prepend IV to the ciphertext, separated by a colon
    const ivBase64 = iv.toString(CryptoJS.enc.Base64);
    const encryptedBase64 = encrypted.toString();
    
    return ivBase64 + ':' + encryptedBase64; // Format: iv:encrypted
  };


  const handleSubmit = async (e) => {
    setIsSubmitted(true);
    const captchaResult= validateCaptcha(e.captchaValue);
    setCaptchaValid(captchaResult);
    if(captchaResult){
      if(e != null){
        let count = 0
        var questions = e.pillers.flatMap((x) => x.questions);
        questions.forEach(element => {
          element.predefinedAnswers.forEach((answer) => {
            if(answer.isSelected == true){
              count++;
            }
          });
        });
        if(count == questions.length){
          const newGUID = uuidv4();
          e.requestKey = encrypt(newGUID);
          var response = await axiosInstance.post(
            "/QuestionnaireAnswer/SaveQuestionnaireAnswer",
            e
          );

          dispatch(clearAllQuestions());
          dispatch(setGUIDKey(response.data));
          navigate("/esgsurvey/download-report");
        }
        else{
          navigate("/esgsurvey/quiz");
        }
      }
      else{
        navigate("/esgsurvey/quiz");
      }
    }
   
    
  };

  const { Formik } = formik;

  const schema = yup.object().shape({
    businessEntityName: yup.string().required(),
    companyTurnoverId: yup.number().required().moreThan(0),
    nameOfPrimaryContact: yup.string().required(),
    roleOfPrimaryContact: yup.string().required(),
    corporateEmailAddressPrimaryContact: yup.string()
    .required("Email address is required")
    .email("Please enter a valid email address"),
    phoneNumberPrimaryContact: yup
    .string()
    .required("Phone number is required")
    .matches(/^[\d()\-+ ]+$/, "Phone number can only contain digits, spaces, parentheses, hyphens, and plus signs"), // Updated regex to allow specific characters
    isConsentTermsAccepted: yup
      .bool()
      .required()
      .oneOf([true], "Terms and Conditions must be accepted"),
      captchaValue:yup.string().required(),
  });


  return (
    <>
      <Formik
        validationSchema={schema}
        onSubmit={handleSubmit}
        initialValues={storedAllQuestionResponseDto}
      >
        {({
          handleSubmit,
          handleChange,
          handleBlur,
          values,
          touched,
          errors,
          isValid, dirty 
        }) => (
          <div className="container white-box d-block m-h-100 mt-md-0">
            <h1>Company Details</h1>
            <p className="e-step-note">
              {/* Just one more step. Complete this form to get your customised ESG
              Readiness Assessment Report. */}
             You're just
              one step away from receiving your personalised ESG Readiness Assessment Report.<br></br>
              Please provide your business information below. Once submitted,
              you will be able to download your customised report, and a copy
              will be sent directly to your email address. Complete the form to
              take your first step towards a more sustainable future!
            </p>
            <p className="e-note">
              Fields marked with <span>*</span> are mandatory.
            </p>
            <Form noValidate onSubmit={handleSubmit} className="forms_controls">
              <Row>
                <Col md="6" lg="6">
                  <Form.Group
                    controlId="businessEntityName"
                    className="form-floating"
                  >
                    <Form.Control
                      type="text"
                      name="businessEntityName"
                      placeholder="Company Name"
                      value={values.businessEntityName}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isInvalid={touched.businessEntityName && !!errors.businessEntityName}
                    />
                    <Form.Label>
                      Company Name <span>*</span>
                    </Form.Label>

                    <Form.Control.Feedback type="invalid">
                      Company Name is required
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>
                <Col md="6" lg="6">
                  <Form.Group
                    controlId="nameOfPrimaryContact"
                    className="form-floating"
                  >
                    <Form.Control
                      type="text"
                      name="nameOfPrimaryContact"
                      placeholder="Contact Person"
                      value={values.nameOfPrimaryContact}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isInvalid={touched.nameOfPrimaryContact && !!errors.nameOfPrimaryContact}
                    />
                    <Form.Label>
                      Contact Person <span>*</span>
                    </Form.Label>

                    <Form.Control.Feedback type="invalid">
                      Contact Person is required
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>
                <Col md="6" lg="6" className="d-select">
                  <Form.Group
                    controlId="companyTurnoverId"
                    className="form-floating"
                  >
                    <Form.Control
                      required
                      as="select"
                      type="select"
                      name="companyTurnoverId"
                      value={values.companyTurnoverId}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isInvalid={
                        touched.companyTurnoverId && !!errors.companyTurnoverId
                      }
                    >
                      <option value="0">Select Annual Turnover</option>
                      {annualTurnoverOption.map((turnover) => (
                        <option key={turnover.value} value={turnover.value}>
                          {turnover.label}
                        </option>
                      ))}
                    </Form.Control>
                    <Form.Label>
                      Annual Turnover <span>*</span>
                    </Form.Label>
                    <Form.Control.Feedback type="invalid">
                      Annual Turnover is required
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>
                <Col md="6" lg="6">
                  <Form.Group
                    controlId="roleOfPrimaryContact"
                    className="form-floating"
                  >
                    <Form.Control
                      type="text"
                      name="roleOfPrimaryContact"
                      placeholder="Job Title"
                      value={values.roleOfPrimaryContact}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isInvalid={touched.roleOfPrimaryContact && !!errors.roleOfPrimaryContact}
                    />
                    <Form.Label>
                      Job Title <span>*</span>
                    </Form.Label>
                    <Form.Control.Feedback type="invalid">
                      Job Title is required
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>
                <Col md="6" lg="6">
                  <Form.Group
                    className="form-floating"
                    md="4"
                    controlId="corporateEmailAddressPrimaryContact"
                  >
                    <Form.Control
                      type="text"
                      name="corporateEmailAddressPrimaryContact"
                      placeholder="Email"
                      value={values.corporateEmailAddressPrimaryContact}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isInvalid={touched.corporateEmailAddressPrimaryContact && !!errors.corporateEmailAddressPrimaryContact}
                    />
                    {/* {JSON.stringify(errors)} */}
                    <Form.Label>
                      Email <span>*</span>
                    </Form.Label>
                    <Form.Control.Feedback type="invalid">
                      {errors?.corporateEmailAddressPrimaryContact}
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>
                <Col md="6" lg="6">
                  <Form.Group
                    controlId="phoneNumberPrimaryContact"
                    className="form-floating"
                  >
                    <Form.Control
                      type="text"
                      name="phoneNumberPrimaryContact"
                      placeholder="Contact Number"
                      value={values.phoneNumberPrimaryContact}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isInvalid={touched.phoneNumberPrimaryContact && !!errors.phoneNumberPrimaryContact}
                    />
                    <Form.Label>
                      Contact Number <span>*</span>
                    </Form.Label>

                    <Form.Control.Feedback type="invalid">
                      {errors?.phoneNumberPrimaryContact}
                    </Form.Control.Feedback>
                  </Form.Group>
                </Col>
              </Row>
              <Form.Group className="mb-3">
                <Form.Label>Are you an existing Maybank Customer? <span className="e-note"><span>*</span></span></Form.Label>
                <div>
                  <Form.Check
                    inline
                    label="Yes"
                    name="isExistingMaybankCustomer" // Same name for both options
                    type="radio"
                    id="isExistingMaybankCustomerYes"
                    value={true} // Assign the value true for "Yes"
                    checked={values.isExistingMaybankCustomer === true}
                    onChange={(e) => handleChange({
                      target: {
                        name: 'isExistingMaybankCustomer',
                        value: e.target.value === 'true' // Convert the value to boolean
                      }
                    })}
                    onBlur={handleBlur}
                    isInvalid={touched.isExistingMaybankCustomer && !!errors.isExistingMaybankCustomer}
                    feedback={errors.isExistingMaybankCustomer}
                    feedbackType="invalid"
                  />
                  <Form.Check
                    inline
                    label="No"
                    name="isExistingMaybankCustomer" // Same name for both options
                    type="radio"
                    id="isExistingMaybankCustomerNo"
                    value={false} // Assign the value false for "No"
                    checked={values.isExistingMaybankCustomer === false}
                    onChange={(e) => handleChange({
                      target: {
                        name: 'isExistingMaybankCustomer',
                        value: e.target.value === 'true' // Convert the value to boolean
                      }
                    })}
                    onBlur={handleBlur}
                    isInvalid={touched.isExistingMaybankCustomer && !!errors.isExistingMaybankCustomer}
                    feedback={errors.isExistingMaybankCustomer}
                    feedbackType="invalid"
                  />
                </div>
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Check
                  required
                  name="isConsentTermsAccepted"
                  label="I agree to Terms and Conditions"
                  onChange={handleChange}
                  onBlur={handleBlur}
                  isInvalid={touched.isConsentTermsAccepted && !!errors.isConsentTermsAccepted}
                  feedback={errors.isConsentTermsAccepted}
                  value={values.isConsentTermsAccepted}
                  feedbackType="invalid"
                  id="isConsentTermsAccepted"
                />
                <p className="tc-note">
                 By clicking the "Submit" button, I/we consent to Maybank collecting and using the information provided in this form to enable Maybank to contact me/us by phone or email to share the Maybank ESG Readiness Assessment Report and additional information on their products and services that may be relevant to the company. Maybank refers to Maybank Singapore Limited and its branches, subsidiaries, affiliates, representative offices, and related entities.
                </p>
              </Form.Group>
              <div className="col-md-12 reload-captcha">
              <LoadCanvasTemplate reloadText="Reload" />
              <div className="col mt-3">
              <Col md="4" lg="4">
                  <Form.Group
                    controlId="captchaValue"
                    className="form-floating"
                  >
                    <Form.Control
                      type="text"
                      name="captchaValue"
                      placeholder="Enter Captcha Value"
                      value={values.captchaValue}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      isInvalid={touched.captchaValue && !!errors.captchaValue}
                    />
                    <Form.Label>
                      Captcha Value <span>*</span>
                    </Form.Label>
                    <Form.Control.Feedback type="invalid">
                      Captcha is required
                    </Form.Control.Feedback>
                     {!captchaValid && isSubmitted && (
                      <div className="text-danger mt-2">Invalid captcha value. Please try again.</div>
                    )}
                  </Form.Group>
                </Col>
                   </div>
              </div>
              <div className="col-md-12 text-center">
                <button
                  type="button"
                  onClick={handleSubmit}
                  className="submit-button" disabled={
                    !(isValid && dirty)
                  }
                >
                  Submit
                </button>
              </div>
            </Form>
          </div>
        )}
      </Formik>
    </>
  );
};

export default BusinessInformation;
