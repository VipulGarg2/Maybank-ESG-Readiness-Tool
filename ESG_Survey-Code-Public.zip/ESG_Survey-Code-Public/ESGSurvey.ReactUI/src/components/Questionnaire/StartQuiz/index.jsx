import React, { useState, useEffect } from "react";
import { useDispatch } from "react-redux";
import Logo from "../../../../public/new-logo.jpg";
import "./style.scss";
import { Link } from "react-router-dom";
import store from "../../../store/store"; 
import { hideLoader } from "../../../store/loaderSlice"; 

const StartQuiz = () => {
  useEffect(() => {
    store.dispatch(hideLoader());
  }, []);

  return (
  <>
    <div className="container h-100 white-box">
      <div className="e-quiz-inner-side animated-btn">
        <div className="logo">
          <img src={Logo} />
        </div>
        <h1 className="text-center">
          Receive your personalised<br /> report
           in just 5 minutes.
        </h1>
        <p>
          Fill out this brief questionnaire to receive clear,
          <br /> actionable steps for your sustainability journey.
        </p>
        <h4>Participate in the quiz.</h4>

        <Link to="/quiz" className="round">
          <div id="cta">
            <span className="arrow primera next "></span>
            <span className="arrow segunda next "></span>
          </div>
        </Link>
      </div>
    </div>
  </>
 );
};
export default StartQuiz;
