import React from "react";
import OutlineImg from "../../../../public/check-outline.svg";
import EditImg from "../../../../public/edit-outline.svg";
import DownloadImg from "../../../../public/download-outline.svg";
import "./style.scss";
import { Link } from "react-router-dom";

const Steps = ({ children }) => (
  <>
   <div className="container h-100 white-box steps-page">
      <div className="animated-btn">
        <div id="quiz-steps">
          <div className="quiz-step one">
            <span className="quiz-step-icon">
              <img src={OutlineImg} />
            </span>
            <span className="quiz-step-label">
              Answers all
              <br /> questions
            </span>
          </div>
          <div className="quiz-step-line">
            <i className="bi bi-chevron-right"></i>
          </div>
          <div className="quiz-step two">
            <span className="quiz-step-icon">
              <img src={EditImg} />
            </span>
            <span className="quiz-step-label">
              Add Business
              <br /> Details
            </span>
          </div>
          <div className="quiz-step-line">
            <i className="bi bi-chevron-right"></i>
          </div>
          <div className="quiz-step three">
            <span className="quiz-step-icon">
              <img src={DownloadImg} />
            </span>
            <span className="quiz-step-label">
              Receive
              <br /> Customise Report
            </span>
          </div>
        </div>
        <h1 className="text-center">You're very close!</h1>
        <p className="text">
          Provide your business information to receive a ESG Readiness
          <br /> Assessment Report customised for you to Download & Email will be sent to your email address.
        </p>
        <h4>Enter your business information.</h4>

        <Link to="/esgsurvey/business-information" className="round">
          <div id="cta">
            <span className="arrow primera next "></span>
            <span className="arrow segunda next "></span>
          </div>
        </Link>
      </div>
    </div>
  </>
);

export default Steps;
