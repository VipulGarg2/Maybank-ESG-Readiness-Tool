import React, { useState, useEffect } from "react";
import {
  CircularProgressbar,
  CircularProgressbarWithChildren,
  buildStyles
} from "react-circular-progressbar";
import axiosInstance from "../../../store/axiosConfig";
import { useDispatch, useSelector } from "react-redux";
import "react-circular-progressbar/dist/styles.css";
import ImageOne from '../../../../public/d-img1.jpg';
import LevelImgOne from '../../../../public/users.svg';
import LevelImgTwo from '../../../../public/leaves.svg';
import LevelImgThree from '../../../../public/risk.svg';
import LevelImgFour from '../../../../public/report.svg';
import Img from "../../../../public/download-outline.svg";
import { Link } from "react-router-dom";
import "./style.scss";
const apiurl = import.meta.env.VITE_API_BASE_URL;
function CustomContentProgressbar(props) {
  const { children, ...otherProps } = props;

  return (
    <div
      style={{
        position: "relative",
        width: "100%",
        height: "100%"
      }}
    >
      <div style={{ position: "absolute" }}>
        <CircularProgressbar {...otherProps} />
      </div>
      <div
        style={{
          position: "absolute",
          height: "100%",
          width: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
        {props.children}
      </div>
    </div>
  );
}

const DownloadReport = ({ children }) => {
  const [data, setData] = useState();
  const questionData = useSelector((state) => state.que);
  useEffect(() => {
    getReportsData();
  }, []);

  const getReportsData = async () => {
    // Fetch the questionnaire list from the API
    const reportData = await axiosInstance.get(`Master/GetEsgReportSummary?guid=${questionData.GUID}`);
    if(reportData?.data){
      reportData.data.surveyScore = Number(((reportData.data.surveyScore||0) * 100)).toFixed(2)
      reportData.data.pillarReportList.map(e => {
        e.score = roundUpNumber(Number(((e.score||0)*100)).toFixed(2));
        return e;
      })
      setData(reportData.data)
    }
  };
  const roundUpNumber = (number) => {
    const num = parseFloat(number);
    if (!isNaN(num)) {
      return Math.ceil(num);
    }
    return '';
  };
  const getImages = (index) => {
    if(index===0){
      return LevelImgOne;
    } else if(index===1){
      return LevelImgTwo;
    } else if(index===2){
      return LevelImgThree;
    } else if(index===3){
      return LevelImgFour;
    } else {
      return LevelImgOne;
    }

  }

  const handleDownload = async () => {
    try {
        const response = await axiosInstance.get(`QuestionnaireAnswer/GetEsgMaturityAssessmentReport?guid=${questionData.GUID}`, {
            responseType: 'blob' // Important: Set the response type to 'blob'
        });

        // Check if the response status is OK (200)
        if (response.status === 200) { // Use 'response.status' instead of 'response.ok'
            const blob = new Blob([response.data], { type: 'application/pdf' }); // Create a Blob from the response data
            const url = window.URL.createObjectURL(blob); // Create a URL for the Blob
            const link = document.createElement('a'); // Create an anchor element
            link.href = url; // Set the URL as the href of the link
            link.setAttribute('download', `ESGReadinessAssessmentReport.pdf`); // Set the download attribute with the desired file name
            document.body.appendChild(link); // Append the link to the body
            link.click(); // Programmatically click the link to trigger the download
            link.parentNode.removeChild(link); // Remove the link from the document
            window.URL.revokeObjectURL(url); // Clean up the URL object
        } else {
            console.error('File download failed:', response.status);
        }
    } catch (error) {
        console.error('Error during file download:', error); // Catch any errors during the request
    }
};
  // const percentage = 40;
  return (
    <div className="container h-100 mx-height white-box download-container">
      <div className="download-inner-side animated-btn">
        <div className="d-image">
          {/* <h4>ESG Readiness Report</h4> */}
          <div className="image-wrap">
          <div>
          
            <img src={ImageOne} />
          </div>
            
          </div>
        </div>
        <div className="d-score">
      
        <div className="d-flex upper-score">
          <div>
        <h4 className="text-center">Overall Level</h4>
        <div className="percentage-circle percentage-circle2">
        <CircularProgressbarWithChildren
          styles={buildStyles({
            pathColor: "#ffc600",
          })} value={data?.surveyScore}>       
        <div className="percentage-number">
          <strong>{data?.surveyScore}</strong>%
        </div>
      </CircularProgressbarWithChildren>
      </div>
      </div>
      <div className="title-h4">
            {data?.surveyMaturityLevel == 'Developing' ? <h4> {data?.surveyMaturityLevel}</h4> :''}
            {data?.surveyMaturityLevel == 'Evolving' ? <h4>{data?.surveyMaturityLevel}</h4> :''}
            {data?.surveyMaturityLevel == 'Trailblazing' ? <h4>{data?.surveyMaturityLevel}</h4> :''}

            {data?.surveyMaturityLevel == 'Developing' ? <p className="score-text">Great progress! You are in the Developing stage. Your company is in the early stages of aligning with ISSB standards and has significant room for growth in its sustainability practices. This is an ideal time to adopt a comprehensive sustainability strategy, strength and improve transparency, to build a stronger foundation for future progress.</p> :''}
            {data?.surveyMaturityLevel == 'Evolving' ? <p className="score-text">Remarkable! You are in the Evolving stage. Your company partially aligns with ISSB standards by implementing key ESG practises and reporting relevant metrics. To progress further, you should address gaps in completeness and consistency, fully integrate sustainability into your business model and long-term planning, and establish clear, measurable, and achievable targets.</p> :''}
            {data?.surveyMaturityLevel == 'Trailblazing' ? <p className="score-text">Outstanding! You are in the Trailblazing stage. Your company demonstrates a strong commitment to mitigating climate change, with sustainability fully integrated into its governance, strategy, and risk management. To sustain this momentum and solidify your leading market position, you should promote sustainability on a broader scale and amplify your impact by pursuing industry collaborations for innovative sustainability projects.</p> :''}
      </div>
           
      </div>
       <div className="level-boxes">
        {data?.pillarReportList?.map((result,index) => {
          return(
            <div className="outer-level">
          <div className="level">
            <div className="level-img">
              <img src={getImages(index)} />
            </div>
            <p className="title">{result?.pillarName}</p>
            <p className="sub-title">{result?.maturityLevel}</p>
          </div>
          <div className="all-scores">
          <div className="percentage-circle">
            <CircularProgressbarWithChildren styles={buildStyles({
                pathColor: "#ffc600",
              })} value={result?.score}>       
            <div className="percentage-number">
              <strong>{result?.score}%</strong>
            </div>
          </CircularProgressbarWithChildren>
          </div>
          </div>
          </div>
          )
        })}
        
       </div>

       
       <div className="d-flex justify-content-center pt-md-4 pb-2">
       <Link onClick={handleDownload} className="buttonDownload">
          <img src={Img} /> Download Report
         </Link>
         </div>
        </div>
      </div>
    </div>
  );
}

export default DownloadReport;


