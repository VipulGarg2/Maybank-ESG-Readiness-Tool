import React, { useState, useEffect } from "react";
import { useDispatch } from "react-redux";
import { Carousel, Button ,Tooltip, OverlayTrigger} from "react-bootstrap";
import CustomSelect from "../../Shared/CustomSelect";
import pillar0 from "../../../../public/pillar0.png";
import pillar1 from "../../../../public/pillar1.png";
import pillar2 from "../../../../public/pillar2.png";
import pillar3 from "../../../../public/pillar3.png";
import pillar4 from "../../../../public/pillar4.png";

import "./style.scss";
import axiosInstance from "../../../store/axiosConfig";
import { setAllQuestions } from "../../../store/queSlice";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import StepperTwo from "../StepperTwo";

const Quiz = () => {
  const dispatch = useDispatch();
  const [index, setIndex] = useState(0);
  const [disableNextButton, setDisableNextButton] = useState(0);
  const [disablePrevButton, setDisablePrevButton] = useState(0);
  const [pillarName, setPillarName] = useState("Organisation Sector");
  const [allQuestionResponseDto, setAllQuestionResponseDto] = useState(null);
  const [allSector, setAllSector] = useState([]);
  const [selectedSector, setSelectedSector] = useState(null); // Default value
  const storedAllQuestionResponseDto = useSelector((state) => state.que);
  const [isSubmitting, setIsSubmitting] = useState(false);
 

  const navigate = useNavigate();

  useEffect(() => {
    getAllQuestionResponseDto();
    if(!storedAllQuestionResponseDto.organizationSectorId){
      setDisableNextButton(true)
    }
    if(index === 0){
      setDisablePrevButton(true)
    }
  }, []);

  

  

  const getAllQuestionResponseDto = async () => {
    // Fetch the questionnaire list from the API
    const responseSector = await axiosInstance.get(
      "/Master/GetAllOrganizationUnGroupSector"
    ); // Adjust API call as per your backend

    setAllSector(responseSector.data.lstDropdownData);
    if (
      storedAllQuestionResponseDto &&
      storedAllQuestionResponseDto.organizationSectorId > 0 &&
      responseSector.data &&
      responseSector.data.lstDropdownData &&
      responseSector.data.lstDropdownData
        //.flatMap((x) => x.options)
        .filter(
          (x) => x.value == storedAllQuestionResponseDto.organizationSectorId
        ).length > 0
    ) {
      const updatedSelectedOption = {
        value: storedAllQuestionResponseDto.organizationSectorId,
        label: responseSector.data.lstDropdownData
          //.flatMap((x) => x.options)
          .filter(
            (x) => x.value == storedAllQuestionResponseDto.organizationSectorId
          )[0].label,
      };
      setSelectedSector(updatedSelectedOption);
    }

    const response = await axiosInstance.get("/Master/GetAllQuestion"); // Adjust API call as per your backend
    const updatedResponse = response.data;
    if (
      storedAllQuestionResponseDto &&
      updatedResponse &&
      updatedResponse.pillers
    ) {
      updatedResponse.organizationSectorId =
        storedAllQuestionResponseDto.organizationSectorId;
      updatedResponse.pillers
        .flatMap((x) => x.questions)
        .forEach((question) => {
          const lstStoredQuestion = storedAllQuestionResponseDto.pillers
            .flatMap((x) => x.questions)
            .filter((x) => x.questionsId == question.questionsId);
          if (lstStoredQuestion.length > 0) {
            lstStoredQuestion[0].predefinedAnswers.forEach((answer) => {
              const lstCurrentAnswer = question.predefinedAnswers.filter(
                (x) => x.answerText == answer.answerText
              );
              if (lstCurrentAnswer.length > 0) {
                lstCurrentAnswer[0].isSelected = answer.isSelected;
              }
            });
          }
        });
    }

    setAllQuestionResponseDto(updatedResponse);
  };

  const handleSelect = (selectedIndex, e) => {
    setIndex(selectedIndex);
    const questions = allQuestionResponseDto.pillers.flatMap(
      (x) => x.questions
    );
    if (questions.length > 0) {
      setCurrentPillarName(questions[selectedIndex].questionsId);
    }
  };

  const onPrevClick = () => {
    let previousSelectedIndex=0;
    if (index !== 0) {
      
      const questions = allQuestionResponseDto.pillers.flatMap((x) => x.questions);
        //[index - 1].predefinedAnswers.filter((x) => x.isSelected);
      if (questions && questions.length > 0) {
        if (index > 0) {
          const answerOnQuestion =  questions[index - 2]?.predefinedAnswers?.filter(e => e.isSelected);
          setIndex(index - 1);
          previousSelectedIndex = index - 2;
          if(!!answerOnQuestion && answerOnQuestion.length>0){
            setDisableNextButton(false)
          } else {
            if(!answerOnQuestion){
              setDisablePrevButton(true)
            } else {
              setDisableNextButton(true)
            }
            if(previousSelectedIndex == -1 && selectedSector.value > 0){
              setDisableNextButton(false);
            }
            
          }
          if (questions.length > 0) {
            if (index - 1 == 0) {
              setPillarName("Organisation Sector");
            } else {
              setCurrentPillarName(questions[previousSelectedIndex].questionsId);
            }
          }
        }
      }
    } else {
      if(storedAllQuestionResponseDto.organizationSectorId){
        setDisableNextButton(false)
      }
      setDisablePrevButton(true);
    }
  };
  const onNextClick = () => {
    let nextSelectedIndex=0;
    var totalSurveyCount = allQuestionResponseDto.pillers.flatMap(
      (x) => x.questions
    ).length;
    if (index < totalSurveyCount) {
      nextSelectedIndex = index + 1;
      setIndex(index + 1);
      const questions = allQuestionResponseDto.pillers.flatMap(
        (x) => x.questions
      );
      if(questions[index]){
       const answerOnQuestion =  questions[index].predefinedAnswers.filter(e => e.isSelected);
        if(answerOnQuestion.length>0){
          setDisableNextButton(false)
        } else {
          setDisableNextButton(true)
        }
      }
      if (questions.length > 0 && index > 0) {
        setCurrentPillarName(questions[index].questionsId);
      }
      else{
        setCurrentPillarName(questions[nextSelectedIndex].questionsId);
      }
    }
    setDisablePrevButton(false);
    if (index == totalSurveyCount) {
      navigate("/esgsurvey/business-information");
    }
  };

  const setCurrentPillarName = (questionsId) => {
    allQuestionResponseDto.pillers.forEach((piller) => {
      piller.questions.forEach((que) => {
        if (questionsId == que.questionsId) {
          setPillarName(piller.pillarName);
        }
      });
    });
  };

  const onUpdateProgress = () => {};
  const updateCurrentAnswer = async (questionId, answerText, index, questionIndex, pillerIndex) => {
    if (isSubmitting) return; // Prevents multiple clicks while submitting
     setIsSubmitting(true);
     setTimeout( async () => {
      try {
        const questionList = allQuestionResponseDto
        if (questionList.pillers[pillerIndex].questions.length > 0) {
          questionList.pillers[pillerIndex].questions[questionIndex].predefinedAnswers.map((answer) => {
            answer.isSelected = false;
            return answer;
          });
          if (questionList.pillers[pillerIndex].questions[questionIndex].predefinedAnswers[index]) {
            questionList.pillers[pillerIndex].questions[questionIndex].predefinedAnswers[index].isSelected = true
          }
        }
    
        // Dispatching updated questions list and setting the state asynchronously
        await Promise.all([
          dispatch(setAllQuestions(questionList)),
          setAllQuestionResponseDto(questionList)
        ]);
          onNextClick();
      } catch (error) {
        console.error("Error updating answer:", error);
      } finally {
        setTimeout(() => {
        setIsSubmitting(false); // Reset the flag after completion
        }, 400);
      }
     }, 400);
     
    
  };

  const handleSectorSelectChange = (selectedOption) => {
    setSelectedSector(selectedOption);
    allQuestionResponseDto.organizationSectorId = selectedOption
      ? selectedOption.value
      : 0;
    dispatch(setAllQuestions(allQuestionResponseDto));
    setAllQuestionResponseDto(allQuestionResponseDto);
    setDisableNextButton(false)
  };

  const [steps, setSteps] = useState([]);

  const handleStepsUpdate = (updatedSteps) => {
    setSteps(updatedSteps);
  };


 

  return (
    <>
    <div className="container h-100 mx-height q-h-100 white-box">
        <div className="owl-slider-container">
          <div className="owl-tabs-container">
          <StepperTwo onStepsUpdate={handleStepsUpdate} />
          </div>

          <form className="owl-full-page-slider">
          
              <div className="box-left">
              {allQuestionResponseDto && (
              <Carousel
                activeIndex={index}
                onSelect={handleSelect}
                indicators={false}
                controls={false}
                interval={null}
                touch={false}
                touchEnabled={false}
              >
                <Carousel.Item>
                  <div className="slide-content">
                    <div className="left-container">
                    <div className="step-name">Organisation Sector</div>

                      <h2>
                      In which sector does your business operate?
                      </h2>
                    </div>
                    <div className="form_controls w-75 select-style">
                      <div className="form-floating">
                        <CustomSelect
                          label="Select Organisation/Company Sector"
                          controlId={"organizationSectorId"}
                          name={"organizationSectorName"}
                          closeMenuOnSelect
                          value={selectedSector}
                          options={allSector}
                          menuPortalTarget={document.querySelector("body")}
                          onChange={handleSectorSelectChange}
                        />
                      </div>
                    </div>
                  </div>
                </Carousel.Item>

                {allQuestionResponseDto.pillers.map((pillar,pillerIndex) =>
                  pillar.questions.map((question,questionIndex) => (
                    <Carousel.Item key={question.questionsId}>
                      <div className="slide-content">
                        <div className="left-container">
                        <div className="step-name"><span className="qn">{pillerIndex + 1}.{questionIndex + 1}</span> {pillarName}</div>
                      <h2> {question.questionsName}
                          {question.guideline != '' && 
                          <OverlayTrigger
                        placement="bottom"
                        overlay={
                          <Tooltip className="mytooltip" id="button-tooltip-2" style={{position:"fixed"}}>
                            {question.guideline}
                          </Tooltip>
                        }
                      >
                        <span className="question-info">
                        <i class="bi bi-info"></i>
                        </span>
                        
                      </OverlayTrigger>}</h2> 
                          
                        </div>
                        
                        <div className="right-container">
                          {question.predefinedAnswers.map((answer,index) =>
                            answer.answerText == "Yes" ? (
                              <button
                                disabled={isSubmitting}
                                type="button"
                                onClick={() => {
                                  if(!isSubmitting){
                                    updateCurrentAnswer(
                                      question.questionsId,
                                      answer.answerText,
                                      index,
                                      questionIndex,
                                      pillerIndex
                                    )
                                  }
                                }
                                  
                                }
                                className={`yes-btn yn-button  ${
                                  answer.isSelected ? "yn-button-green" : ""
                                }`}
                              >
                                {answer.answerText}
                              </button>
                            ) : (
                              <button
                                disabled={isSubmitting}
                                type="button"
                                onClick={() =>{
                                  if(!isSubmitting){
                                    updateCurrentAnswer(
                                      question.questionsId,
                                      answer.answerText,
                                      index,
                                      questionIndex,
                                      pillerIndex
                                    )
                                  }
                                }
                                  
                                }
                                className={`no-btn yn-button  ${
                                  answer.isSelected ? "yn-button-green" : ""
                                }`}
                              >
                                {answer.answerText}
                              </button>
                            )
                          )}
                        </div>
                      </div>
                    </Carousel.Item>
                  ))
                )}
              </Carousel>
            )}

            <div className="center-line" key={disableNextButton}>
              <Button className="prev-arrow arrow" style={{display:disablePrevButton?"none":"flex", borderColor:disablePrevButton?"grey":"#222" ,background:disablePrevButton?"grey":"#222"}} onClick={onPrevClick}>
                <i className="bi bi-chevron-left"></i>
              </Button>
             
              <Button key={disableNextButton} className={`next-arrow arrow`} style={{display:disableNextButton?"none":"flex", borderColor:disableNextButton?"grey":"#222" ,background:disableNextButton?"grey":"#222"}} onClick={onNextClick} disabled={disableNextButton}>
                <i className="bi bi-chevron-right"></i></Button>
            </div>
              </div>
              <div className="box-right">
                  <div className="image-gif">

                  { pillarName == 'Organisation Sector' && <img
                     src={pillar0} 
                     className="m-auto animated-image"
                   />}
                   { pillarName == 'Leadership and Governance' && <img
                     src={pillar1} 
                     className="m-auto animated-image"
                   />}
                    { pillarName == 'Strategy and Objective Setting' && <img
                     src={pillar2} 
                     className="m-auto animated-image"
                   />}
                   { pillarName == 'Risk and Opportunity Management' && <img
                     src={pillar3} 
                     className="m-auto animated-image"
                   />}
                   { pillarName == 'Performance Monitoring and Reporting' && <img
                     src={pillar4} 
                     className="m-auto animated-image"
                   />}
                
                </div>
              </div>

          </form>
        </div>
    </div>
    </>
  );
};

export default Quiz;
