import React from "react";
import PublicTemplate from "../Templates/PublicTemplate";
import DownloadReport from "../Questionnaire/DownloadReport";

const DownloadReportPage = () => (
  <PublicTemplate>
    <DownloadReport />
  </PublicTemplate>
);
export default DownloadReportPage;
