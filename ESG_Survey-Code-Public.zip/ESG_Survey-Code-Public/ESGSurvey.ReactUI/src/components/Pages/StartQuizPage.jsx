import React from "react";
import PublicTemplate from "../Templates/PublicTemplate";
import StartQuiz from "../Questionnaire/StartQuiz";

const StartQuizPage = () => (
  <PublicTemplate>
    <StartQuiz />
  </PublicTemplate>
);
export default StartQuizPage;
