import React from "react";
import PublicTemplate from "../Templates/PublicTemplate";
import BusinessInformation from "../Questionnaire/BusinessInformation";

const BusinessInformationPage = () => (
  <PublicTemplate>
    <BusinessInformation />
  </PublicTemplate>
);
export default BusinessInformationPage;
