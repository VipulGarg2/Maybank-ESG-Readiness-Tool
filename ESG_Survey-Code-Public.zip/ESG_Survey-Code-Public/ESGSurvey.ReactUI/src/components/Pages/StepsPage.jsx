import React from "react";
import PublicTemplate from "../Templates/PublicTemplate";
import Steps from "../Questionnaire/Steps";

const StepsPage = () => (
  <PublicTemplate>
    <Steps />
  </PublicTemplate>
);
export default StepsPage;
