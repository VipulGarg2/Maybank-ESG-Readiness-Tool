import React,{ useState, useEffect }  from "react";
import PublicTemplate from "../Templates/PublicTemplate";
import Quiz from "../Questionnaire/Quiz";
import { Carousel, Button ,Tooltip, OverlayTrigger, Modal} from "react-bootstrap";
import { clearAllQuestions } from "../../store/queSlice";
import { useDispatch, useSelector } from "react-redux";

const QuizPage = () => {
  const [showModal, setShowModal] = useState(false); // Modal visibility
  const storedAllQuestionResponseDto = useSelector((state) => state.que);
  const dispatch = useDispatch();
  useEffect(() => {
    // Show confirmation modal when the page loads
    if(!!storedAllQuestionResponseDto && storedAllQuestionResponseDto.organizationSectorId){
    setShowModal(true);
    }
  }, []);
  const handleCancel = () => {
    dispatch(clearAllQuestions());
    setTimeout(() => {
      setShowModal(false); // Close modal on cancel
    // You can clear session data here or redirect
    }, 400);
  };
   // Handle modal confirmation
   const handleConfirm = () => {
    setShowModal(false); // Close modal on confirmation
    // Continue with existing session data
  };
  return(<PublicTemplate>
    <Quiz key={showModal}/>
    <Modal show={showModal} backdrop="static" keyboard={false} centered className="quiz-modal">
      <Modal.Body>
        <div className="warning-text"> <i class="bi bi-exclamation-triangle"></i> <h5>Unsubmitted Survey Found!</h5></div>
       <p className="text-center">Are you sure you want to continue with unsubmitted survey data?</p>
       <div className="mod-buttons">
       <Button variant="light" onClick={handleCancel}>
          No
        </Button>
        <Button variant="warning" onClick={handleConfirm}>
          Yes
        </Button>
       </div>
      </Modal.Body>
 
    </Modal> 
  </PublicTemplate>)
}
export default QuizPage;
