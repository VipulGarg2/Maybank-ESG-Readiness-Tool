import React from 'react';
import './loader.css'; // Add your loader styles here

const LoaderDiv = () => {
  return (
    <div className="loader-overlay">
      <div className="loader"></div>
    </div>
  );
};

export default LoaderDiv;