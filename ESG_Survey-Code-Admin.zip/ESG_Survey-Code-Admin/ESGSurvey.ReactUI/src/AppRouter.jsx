import React, { Suspense } from "react";
import { BrowserRouter as Router, Route, Routes, Navigate } from "react-router-dom";
import ProtectedRoute from "./ProtectedRoute";
import { useSelector } from 'react-redux';
const Login = React.lazy(()=> import("./components/Authentication/login"));
const ForgotPassword = React.lazy(()=> import( "./components/Authentication/forgot-password"));
const ResetPassword = React.lazy(()=> import("./components/Authentication/reset-password"));
import AdminSurveyPage from "./components/Pages/AdminSurveyPage"
import AdminQuestionnairePage from "./components/Pages/AdminQuestionnairePage"
import ProductListPage from "./components/Pages/ProductListPage"
const ExternalLinkPage = React.lazy(()=> import('./components/Pages/ExternalLinkPage'))

function AppRouter() {
    const isLoggedIn = useSelector((state) => state.auth.isLoggedIn); 
 
  return (
      <Suspense fallback={<></>}>
      <Routes>
          <Route path="/ESGPortal" element={<ProtectedRoute element={isLoggedIn ? <Navigate to="/ESGPortal/admin-surveys" /> : <Login />} />} />
          <Route path="/ESGPortal/forgot-password" element={isLoggedIn ? <Navigate to="/ESGPortal/admin-surveys" /> : <ForgotPassword />} />
          <Route path="/ESGPortal/login" element={isLoggedIn ? <Navigate to="/ESGPortal/admin-surveys" /> : <Login />} />
          <Route path="/ESGPortal/reset-password" element={<ResetPassword />} />
          <Route
              path="/ESGPortal/admin-surveys"
              element={<ProtectedRoute element={<AdminSurveyPage />} />} />
           <Route
              path="/ESGPortal/products"
              element={<ProtectedRoute element={<ProductListPage />} />} />   
            <Route
                path="/ESGPortal/external-link"
                element={<ProtectedRoute element={<ExternalLinkPage />} />} />   
          <Route
              path="/ESGPortal/admin-questionnaire"
              element={<ProtectedRoute element={<AdminQuestionnairePage />} />} />
          
      </Routes>
      </Suspense>
       
  );
}

export default AppRouter;
