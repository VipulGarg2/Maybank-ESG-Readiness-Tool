import React from "react";
import "./App.css";
import { AuthProvider } from "./context/AuthContext";
import { useSelector } from "react-redux";
import LoaderDiv from "./common/loaderDiv";
import AppRouter from "./AppRouter";
import { ToastProvider } from "./common/ToastContext";
import { ToastContainer } from 'react-toastify';
function App() {
  const isLoading = useSelector((state) => state.loader.loading);

  return (
    <>
    <ToastProvider>
      <AuthProvider>
        {isLoading && <LoaderDiv />}
        <AppRouter />
      </AuthProvider>
      <ToastContainer />
    </ToastProvider>
    </>
  );
}

export default App;
