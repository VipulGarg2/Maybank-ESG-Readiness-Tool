// src/context/AuthContext.js
import React, { createContext, useContext, useState } from 'react';
import { useDispatch } from 'react-redux';
import { setTokens, clearTokens, setLogin, setUserName } from '../store/authSlice';
import axiosInstance from '../store/axiosConfig';
import { Link, useNavigate } from 'react-router-dom';
import { MESSAGES, TOAST_TYPES,API_ENDPOINTS } from '../common/constant';
import { useToast } from "../common/ToastContext";
const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const showToast = useToast();
  const login = async (formData) => {
    try {
      const response = await axiosInstance.post(API_ENDPOINTS.LOGIN, formData);
      if (response.data && response.data.isFirstLogin) {
        // Reset password
       navigate(`/ESGPortal/reset-password?token=${response.data.resetPasswordRequestDto.token}`);
      }  else if(response.data && response.data.accessToken){
        dispatch(setTokens({
          accessToken: response.data.accessToken,
          refreshToken: response.data.refreshToken,
        }));
        dispatch(setLogin({
          isLoggedIn: true,
        }));
        dispatch(setUserName({
          userName: response.data.userName,
        }));
        localStorage.setItem('accessToken', response.data.accessToken);
        localStorage.setItem('refreshToken', response.data.refreshToken);
        setIsAuthenticated(true);
        showToast(MESSAGES.LOGIN_SUCCESS,TOAST_TYPES.SUCCESS)
        navigate('/ESGPortal/admin-surveys');
      } else {
        showToast(MESSAGES.ERROR,TOAST_TYPES.ERROR)
      }
    } catch (error) {
      if(error.status == '401'){
        showToast(MESSAGES.LOGIN_FAILED,TOAST_TYPES.ERROR)
      }
      else{
        showToast(MESSAGES.ERROR,TOAST_TYPES.ERROR)
      }
    }
  };

  const logout = () => {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    setIsAuthenticated(false);
    dispatch(clearTokens());
    dispatch(setLogin({
      isLoggedIn: false,
    }));
    dispatch(setUserName({
      userName: '',
    }));
    navigate('/ESGPortal/login');
  };
  

  return (
    <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};


export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};