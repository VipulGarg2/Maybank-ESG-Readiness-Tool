import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import axiosInstance from "../../store/axiosConfig"; // Import your Axios instance
import logo from "../../../public/new-logo.png"; // Adjust import based on your setup
import { Link, useNavigate } from "react-router-dom";
import { useToast } from "../../common/ToastContext";
import { MESSAGES, TOAST_TYPES, API_ENDPOINTS } from "../../common/constant"; 
import "./style.scss";

// Validation schema using Yup
const validationSchema = Yup.object({
  username: Yup.string().required("Username is required."),
});

const ForgotPassword = () => {
  const navigate = useNavigate();
  const showToast = useToast();

  // Handle form submission using Formik
  const handleSubmit = async (values, { setSubmitting }) => {
    try {
      const response = await axiosInstance.post(API_ENDPOINTS.FORGOT_PASSWORD, values);
      if(response.status == 200){
        showToast(MESSAGES.FORGOT_PASSWORD_SUCCESS,TOAST_TYPES.SUCCESS)
        navigate("/ESGPortal/login"); // Redirect after successful submission
      } else {
        showToast(MESSAGES.ERROR,TOAST_TYPES.ERROR)
      }
    } catch (error) {
      showToast(MESSAGES.ERROR,TOAST_TYPES.ERROR)
      console.error(error); // Handle error (you can also show an error message)
    } finally {
      setSubmitting(false); // Stop the submitting state
    }
  };

  return (
    <div className="login-container">
      <div className="login-form">
        <div className="logo">
          <img src={logo} alt="logo" />
        </div>
        <h5 className="text-center mb-2">Forgot/Reset Password</h5>
        <p className="message mb-4">Please enter your username to receive the reset password link on your email.</p>
        <Formik
          initialValues={{ username: "" }}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
        >
          {({ isSubmitting }) => (
            <Form className="forms_controls">
              <div className="form-floating position-relative">
                <Field
                  type="text"
                  className="form-control"
                  name="username"
                  id="username"
                  placeholder="User Name"
                />
                <label className="form-label">
                  Username <span>*</span>
                </label>
                <ErrorMessage
                  name="username"
                  component="div"
                  className="text-danger fs-13 mt-1"
                />
              </div>

              <button
                type="submit"
                className="login-btn"
                disabled={isSubmitting} // Disable button while submitting
              >
                {isSubmitting ? "Submitting..." : "Submit"}
              </button>

              <div className="d-flex justify-content-center mt-2">
                <Link to="/ESGPortal/login" className="text-decoration-none">
                  Login
                </Link>
              </div>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default ForgotPassword;
