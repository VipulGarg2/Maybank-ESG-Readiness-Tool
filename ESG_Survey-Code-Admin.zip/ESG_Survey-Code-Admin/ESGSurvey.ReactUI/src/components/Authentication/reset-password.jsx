import React, { useState, useEffect } from "react";
import axiosInstance from "../../store/axiosConfig"; // Import your Axios instance
import logo from "../../../public/new-logo.png";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { API_ENDPOINTS, MESSAGES, TOAST_TYPES } from "../../common/constant";
import { useToast } from "../../common/ToastContext";
import "./style.scss";

// Validation Schema using Yup
const ResetPasswordSchema = Yup.object().shape({
  password: Yup.string()
    .matches(/[A-Z]/, "Password must contain at least one uppercase letter") // At least one uppercase letter
    .matches(/[a-z]/, "Password must contain at least one lowercase letter") // At least one lowercase letter
    .matches(/[0-9]/, "Password must contain at least one number") // At least one number
    .matches(/[\W_]/, "Password must contain at least one special character")
    .min(8, "Password must be at least 8 characters long")
   // .max(8, "Password must be less than 50 characters long")
    .required("Password is required"),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref("password"), null], "Passwords must match")
    .required("Confirm Password is required"),
});


const ResetPassword = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token");
  useEffect(() => {
    if(!token) return false;
    checkResetPassword();
  }, []);

  const checkResetPassword = async () => {
    try {
      const response = await axiosInstance.get(
        API_ENDPOINTS.CHECK_RESET_PASSWORD + `/?token=${token}`
        
      );
    } catch (error) {
      showToast(error?.response?.data?.InvalidToken[0],TOAST_TYPES.ERROR);
      navigate("/ESGPortal/login");
    } finally {
    }
  }

  const [passwordVisible, setPasswordVisible] = useState(false);
  const showToast = useToast();
  
  const togglePasswordVisibility = () => {
    setPasswordVisible(!passwordVisible);
  };

  

  const initialValues = {
    password: "",
    confirmPassword: "",
    token: token,
  };

  const handleSubmit = async (values, { setSubmitting }) => {
    try {
      const response = await axiosInstance.post(
        API_ENDPOINTS.RESET_PASSWORD,
        values
      );
      if(response.status == 200){
        showToast(MESSAGES.RESET_PASSWORD_SUCCESS,TOAST_TYPES.SUCCESS)
        navigate("/ESGPortal/login"); // Redirect after successful submission
      } else {
        showToast(MESSAGES.ERROR,TOAST_TYPES.ERROR)
      }
    } catch (error) {
      showToast(error?.response?.data?.InvalidToken[0],TOAST_TYPES.ERROR)
      console.log(error);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="login-container">
      <div className="login-form">
        <div className="logo">
          <img src={logo} alt="logo" />
        </div>
        <h5 className="text-center mb-4">Reset Password</h5>

        <Formik
          initialValues={initialValues}
          validationSchema={ResetPasswordSchema}
          onSubmit={handleSubmit}
        >
          {({ isSubmitting }) => (
            <Form className="forms_controls">
              <div className="mb-3">
                <div className="form-floating position-relative mb-0">
                  <Field
                    type={passwordVisible ? "text" : "password"}
                    className="form-control"
                    name="password"
                    placeholder="New Password"
                  />
                  <label className="form-label">
                    New Password <span>*</span>
                  </label>
                  {/* <i
                    className={`position-absolute end-0 top-70 translate-middle-y me-3 cursor ${
                      passwordVisible ? "bi bi-eye-slash" : "bi bi-eye"
                    }`}
                    onClick={togglePasswordVisibility}
                  ></i> */}
                </div>
                <ErrorMessage
                  name="password"
                  component="div"
                  className="text-danger fs-13 mt-1"
                />
              </div>

              <div className="mb-3">
                <div className="form-floating position-relative mb-0">
                  <Field
                    type={passwordVisible ? "text" : "password"}
                    className="form-control"
                    name="confirmPassword"
                    placeholder="Confirm New Password"
                  />
                  <label className="form-label">
                    Confirm New Password <span>*</span>
                  </label>
                  {/* <i
                    className={`position-absolute end-0 top-70 translate-middle-y me-3 cursor ${
                      passwordVisible ? "bi bi-eye-slash" : "bi bi-eye"
                    }`}
                    onClick={togglePasswordVisibility}
                  ></i> */}
                </div>
                <ErrorMessage
                  name="confirmPassword"
                  component="div"
                  className="text-danger fs-13 mt-1"
                />
              </div>

              <button
                type="submit"
                className="login-btn"
                disabled={isSubmitting}
              >
                {isSubmitting ? "Updating..." : "Update Password"}
              </button>

              <div className="d-flex justify-content-center mt-2">
                <Link to="/ESGPortal/login" className="text-decoration-none">
                  Login
                </Link>
              </div>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default ResetPassword;
