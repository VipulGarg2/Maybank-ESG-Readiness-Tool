import React, { useState, useEffect } from "react";
import logo from "../../../public/new-logo.png";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup"; // Import Yup for validation
import "./style.scss";
import store from "../../store/store"; 
import { hideLoader } from "../../store/loaderSlice"; 
// Validation schema using Yup
const validationSchema = Yup.object().shape({
  username: Yup.string().required("Username is required."),
  password: Yup.string().required("Password is required."),
});

const Login = () => {
  useEffect(() => {
    store.dispatch(hideLoader());
  }, []);

  const [passwordVisible, setPasswordVisible] = useState(false);
  const { login } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const togglePasswordVisibility = () => {
    setPasswordVisible(!passwordVisible);
  };

  const handleSubmit = async (values) => {
    setLoading(true);
    try {
      await login(values);
    } catch (error) {
      setError(error.response?.data?.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      <div className="login-form">
        <div className="logo">
          <img src={logo} alt="logo" />
        </div>

        <Formik
          initialValues={{ username: "", password: "" }}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
        >
          {({ values, handleChange, handleSubmit, isSubmitting }) => (
            <Form onSubmit={handleSubmit} className="forms_controls">
              <div className="mb-3">
                <div className="form-floating position-relative mb-0">
                  <Field
                    type="text"
                    id="username"
                    name="username"
                    placeholder="Enter your username"
                    className="form-control"
                  />
                  <label className="form-label">
                    Username <span>*</span>
                  </label>
                  <i className="bi bi-person position-absolute end-0 top-70 translate-middle-y me-3"></i>
                </div>
                <ErrorMessage
                    name="username"
                    component="div"
                    className="text-danger fs-13 mt-1"
                  />
              </div>

              <div className="mb-3">
                <div className="form-floating position-relative mb-0">
                  <Field
                    type={passwordVisible ? "text" : "password"}
                    id="password"
                    name="password"
                    placeholder="Enter your password"
                    className="form-control"
                  />
                  <label className="form-label">
                    Password <span>*</span>
                  </label>
                  <i
                    className={`position-absolute end-0 top-70 translate-middle-y me-3 cursor ${
                      passwordVisible ? "bi bi-eye-slash" : "bi bi-eye"
                    }`}
                    onClick={togglePasswordVisibility}
                  ></i>
                 
                </div>
                <ErrorMessage
                    name="password"
                    component="div"
                    className="text-danger fs-13 mt-1"
                  />
              </div>

              <div className="d-flex justify-content-end mb-3">
                <Link to="/ESGPortal/forgot-password" className="text-decoration-none">
                  Forgot Password?
                </Link>
              </div>

              <button
                type="submit"
                disabled={loading || isSubmitting}
                className="login-btn"
              >
                {loading || isSubmitting ? "Logging in..." : "Login"}
              </button>

              {error && <div className="text-danger mt-2">{error}</div>}
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default Login;
