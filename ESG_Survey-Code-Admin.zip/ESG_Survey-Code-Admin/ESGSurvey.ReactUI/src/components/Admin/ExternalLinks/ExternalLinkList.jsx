import React, { useState, useEffect } from "react";
import {
  useReactTable,
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  getPaginationRowModel,
} from '@tanstack/react-table';
import axiosInstance from '../../../store/axiosConfig';
import ExternalLinkUpdateModel from "./ExternalLinkUpdateModel";
import { API_ENDPOINTS, MESSAGES, TOAST_TYPES } from "../../../common/constant";
import { useToast } from "../../../common/ToastContext";
import "./style.scss";


const ExternalLinkList = () => {
  const fetchData = async (params) => {
    const response = await axiosInstance.post(
      API_ENDPOINTS.EXTERNAL_LINK_LIST,
      params
    );
    return response.data;
  };
  const showToast = useToast();
  const columnHelper = createColumnHelper();

  const columns = [
    
    columnHelper.accessor('tokenKey', {
      header: () => 'Token',
      cell: info => info.getValue(),
      enableSorting: true,
      size: 30, // Specify width in pixels
    }),
    columnHelper.accessor("description", {
      header: () => "Visible Text",
      cell: (info) => info.getValue(),
      enableSorting: true,
      size: 35, // Specify width in pixels
    }),
    columnHelper.accessor("tokenValue", {
      header: () => "URL",
      cell: (info) => info.getValue(),
      enableSorting: true,
      size: 30, // Specify width in pixels
    }),
    {
      id: 'actions',
      header: 'Actions',
      enableSorting: false,
      cell: ({ row }) => (
        <div className="text-center actions-td">
          <div className="actions">
            <div className="action-btn" onClick={() => openEdit(row.original)}>
              <span placement="top"> <i className="bi bi-pencil-square"></i> </span>
            </div>
          </div>
        </div>
      ),
    },
  ];

  const [data, setData] = useState([]);
  const [pageCount, setPageCount] = useState(0);
  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(8);
  const [sortBy, setSortBy] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [linkDetail,setLinkDetail] = useState(null);

  const defaultSorting = React.useMemo(() => {
    return [
      {
        id: 'pillarName', // Make sure this matches your column accessor
        desc: false, // Set to true for descending order
      },
    ];
  }, []);

  const table = useReactTable({
    data: data,
    columns,
    pageCount,
    state: {
      pagination: { pageIndex, pageSize },
      sorting: sortBy.length === 0 ? defaultSorting : sortBy, 
    },
    manualPagination: true,
    manualSorting: true,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    onPaginationChange: (updater) => {
      const pageIndexValue = typeof updater === 'function' ? updater({}).pageIndex : updater?.pageIndex;
      setPageIndex(pageIndexValue ?? 0);
    },
    onSortingChange: setSortBy,
  });

  useEffect(() => {
    rerender();
  }, [pageIndex, pageSize, sortBy]);

  const openEdit = async (data) => {
    try {
      const response = await axiosInstance.get(`${API_ENDPOINTS.GET_EXTERNAL_LINK_BY_ID}?TokenId=${data.tokenId}`);
      setLinkDetail(response.data);
      handleModalOpen();
    } catch (error) {
      showToast(MESSAGES.ERROR,TOAST_TYPES.ERROR)
    }
  };

  const rerender = async () => {
    const params = {
      page: (pageIndex * pageSize),
      pageSize,
      sortBy: sortBy.length === 0 ? defaultSorting :sortBy.map((sort) => ({
        id: sort.id,
        desc: sort.desc,
      })),
    };
    const result = await fetchData(params);
    setData(result.data);
    setPageCount(Math.ceil(result.recordsTotal / pageSize));
  };

  const handleModalOpen = () => setModalOpen(true);

  const handleClose = () => setModalOpen(false);

  const updateLink = async (values) => {
    try {
      const updateData = await axiosInstance.post(
        API_ENDPOINTS.TOKEN_UPDATE,
        values
      );
      if(updateData.status === 200) {
        showToast(MESSAGES.EXTRNAL_LINK_UPDATE_SUCCESS,TOAST_TYPES.SUCCESS);
        handleClose();
        rerender(); // Refresh the list after update
      } else {
        showToast(MESSAGES.ERROR,TOAST_TYPES.ERROR);
      }
    } catch (error) {
      console.log("error",error)
      showToast(MESSAGES.ERROR,TOAST_TYPES.ERROR);
    }
  };

  return (
    <div className="container-fluid p-0">

      <div id="no-more-tables" className="data-table">
        <div className='max-w-full overflow-x-scroll dr-right'>
        <table className="display table row-border hover dr-left">
          <thead>
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map(header => (
                  <th 
                  className={`${
                    header.column.columnDef.meta?.className ?? ""
                    }`}
                     style={{ width: `${header.getSize()}%` }} key={header.id} onClick={header.column.getToggleSortingHandler()}>
                    {flexRender(header.column.columnDef.header, header.getContext())}
                    {header.column.getIsSorted() ? (
                      <span>{header.column.getIsSorted() === 'asc' ? ' ↑' : ' ↓'}</span>
                    ) : (header.column.getCanSort() ? ' ↑' : null)} 
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {table.getRowModel().rows.map((row) => (
              <tr key={row.id}>
                {row.getVisibleCells().map(cell => (
                  <td key={cell.id}
                  className={`${
                    cell.column.columnDef.meta?.className ?? ""
                    }`}>
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
        </div>
         {/* Pagination Controls */}
         <div className="pagination">
          <div className='pg-left'>
          <label htmlFor="pageSize">Show entries:</label>
          <select
            id="pageSize"
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setPageIndex(0); // Reset to first page
            }}
          >
            {[5, 8, 10, 15, 20, 50].map(size => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </select>
          </div>
          <div className='pg-right'>
          <button
          onClick={() => setPageIndex(old => Math.max(old - 1, 0))} // Prevents going below 0
          disabled={pageIndex === 0} // Disable when on the first page
        >
          <i className="bi bi-chevron-left"></i>
        </button>
          <span className='page-numbers'>
            Page {table.getState().pagination.pageIndex + 1} of {table.getPageCount()}
          </span>
          <button
            onClick={() => setPageIndex(pageIndex + 1)} // Move to the next page manually
            disabled={pageIndex >= table.getPageCount() - 1} // Disable when on the last page
          >
            <i className="bi bi-chevron-right"></i>
          </button>
          </div>
        </div>
      </div>
        {/* Modal for editing the external link data */}
        <ExternalLinkUpdateModel 
          showModal={modalOpen}
          handleClose={handleClose}
          linkDetail={linkDetail}
          setLinkDetail={setLinkDetail}
          updateLink={updateLink}
        />
    </div>
  );
};

export default ExternalLinkList;
