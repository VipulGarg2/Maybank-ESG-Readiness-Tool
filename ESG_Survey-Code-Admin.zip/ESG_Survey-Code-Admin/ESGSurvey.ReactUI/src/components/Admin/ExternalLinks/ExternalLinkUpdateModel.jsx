import React from "react";
import { Modal, Button } from "react-bootstrap";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
import "./style.scss";
// Yup validation schema
const QuestionSchema = Yup.object().shape({
  description: Yup.string().required("Description is required"),
  tokenValue: Yup.string().required("URL is required"),
});

const ExternalLinkUpdateModel = ({
  showModal,
  handleClose,
  linkDetail,
  setLinkDetail,
  updateLink
}) => {
  return (
    linkDetail && (
      <Modal
        show={showModal}
        onHide={handleClose}
        centered
        size="lg"
        className="custom-modal-style"
      >
        <Modal.Header closeButton>
          <Modal.Title>Edit External Link</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Formik
            initialValues={linkDetail}
            validationSchema={QuestionSchema}
            onSubmit={(values) => {
              updateLink(values); // Call your update function with the form values
              handleClose(); // Close modal after submission
            }}
          >
            {({ setFieldValue }) => (
              <Form>
                <div className="form-group mb-2">
                  Token :  <label
                    className="form-label fs-13 color-dark fw-500 mb-0">
                    {linkDetail.tokenKey}
                  </label>
                </div>
                <div className="form-group mb-2">
                  <label
                    htmlFor="description"
                    className="form-label fs-13 color-dark fw-500 mb-0"
                  >
                    Visible Text
                  </label>
                  <Field
                    as="textarea" // Use Field with "as" prop for textarea
                    id="description"
                    name="description"
                    className="form-control text-area"
                    onChange={(e) => {
                      setFieldValue("description", e.target.value);
                      setLinkDetail({
                        ...linkDetail,
                        description: e.target.value,
                      });
                    }}
                  />
                  <ErrorMessage
                    name="description"
                    component="div"
                    className="text-danger fs-13 mt-1"
                  />
                </div>
                <div className="form-group mb-2">
                  <label
                    htmlFor="tokenValue"
                    className="form-label fs-13 color-dark fw-500 mb-0"
                  >
                    URL
                  </label>
                  <Field
                    // as="textarea" // Use Field with "as" prop for textarea
                    id="tokenValue"
                    name="tokenValue"
                    className="form-control text-area"
                    onChange={(e) => {
                      setFieldValue("tokenValue", e.target.value);
                      setLinkDetail({
                        ...linkDetail,
                        tokenValue: e.target.value,
                      });
                    }}
                  />
                  <ErrorMessage
                    name="tokenValue"
                    component="div"
                    className="text-danger fs-13 mt-1"
                  />
                </div>

                <div className="form-group d-flex justify-content-end gap-2 mt-3">
                  <Button variant="light" onClick={handleClose}>
                    Cancel
                  </Button>
                  <Button type="submit" variant="warning">
                    Update
                  </Button>
                </div>
              </Form>
            )}
          </Formik>
        </Modal.Body>
      </Modal>
    )
  );
};

export default ExternalLinkUpdateModel;
