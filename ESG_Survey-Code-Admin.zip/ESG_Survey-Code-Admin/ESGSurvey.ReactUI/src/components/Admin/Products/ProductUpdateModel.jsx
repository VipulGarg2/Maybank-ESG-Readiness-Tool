import React from "react";
import { Modal, Button } from "react-bootstrap";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
import "./style.scss";
// Yup validation schema
const QuestionSchema = Yup.object().shape({
  productName: Yup.string().trim().required("Product name is required")
});

const ProductUpdateModel = ({
  showModal,
  handleClose,
  productsDetail,
  setProductsDetail,
  updateProduct
}) => {
  return (
    productsDetail && (
      <Modal
        show={showModal}
        onHide={handleClose}
        centered
        size="lg"
        className="custom-modal-style"
      >
        <Modal.Header closeButton>
          <Modal.Title>Edit Product</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Formik
            initialValues={productsDetail}
            validationSchema={QuestionSchema}
            onSubmit={(values) => {
              updateProduct(values); // Call your update function with the form values
              handleClose(); // Close modal after submission
            }}
          >
            {({ setFieldValue }) => (
              <Form>
                <div className="form-group mb-2">
                  <label
                    htmlFor="productName"
                    className="form-label fs-13 color-dark fw-500 mb-0"
                  >
                    Product Name
                  </label>
                    <Field
                      id="productName"
                      name="productName"
                      className="form-control text-area"
                      onChange={(e) => {
                        setFieldValue("productName", e.target.value);
                        setQuestionDetail({
                          ...productsDetail,
                          productName: e.target.value,
                        });
                      }}
                    />
                  <ErrorMessage
                    name="productName"
                    component="div"
                    className="text-danger fs-13 mt-1"
                  />
                </div>
                <div className="form-group mb-2">
                  <label
                    htmlFor="productDescription"
                    className="form-label fs-13 color-dark fw-500 mb-0"
                  >
                    Decription
                  </label>
                    <Field
                      as="textarea" // Use Field with "as" prop for textarea
                      id="productDescription"
                      name="productDescription"
                      className="form-control text-area"
                      onChange={(e) => {
                        setFieldValue("productDescription", e.target.value);
                        setQuestionDetail({
                          ...productsDetail,
                          productDescription: e.target.value,
                        });
                      }}
                    />
                </div>
                <div className="form-group mb-2">
                  <label
                    htmlFor="productURL"
                    className="form-label fs-13 color-dark fw-500 mb-0"
                  >
                    URL
                  </label>
                    <Field
                      id="productURL"
                      name="productURL"
                      className="form-control text-area"
                      onChange={(e) => {
                        setFieldValue("productURL", e.target.value);
                        setQuestionDetail({
                          ...productsDetail,
                          productURL: e.target.value,
                        });
                      }}
                    />
                    <ErrorMessage
                      name="productURL"
                      component="div"
                      className="text-danger fs-13 mt-1"
                    />
                </div>

                <div className="form-group d-flex justify-content-end gap-2 mt-3">
                  <Button variant="light" onClick={handleClose}>
                    Cancel
                  </Button>
                  <Button type="submit" variant="warning">
                    Update
                  </Button>
                </div>
              </Form>
            )}
          </Formik>
        </Modal.Body>
      </Modal>
    )
  );
};

export default ProductUpdateModel;
