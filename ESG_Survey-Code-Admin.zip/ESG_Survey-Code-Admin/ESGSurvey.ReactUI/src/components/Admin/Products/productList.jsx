import React, { useState, useEffect } from "react";
import {
  useReactTable,
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  getPaginationRowModel,
} from '@tanstack/react-table';
import axiosInstance from '../../../store/axiosConfig';
import ProductUpdateModel from "./ProductUpdateModel";
import { API_ENDPOINTS, MESSAGES, TOAST_TYPES } from "../../../common/constant";
import { useToast } from "../../../common/ToastContext";
import "./style.scss";
import parse from 'html-react-parser'; // Import the alternative parser
import { OverlayTrigger, Tooltip } from "react-bootstrap";


const ProductList = () => {
  const fetchData = async (params) => {
    const response = await axiosInstance.post(
      API_ENDPOINTS.PRODUCT_LIST,
      params
    );
    return response.data;
  };
  const showToast = useToast();
  const columnHelper = createColumnHelper();



  const columns = [
    
    columnHelper.accessor('productName', {
      header: () => 'Product Name',
      cell: info => parse(info.getValue()),
      enableSorting: true,
      size: 25, // Specify width in pixels
      meta: {
        className: 'wrap-text'
      },
    }),
    columnHelper.accessor("productDescription", {
      header: () => "Description",
      cell: (info) => parse(info.getValue()),
      enableSorting: true,
      size: 40, // Specify width in pixels
      meta: {
        className: 'wrap-text'
      },
    }),
    columnHelper.accessor("productURL", {
      header: () => "URL",
      cell: (info) => parse(info.getValue()),
      enableSorting: true,
      size: 30, // Specify width in pixels
      meta: {
        className: 'wrap-text'
      },
    }),
    {
      id: 'actions',
      header: 'Actions',
      enableSorting: false,
      meta: {
        className: 'text-center'
      },
      cell: ({ row }) => (
        <div className="text-center actions-td">
          <div className="actions">
            <div className="action-btn" onClick={() => openEdit(row.original)}>
  
              <OverlayTrigger
              placement="top"
               overlay={ <Tooltip className="mytooltip" id="button-tooltip-2">  Edit </Tooltip>}>
                 <span placement="top"> <i className="bi bi-pencil-square"></i> </span>
            </OverlayTrigger>
            </div>
          </div>
        </div>
      ),
    },
  ];

  const [products, setProducts] = useState([]);
  const [pageCount, setPageCount] = useState(0);
  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(5);
  const [sortBy, setSortBy] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [productsDetail,setProductsDetail] = useState(null);

  const defaultSorting = React.useMemo(() => {
    return [
      {
        id: 'pillarName', // Make sure this matches your column accessor
        desc: false, // Set to true for descending order
      },
    ];
  }, []);

  const table = useReactTable({
    data: products,
    columns,
    pageCount,
    state: {
      pagination: { pageIndex, pageSize },
      sorting: sortBy.length === 0 ? defaultSorting : sortBy, 
    },
    manualPagination: true,
    manualSorting: true,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    onPaginationChange: (updater) => {
      const pageIndexValue = typeof updater === 'function' ? updater({}).pageIndex : updater?.pageIndex;
      setPageIndex(pageIndexValue ?? 0);
    },
    onSortingChange: setSortBy,
  });

  useEffect(() => {
    rerender();
  }, [pageIndex, pageSize, sortBy]);

  const openEdit = async (question) => {
    try {
      debugger;
      const response = await axiosInstance.get(`${API_ENDPOINTS.GET_PRODUCT_BY_ID}?productId=${question.productId}`);
      setProductsDetail(response.data);
      handleModalOpen();
    } catch (error) {
      showToast(MESSAGES.ERROR,TOAST_TYPES.ERROR)
    }
  };

  const rerender = async () => {
    const params = {
      page: (pageIndex * pageSize),
      pageSize,
      sortBy: sortBy.length === 0 ? defaultSorting :sortBy.map((sort) => ({
        id: sort.id,
        desc: sort.desc,
      })),
    };
    const result = await fetchData(params);
    setProducts(result.data);
    setPageCount(Math.ceil(result.recordsTotal / pageSize));
  };

  const handleModalOpen = () => setModalOpen(true);

  const handleClose = () => setModalOpen(false);

  const updateProduct = async (values) => {
    try {
      const updateData = await axiosInstance.post(
        API_ENDPOINTS.PRODUCT_UPDATE,
        values
      );
      if(updateData.status === 200) {
        showToast(MESSAGES.PRODUCT_LIST_UPDATE_SUCCESS,TOAST_TYPES.SUCCESS);
        handleClose();
        rerender(); // Refresh the list after update
      } else {
        showToast(MESSAGES.ERROR,TOAST_TYPES.ERROR);
      }
    } catch (error) {
      showToast(MESSAGES.ERROR,TOAST_TYPES.ERROR);
    }
  };

  return (
    <div className="container-fluid p-0">

      <div id="no-more-tables" className="data-table pr-table">
        <div className='max-w-full overflow-x-scroll dr-right'>
        <table className="display table row-border hover dr-left">
          <thead>
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map(header => (
                  <th 
                  className={`${
                    header.column.columnDef.meta?.className ?? ""
                    }`}
                     style={{ width: `${header.getSize()}%` }} key={header.id} onClick={header.column.getToggleSortingHandler()}>
                    {flexRender(header.column.columnDef.header, header.getContext())}
                    {header.column.getIsSorted() ? (
                      <span>{header.column.getIsSorted() === 'asc' ? ' ↑' : ' ↓'}</span>
                    ) : (header.column.getCanSort() ? ' ↑' : null)} 
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {table.getRowModel().rows.map((row) => (
              <tr key={row.id}>
                {row.getVisibleCells().map(cell => (
                  <td key={cell.id}
                  className={`${
                    cell.column.columnDef.meta?.className ?? ""
                    }`}>
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
        </div>
         {/* Pagination Controls */}
         <div className="pagination">
          <div className='pg-left'>
          <label htmlFor="pageSize">Show entries:</label>
          <select
            id="pageSize"
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setPageIndex(0); // Reset to first page
            }}
          >
            {[5, 10, 15, 20, 25, 50, 75, 100].map(size => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </select>
          </div>
          <div className='pg-right'>
          <button
          onClick={() => setPageIndex(old => Math.max(old - 1, 0))} // Prevents going below 0
          disabled={pageIndex === 0} // Disable when on the first page
        >
          <i className="bi bi-chevron-left"></i>
        </button>
          <span className='page-numbers'>
            Page {table.getState().pagination.pageIndex + 1} of {table.getPageCount()}
          </span>
          <button
            onClick={() => setPageIndex(pageIndex + 1)} // Move to the next page manually
            disabled={pageIndex >= table.getPageCount() - 1} // Disable when on the last page
          >
            <i className="bi bi-chevron-right"></i>
          </button>
          </div>
        </div>
      </div>
        {/* Modal for editing the Products */}
        <ProductUpdateModel 
          showModal={modalOpen}
          handleClose={handleClose}
          productsDetail={productsDetail}
          setProductsDetail={setProductsDetail}
          updateProduct={updateProduct}
        />
    </div>
  );
};

export default ProductList;
