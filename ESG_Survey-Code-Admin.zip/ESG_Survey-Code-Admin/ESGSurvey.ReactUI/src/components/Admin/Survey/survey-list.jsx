import React, { useState, useEffect } from "react";
import {
  useReactTable,
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  getPaginationRowModel,
} from '@tanstack/react-table';
import axiosInstance from '../../../store/axiosConfig';
import { Row, Col, Button, Modal, OverlayTrigger, Tooltip } from 'react-bootstrap';
import "./style.scss";
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import moment from 'moment';
import "./style.scss";
import * as XLSX from 'xlsx';
import { useToast } from "../../../common/ToastContext";
import "./style.scss";
import { MESSAGES, TOAST_TYPES } from "../../../common/constant";
const apiurl = import.meta.env.VITE_API_BASE_URL;

const SurveyList = () => {
  const showToast = useToast();
  const fetchData = async (params) => {
    const response = await axiosInstance.post(
      `/AdminSurvey/GetAdminSurveyGridData`,
      params
    );
    return response.data;
  };

  const columnHelper = createColumnHelper();

  const columns = [
    columnHelper.accessor("businessEntityName", {
      header: () => "Company Name",
      cell: (info) => info.getValue(),
      enableSorting: true,
      meta: {
        className:
          "sticky right-0",
       },
    }),
    columnHelper.accessor('companyTurnoverName', {
      header: () => 'Annual Turnover',
      cell: info => info.getValue(),
      enableSorting: true,
    }),
    columnHelper.accessor('organizationSectorName', {
      header: () => 'Organisation Sector',
      cell: info => info.getValue(),
      enableSorting: true,
    }),
    columnHelper.accessor('nameOfPrimaryContact', {
      header: () => 'Contact Person',
      cell: info => info.getValue(),
      enableSorting: true,
    }),
    columnHelper.accessor('roleOfPrimaryContact', {
      header: () => 'Job Title',
      cell: info => info.getValue(),
      enableSorting: true,
    }),
    columnHelper.accessor('corporateEmailAddressPrimaryContact', {
      header: () => 'Email',
      cell: info => info.getValue(),
      enableSorting: true,
    }),
    columnHelper.accessor('phoneNumberPrimaryContact', {
      header: () => 'Contact Number',
      cell: info => info.getValue(),
      enableSorting: true,
    }),
    columnHelper.accessor('isExistingMaybankCustomer', {
      header: () => 'Existing Customer',
      cell: info => info.getValue(),
      enableSorting: true,
    }),
    columnHelper.accessor('score', {
      header: () => 'Score',
      cell: info => info.getValue() + '%',
      enableSorting: true,
    }),
    columnHelper.accessor('maturityLevel', {
      header: () => 'Maturity Level',
      cell: info => info.getValue(),
      enableSorting: true,
    }),
    columnHelper.accessor('createdDate', {
      header: () => 'Submitted On',
      cell: info =>  {
        return convertToLocalDate(info.getValue())
      },
      enableSorting: true,
    }),
    
    {
      id: 'actions',
      header: 'Actions',
      enableSorting: false,
      cell: ({ row }) => (
        <div className="text-center actions-td">
        <div className="actions">
          <div className="action-btn" onClick={() => handleModalOpen(row.original)}>
          <OverlayTrigger
              placement="top"
               overlay={ <Tooltip className="mytooltip" id="button-tooltip-2">  View </Tooltip>}>
                     <span placement="top"> <i className="bi bi-eye-fill"></i> </span>
            </OverlayTrigger>

          </div>
          <div className="action-btn" onClick={() => handleDownloadPdf(row.original)}>
    <OverlayTrigger
              placement="top"
               overlay={ <Tooltip className="mytooltip" id="button-tooltip-2">  Download </Tooltip>}>
                     <span placement="top"> <i className="bi bi-cloud-arrow-down-fill"></i></span>
            </OverlayTrigger>
          </div>
        </div>
</div>
      ),
    },
  ];

  const [surveyForm, setSurveyForm] = useState({
    organizationSectorId: null,
    globalSearchText: '',
    fromSubmittedOn: null,
    tillSubmittedOn:null,
  });
  const [surveys, setSurveys] = useState([]);
  const [sectorList, setSectorList] = useState([]);
  const [pageCount, setPageCount] = useState(0);
  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(5);
  const [sortBy, setSortBy] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [isReset, setIsReset] = useState(false);
  const [isApply, setIsApply] = useState(false);
  const [selectedSurvey, setSelectedSurvey] = useState(null);
  const [groupedSurveyDetails, setGroupedSurveyDetails] = useState([]);
  const defaultSorting = React.useMemo(() => {
    return [
      {
        id: 'createdDate', // Make sure this matches your column accessor
        desc: true, // Set to true for descending order
      },
    ];
  }, []);

  const table = useReactTable({
    data: surveys,
    columns,
    pageCount,
    state: {
      pagination: { pageIndex, pageSize },
      sorting: sortBy.length === 0 ? defaultSorting : sortBy, 
    },
    manualPagination: true,
    manualSorting: true,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    onPaginationChange: (updater) => {
      const pageIndexValue = typeof updater === 'function' ? updater({}).pageIndex : updater?.pageIndex;
      setPageIndex(pageIndexValue ?? 0);
    },
    onSortingChange: setSortBy,
  });

  useEffect(() => {
    rerender();
    fetchSectors();
  },[])

  useEffect(() => {
    if(!isReset){
      rerender();
    }
  }, [pageIndex, pageSize, sortBy, isApply]);

  const fetchSectors = async () => {
    const response = await axiosInstance.get(
      `/AdminSurvey/SectorDropdownSelect`
    );
    setSectorList(response.data.sectorList);
  };

  const rerender = async () => {
    const params = {
      organizationSectorId: surveyForm.organizationSectorId,
      globalSearchText: surveyForm.globalSearchText,
      fromSubmittedOn: surveyForm.fromSubmittedOn,
      tillSubmittedOn: surveyForm.tillSubmittedOn,
      page: (pageIndex * pageSize), // server usually expects 1-based index
      pageSize,
      sortBy: sortBy.length === 0 ? defaultSorting :sortBy.map((sort) => ({
        id: sort.id,
        desc: sort.desc,
      })),
    };
    const result = await fetchData(params);
    setSurveys(result.data);
    setPageCount(Math.ceil(result.recordsTotal / pageSize));
  };

  const handleModalOpen = (survey) => {
    setSelectedSurvey(survey);
    setModalOpen(true);
    fetchSurveyDetails(survey.reportGuid);
  };

  const handleDownloadPdf = async (survey) => {
    try {
        const response = await axiosInstance.get(`AdminSurvey/GetEsgMaturityAssessmentReport?guid=${survey.reportGuid}`, {
            responseType: 'blob' // Important: Set the response type to 'blob'
        });

        // Check if the response status is OK (200)
        if (response.status === 200) { // Use 'response.status' instead of 'response.ok'
            const blob = new Blob([response.data], { type: 'application/pdf' }); // Create a Blob from the response data
            const url = window.URL.createObjectURL(blob); // Create a URL for the Blob
            const link = document.createElement('a'); // Create an anchor element
            link.href = url; // Set the URL as the href of the link
            link.setAttribute('download', `ESGReadinessAssessmentReport_${survey.businessEntityName}_${convertToLocalDateForName(survey.createdDate)}.pdf`); // Set the download attribute with the desired file name
            document.body.appendChild(link); // Append the link to the body
            link.click(); // Programmatically click the link to trigger the download
            link.parentNode.removeChild(link); // Remove the link from the document
            window.URL.revokeObjectURL(url); // Clean up the URL object
        } else {
            console.error('File download failed:', response.status);
        }
    } catch (error) {
        console.error('Error during file download:', error); // Catch any errors during the request
    }
};

  const fetchSurveyDetails = async (id) => {
    const response = await axiosInstance.get(
      `/AdminSurvey/GetSurveyViewSelect/?reportGuid=${id}`
    );
    const surveyViewList = response.data.surveyDetailsList;
    setGroupedSurveyDetails(groupByPillar(surveyViewList));
  };

  const groupByPillar = (surveyDetails) => {
    return surveyDetails.reduce((group, detail) => {
      const { pillarId, pillarName, score } = detail;
      if (!group[pillarId]) {
        group[pillarId] = {
          pillarName: pillarName,
          score : score,
          details: [],
        };
      }
      group[pillarId].details.push(detail);
      return group;
    }, {});
  };

  const clearDate = () => {
    setSurveyForm({
      fromSubmittedOn: null,
      tillSubmittedOn: null,
    });
  };

  const handleApply=()=>{
    const currentDate = new Date();
  // Check if From Date is greater than current date
  if (surveyForm.fromSubmittedOn && new Date(surveyForm.fromSubmittedOn) > currentDate ) {
    showToast(MESSAGES.FROM_DATE_NOT_GRATER_THAN_CURRENT,TOAST_TYPES.ERROR);
    return;
  }

  // Check if Till Date is greater than current date
  else if (surveyForm.tillSubmittedOn && new Date(surveyForm.tillSubmittedOn) >currentDate) {
    showToast(MESSAGES.TILL_DATE_NOT_GRATER_THAN_CURRENT,TOAST_TYPES.ERROR)
    return;
  }
  else if(surveyForm.tillSubmittedOn) {
    if (surveyForm.fromSubmittedOn && new Date(surveyForm.tillSubmittedOn) < new Date(surveyForm.fromSubmittedOn) ) {
    showToast(MESSAGES.FROM_DATE_NOT_GRATER_THAN_TILL,TOAST_TYPES.ERROR)
    return;
  }}
 
      setPageCount(0);
      setPageIndex(0);
      setIsApply(!isApply);
  
}
  const handleExport = async () => {
    const params = {
      organizationSectorId: surveyForm.organizationSectorId,
      globalSearchText: surveyForm.globalSearchText,
      fromSubmittedOn:surveyForm.fromSubmittedOn,
      tillSubmittedOn:surveyForm.tillSubmittedOn,
      page: 0, // server usually expects 1-based index
      pageSize : 999999,
      sortBy: sortBy.length === 0 ? defaultSorting :sortBy.map((sort) => ({
        id: sort.id,
        desc: sort.desc,
      })),
    };
    const result = await fetchData(params);

  // Define the headers you want
  const headers = [
    'Company Name',
    'Annual Turnover',
    'Organisation Sector',
    'Contact Person',
    'Job Title',
    'Email',
    'Contact Number',
    'Existing Customer',
    'Score',
    'Maturity Level',
    'Submitted On'
  ];

  // Map the data to include the new keys with capitalized headers
  const formattedData = result.data.map(item => ({
    'Company Name':item.businessEntityName,
    'Annual Turnover':item.companyTurnoverName,
    'Organisation Sector':item.organizationSectorName,
    'Contact Person':item.nameOfPrimaryContact,
    'Job Title':item.roleOfPrimaryContact,
    'Email':item.corporateEmailAddressPrimaryContact,
    'Contact Number':item.phoneNumberPrimaryContact,
    'Existing Customer':item.isExistingMaybankCustomer,
    'Score':item.score,
    'Maturity Level':item.maturityLevel,
    'Submitted On':convertToLocalDate(item.createdDate)
  }));

  // Convert the formatted data to a worksheet
  const worksheet = XLSX.utils.json_to_sheet(formattedData, { header: headers });
  
  // Create a new workbook
  const workbook = XLSX.utils.book_new();
  
  // Append the worksheet to the workbook
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

  /// Generate a timestamp in DD-MM-YYYY_HH-MM-SS format
  const now = new Date();
  const day = String(now.getDate()).padStart(2, '0');
  const month = String(now.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
  const year = now.getFullYear();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  const formattedDateTime = `${day}-${month}-${year}_${hours}-${minutes}-${seconds}`; // Format: DD-MM-YYYY_HH-MM-SS

  // Generate a file name with timestamp
  const fileName = `ESGReadinessAssessment_${formattedDateTime}.xlsx`;

  // Export the workbook
  XLSX.writeFile(workbook, fileName);
  }

  const convertToLocalDate = (utcDate) => {
    return moment.utc(utcDate).local().format('DD/MM/YYYY'); // Customize format as needed
};
const convertToLocalDateForName = (utcDate) => {
  return moment.utc(utcDate).local().format('DD/MM/YYYY'); // Customize format as needed
};


  const handleReset = async () => {
    setSurveyForm({
      organizationSectorId: null,
      globalSearchText: '',
      fromSubmittedOn: null,
      tillSubmittedOn:null,
    });
    setPageCount(0);
    setPageIndex(0);
    setPageSize(5);
    const params = {
      organizationSectorId: null,
      globalSearchText: '',
      fromSubmittedOn: null,
      tillSubmittedOn:null,
      page: 0, // server usually expects 1-based index
      pageSize:5,
      sortBy: sortBy.length === 0 ? defaultSorting :sortBy.map((sort) => ({
        id: sort.id,
        desc: sort.desc,
      })),
    };
    const result = await fetchData(params);
    setSurveys(result.data);
    setPageCount(Math.ceil(result.recordsTotal / 5));
    setIsReset(false);
  };

  const handleDateChangeFrom = (date) => {
    console.log("date",date)
    setSurveyForm({ ...surveyForm, fromSubmittedOn: date ? moment(date).format('YYYY-MM-DD')  : null }); // Update the surveyForm state
  };
  const handleDateChangeTill = (date) => {
    console.log("date",date)
    setSurveyForm({ ...surveyForm, tillSubmittedOn: date ? moment(date).format('YYYY-MM-DD')  : null }); // Update the surveyForm state
  };

  return (
    <div className="container-fluid p-0">
      <div className="table-search">
        <form className="forms_controls">
          <Row>
            <Col md="2" lg="2" className="col-search">
              <div className="form-floating">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search here..."
                  value={surveyForm.globalSearchText}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault(); // Disable the Enter key
                    }
                  }}
                  onChange={(e) => setSurveyForm({ ...surveyForm, globalSearchText: e.target.value })}
                />
                <label className='form-label'>Search by Keyword</label>
              </div>
            </Col>
            <Col md="3" lg="3" className="col-search">
              <div className="form-floating">
                <select
                  className="form-select"
                  value={surveyForm.organizationSectorId || ""}
                  onChange={(e) =>
                    setSurveyForm({
                      ...surveyForm,
                      organizationSectorId: e.target.value || null,
                    })
                  }
                >
                  <option value="">Select Company Sector</option>
                  {sectorList.map((item) => (
                    <option
                      key={item.organizationSectorId}
                      value={item.organizationSectorId}
                    >
                      {item.organizationSectorName}
                    </option>
                  ))}
                </select>
                <label className='form-label'>Company Sector</label>
              </div>
            </Col>
            <Col md="2" lg="2" className="col-search">
              <div className="form-floating">
                {/* <input
                  type="date"
                  className="form-control"
                  value={surveyForm.submittedOn ?? ""}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault(); // Disable the Enter key
                    }
                  }}
                  onChange={(e) => e.target.value ? setSurveyForm({ ...surveyForm, submittedOn: e.target.value }) :
                  setSurveyForm((prevForm) => ({
                    ...prevForm,
                    submittedOn: null, // Clear only the submittedOn date
                  }))}
                /> */}
                <DatePicker
                  selected={surveyForm.fromSubmittedOn ? new Date(surveyForm.fromSubmittedOn) : null}
                  onChange={handleDateChangeFrom}
                  className="form-control"
                  placeholderText="DD/MM/YYYY"
                  dateFormat="DD/MM/YYYY"
                  isClearable // Allows clearing the date
                />
                <label className='form-label'>From Date</label>
              </div>
            </Col>

            <Col md="2" lg="2" className="col-search">
              <div className="form-floating">
                {}
                <DatePicker
                  selected={surveyForm.tillSubmittedOn ? new Date(surveyForm.tillSubmittedOn) : null}
                  onChange={handleDateChangeTill}
                  className="form-control"
                  placeholderText="DD/MM/YYYY"
                  dateFormat="DD/MM/YYYY"
                  isClearable // Allows clearing the date
                />
                <label className='form-label'>Till Date</label>
              </div>
            </Col>
            <Col md="3" lg="3" className="col-search form-buttons pt-md-2h">
              <div className="d-flex gap-2">
                <button
                  type="button"
                  className="btn btn-warning"
                  onClick={handleApply}
                >
                  Apply
                </button>
                <button
                  type="button"
                  className="btn btn-light"
                  onClick={() => {
                    setIsReset(true);
                    setTimeout(() => {
                      handleReset();
                    }, 300);
                  }}
                >
                  Reset
                </button>
                <button
                  type="button"
                  className="btn btn-light"
                  onClick={handleExport}
                >
                  Export
                </button>
              </div>
            </Col>
          </Row>
        </form>
        
      </div>

      <div id="no-more-tables" className="data-table">
        <div className='max-w-full overflow-x-scroll dr-left'>
        <table className="display table row-border hover dr-left">
          <thead>
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map(header => (
                  <th 
                  className={`${
                    header.column.columnDef.meta?.className ?? ""
                    }`}
                     style={{ width: `${header.getSize()}%` }} key={header.id} onClick={header.column.getToggleSortingHandler()}>
                    {flexRender(header.column.columnDef.header, header.getContext())}
                    {header.column.getIsSorted() ? (
              <span>{header.column.getIsSorted() === 'asc' ? ' ↑' : ' ↓'}</span>
            ) : (header.column.getCanSort() ? ' ↑' : null)} 
                    {/* {{ asc: ' ↑', desc: ' ↓' }[header.column.getIsSorted()] ?? ' ↑'} */}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
              {table.getRowModel().rows.length > 0 ? (
                table.getRowModel().rows.map((row) => (
                  <tr key={row.id}>
                    {row.getVisibleCells().map((cell) => (
                      <td key={cell.id} className={`${cell.column.columnDef.meta?.className ?? ""}`}>
                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                      </td>
                    ))}
                  </tr>
                ))
              ) : (
                <tr style={{height:"55px", fontSize:"16px"}}>
                  <td colSpan={columns.length} className="text-center" style={{fontSize:"16px"}}>
                    No record found
                  </td>
                </tr>
              )}
            </tbody>

        </table>
        </div>
         {/* Pagination Controls */}
         <div className="pagination">
          <div className='pg-left'>
          <label htmlFor="pageSize">Show entries:</label>
          <select
            id="pageSize"
            value={pageSize}
            onChange={(e) => {
              setPageSize(Number(e.target.value));
              setPageIndex(0); // Reset to first page
            }}
          >
            {[5, 10, 15, 20, 25, 50, 75, 100].map(size => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </select>
          </div>
          <div className='pg-right'>
          <button
          onClick={() => setPageIndex(old => Math.max(old - 1, 0))} // Prevents going below 0
          disabled={pageIndex === 0} // Disable when on the first page
        >
          <i className="bi bi-chevron-left"></i>
        </button>
          <span className='page-numbers'>
            Page {table.getState().pagination.pageIndex + 1} of {table.getPageCount()}
          </span>
          <button
            onClick={() => setPageIndex(pageIndex + 1)} // Move to the next page manually
            disabled={pageIndex >= table.getPageCount() - 1} // Disable when on the last page
          >
            <i className="bi bi-chevron-right"></i>
          </button>
          </div>
        </div>
      </div>
        

      {/* Modal for survey details */}
      <Modal size="lg" show={modalOpen} onHide={() => setModalOpen(false)} centered className='custom-modal-style'>
        <Modal.Header closeButton className='pb-3'>
          <Modal.Title>{selectedSurvey?.businessEntityName} - {selectedSurvey?.organizationSectorName}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {Object.entries(groupedSurveyDetails).map(([key, group]) => (
            <div key={key} className="pillar">
              <div className="pillar-head d-flex">
                <div className="pillar-head-left">
                  <span className="badge bg-warning">Pillar-{key}</span>
                  <label className="ms-2">{group.pillarName}</label>
                </div>
                <div className="ms-auto">
                  <span className="badge bg-dark">Score: {group.score}%</span>
                </div>
              </div>
              {group.details.map((detail, index) => (
                <div key={index} className="pilla-ques">
                  <p>{detail.questionsName}</p>
                  <p className={detail.answerText==='Yes'? 'answ':'answ no-ans'}>{detail.answerText}</p>
                </div>
              ))}
            </div>
          ))}
           <div className="form-group d-flex justify-content-end gap-2 mt-3">
              <Button variant="light" onClick={() => setModalOpen(false)}>
              Close
              </Button>
             
            </div>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default SurveyList;
