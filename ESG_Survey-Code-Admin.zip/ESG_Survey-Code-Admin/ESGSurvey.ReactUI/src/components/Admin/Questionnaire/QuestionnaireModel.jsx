import React from "react";
import { Modal, Button } from "react-bootstrap";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";
import "./style.scss";
// Yup validation schema
const QuestionSchema = Yup.object().shape({
  questionsName: Yup.string().trim().required("Question is required"),
  //guideline: Yup.string().required("Guideline is required"),
});

const EditQuestionModal = ({
  showModal,
  handleClose,
  questionDetail,
  setQuestionDetail,
  updateQuestion
}) => {
  return (
    questionDetail && (
      <Modal
        show={showModal}
        onHide={handleClose}
        centered
        size="lg"
        className="custom-modal-style"
      >
        <Modal.Header closeButton>
          <Modal.Title>Edit Question</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Formik
            initialValues={{
              questionsName: questionDetail.questionsName || "",
              guideline: questionDetail.guideline || "",
              yesRecommendation: questionDetail.yesRecommendation || "",
              noRecommendation: questionDetail.noRecommendation || "",
            }}
            validationSchema={QuestionSchema}
            onSubmit={(values) => {
              updateQuestion(values); // Call your update function with the form values
              handleClose(); // Close modal after submission
            }}
          >
            {({ setFieldValue }) => (
              <Form>
                <div className="form-group mb-2">
                  <label>
                    <span className="badge bg-warning text-dark">
                      Pillar-{questionDetail.pillarId}
                    </span>{" "}
                    {questionDetail.pillarName}
                  </label>
                </div>
                <div className="form-group mb-2">
                  <label
                    htmlFor="editQuestion"
                    className="form-label fs-13 color-dark fw-500 mb-0"
                  >
                    Question
                  </label>
                  <Field
                    as="textarea" // Use Field with "as" prop for textarea
                    id="editQuestion"
                    name="questionsName"
                    className="form-control text-area"
                    onChange={(e) => {
                      setFieldValue("questionsName", e.target.value);
                      setQuestionDetail({
                        ...questionDetail,
                        questionsName: e.target.value,
                      });
                    }}
                  />
                  <ErrorMessage
                    name="questionsName"
                    component="div"
                    className="text-danger fs-13 mt-1"
                  />
                </div>

                <div className="form-group mb-2">
                  <label
                    htmlFor="editGuideline"
                    className="form-label fs-13 color-dark fw-500 mb-0"
                  >
                    Guideline
                  </label>
                  <Field
                    as="textarea" // Use Field with "as" prop for textarea
                    id="editGuideline"
                    name="guideline"
                    className="form-control text-area"
                    onChange={(e) => {
                      setFieldValue("guideline", e.target.value);
                      setQuestionDetail({
                        ...questionDetail,
                        guideline: e.target.value,
                      });
                    }}
                  />
                  <ErrorMessage
                    name="guideline"
                    component="div"
                    className="text-danger fs-13 mt-1"
                  />
                </div>
                <div className="form-group mb-2">
                  <label>
                    
                    {"Recommendation"}
                  </label>
                </div>
                <div className="form-group mb-2">
                  <label
                    htmlFor="editQuestion"
                    className="form-label fs-13 color-dark fw-500 mb-0"
                  >
                    Yes
                  </label>
                  <Field name="yesRecommendation">
                    {({ field }) => (
                      <CKEditor
                        editor={ClassicEditor}
                        data={field.value}
                        onChange={(event, editor) => {
                          const data = editor.getData();
                          setFieldValue("yesRecommendation", data);
                          setQuestionDetail({
                            ...questionDetail,
                            yesRecommendation: data,
                          });
                        }}
                      />
                    )}
                  </Field>
                  <ErrorMessage
                    name="yesRecommendation"
                    component="div"
                    className="text-danger fs-13 mt-1"
                  />
                </div>

                <div className="form-group mb-2">
                  <label
                    htmlFor="editGuideline"
                    className="form-label fs-13 color-dark fw-500 mb-0"
                  >
                    No
                  </label>
                  <Field name="noRecommendation">
                    {({ field }) => (
                      <CKEditor
                        editor={ClassicEditor}
                        data={field.value}
                        onChange={(event, editor) => {
                          const data = editor.getData();
                          setFieldValue("noRecommendation", data);
                          setQuestionDetail({
                            ...questionDetail,
                            noRecommendation: data,
                          });
                        }}
                      />
                    )}
                  </Field>
                  <ErrorMessage
                    name="noRecommendation"
                    component="div"
                    className="text-danger fs-13 mt-1"
                  />
                </div>

                <div className="form-group d-flex justify-content-end gap-2 mt-3">
                  <Button variant="light" onClick={handleClose}>
                    Cancel
                  </Button>
                  <Button type="submit" variant="warning">
                    Update
                  </Button>
                </div>
              </Form>
            )}
          </Formik>
        </Modal.Body>
      </Modal>
    )
  );
};

export default EditQuestionModal;
