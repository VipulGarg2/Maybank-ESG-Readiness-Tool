import React, { useState, useEffect, useRef } from "react";
import { Modal, Button, Table, Tooltip, OverlayTrigger } from "react-bootstrap"; // Using react-bootstrap for Modal and Tooltips
import axiosInstance from "../../../store/axiosConfig";
import EditQuestionModal from "./QuestionnaireModel";
import { API_ENDPOINTS, MESSAGES, TOAST_TYPES } from "../../../common/constant";
import { useToast } from "../../../common/ToastContext";
import "./style.scss";

const QuestionnaireList = () => {
  const [questionnaireList, setQuestionnaireList] = useState([]);
  const [questionDetail, setQuestionDetail] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const showToast = useToast();
  const dtElement = useRef(null); // Replacing @ViewChild with a ref

  useEffect(() => {
    // Fetch the questionnaire list on component mount
    getQuestionnaireList();
  }, []);

  const getQuestionnaireList = async () => {
    // Fetch the questionnaire list from the API
    try {
      const response = await axiosInstance.get(API_ENDPOINTS.GET_QUESTIONNAIR_LIST); // Adjust API call as per your backend
      const groupedData = groupQuestionsByPillar(response.data.questionnaireList);
      setQuestionnaireList(groupedData);
    } catch (error) {
      showToast(MESSAGES.ERROR,TOAST_TYPES.ERROR)
    }
  };

  const groupQuestionsByPillar = (list) => {
    return list.reduce((acc, question) => {
      let pillar = acc.find((p) => p.pillarName === question.pillarName);
      if (!pillar) {
        pillar = {
          pillarId: question.pillarId,
          pillarName: question.pillarName,
          questions: [],
        };
        acc.push(pillar);
      }
      pillar.questions.push({
        pillarId: question.pillarId,
        questionsId: question.questionsId,
        questionsName: question.questionsName,
        guideline: question.guideline,
      });
      return acc;
    }, []);
  };

  const openEdit = async (question) => {
    try {
      const response = await axiosInstance.get(`${API_ENDPOINTS.GET_QUESTIONNAIR_BY_ID}?questionsId=${question.questionsId}`);
      setQuestionDetail(response.data);
      setShowModal(true);
    } catch (error) {
      showToast(MESSAGES.ERROR,TOAST_TYPES.ERROR)
    }
  };

  const updateQuestion = async () => {
    try {
      const updateQuestionDto = {
        questionsId: questionDetail.questionsId,
        questionsName: questionDetail.questionsName,
        guideline: questionDetail.guideline,
        yesRecommendation : questionDetail.yesRecommendation,
        noRecommendation : questionDetail.noRecommendation,
      };
      const updateData = await axiosInstance.post(
        API_ENDPOINTS.UPDATE_QUESTIONNAIRE,
        updateQuestionDto
      );
      if(updateData.status === 200) {
        showToast(MESSAGES.QUESTIONNAIRE_UPDATE_SUCCESS,TOAST_TYPES.SUCCESS);
        setShowModal(false);
        getQuestionnaireList(); // Refresh the list after update
      } else {
        showToast(MESSAGES.ERROR,TOAST_TYPES.ERROR);
      }
    } catch (error) {
      showToast(MESSAGES.ERROR,TOAST_TYPES.ERROR);
    }
  };

  const handleClose = () => setShowModal(false);

  return (
    <>
      <div className="container-fluid p-0" id="no-more-tables">
        {/* Iterate over the grouped questionnaireList */}
        {questionnaireList.map((pillar, i) => (
          <div key={i} className="question-table">
            <div className="quiz-title">
              <strong>Pillar-{pillar.pillarId}</strong> - {pillar.pillarName}
            </div>
            <Table>
              <thead>
                <tr>
                  <th style={{ width: "45%" }}>Question</th>
                  <th style={{ width: "45%" }}>Guideline</th>
                  <th style={{ width: "10px" }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {pillar.questions.map((question, idx) => (
                  <tr key={idx}>
                    <td>{question.questionsName}</td>
                    <td>
                      <OverlayTrigger
                        placement="top"
                        overlay={
                          <Tooltip id="button-tooltip-2">
                            {question.guideline}
                          </Tooltip>
                        }
                      >
                        <span className="text-truncate">
                          {question.guideline}
                        </span>
                      </OverlayTrigger>

                      {/* <Tooltip title={question.guideline} placement="top">
                      <span>{question.guideline}</span>
                    </Tooltip> */}
                    </td>
                    <td className="action-td text-center">
                    <OverlayTrigger
              placement="top"
               overlay={ <Tooltip className="mytooltip" id="button-tooltip-2">  Edit </Tooltip>}>
                   <span
                        className="cursor edit-i"
                        onClick={() => openEdit(question)}
                      >
                        <i className="bi bi-pencil-square"></i>
                      </span>
            </OverlayTrigger>
                      
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        ))}
      </div>

      {/* Modal for editing the question */}
      <EditQuestionModal 
        showModal={showModal}
        handleClose={handleClose}
        questionDetail={questionDetail}
        setQuestionDetail={setQuestionDetail}
        updateQuestion={updateQuestion}
      />
    </>
  );
};


export default QuestionnaireList;
