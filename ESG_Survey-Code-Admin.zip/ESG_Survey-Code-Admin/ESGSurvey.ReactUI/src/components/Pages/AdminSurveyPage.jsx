import React from "react";
import SurveyList from "../Admin/Survey/survey-list";
import AdminTemplate from "../Templates/AdminTemplate";

const AdminSurveyPage = () => (
  <AdminTemplate>
    <SurveyList />
  </AdminTemplate>
);
export default AdminSurveyPage;
