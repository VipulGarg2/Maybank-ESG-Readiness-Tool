import React from "react";
import ExternalLinkList from "../Admin/ExternalLinks/ExternalLinkList";
import AdminTemplate from "../Templates/AdminTemplate";

const ExternalLinkPage = () => (
  <AdminTemplate>
    <ExternalLinkList />
  </AdminTemplate>
);
export default ExternalLinkPage;
