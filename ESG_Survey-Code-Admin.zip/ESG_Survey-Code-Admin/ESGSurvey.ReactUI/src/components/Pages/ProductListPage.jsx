import React from "react";
import ProductList from "../Admin/Products/ProductList";
import AdminTemplate from "../Templates/AdminTemplate";

const ProductListPage = () => (
  <AdminTemplate>
    <ProductList />
  </AdminTemplate>
);
export default ProductListPage;
