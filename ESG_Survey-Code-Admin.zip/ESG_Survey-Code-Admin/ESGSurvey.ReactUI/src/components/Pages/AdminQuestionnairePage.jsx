import React from "react";
import AdminTemplate from "../Templates/AdminTemplate";
import QuestionnaireList from "../Admin/Questionnaire/questionnaire-list";

const AdminQuestionnairePage = () => (
  <AdminTemplate>
    <QuestionnaireList />
  </AdminTemplate>
);
export default AdminQuestionnairePage;
