import React, { useState } from "react";
import Header from "../Layouts/header";
import Sidebar from "../Layouts/sidebar";

const AdminTemplate = ({ children }) => {
  const [showSidebar, setShowSidebar] = useState(true);

  const toggleSidebar = () => {
    setShowSidebar(!showSidebar);
  };

  return (
    <div className={`layout admin-layout ${showSidebar ? "" : "nav-toggle"}`}>
      <Header showSidebar={showSidebar} toggleSidebar={toggleSidebar} />
      <Sidebar />
      <div className="main">{children}</div>
    </div>
  );
};

export default AdminTemplate;
