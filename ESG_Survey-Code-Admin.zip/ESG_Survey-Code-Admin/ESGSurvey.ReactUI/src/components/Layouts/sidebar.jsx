// Sidebar.jsx
import React from "react";
import { Link, useLocation  } from "react-router-dom";
import { useSelector } from "react-redux";
import Logo from "../../../public/new-logo.png";
import LogoIcon from "../../../public/maybank-logo-icon.png";

const Sidebar = ({ toggleSidebar }) => {
  const user = useSelector((state) => state.auth.isLoggedIn);
  const location = useLocation();

  const isPathActive = (path) => {
    return location.pathname.startsWith(path);
  };
  return (
    <>
      <div className="overlay"></div>
      <div className="side-nav expand-lg">
        <ul className="side-nav-menu">
          <li className="side-nav-logo">
            <a className="logo" title="Logo">
              <img src={Logo} className="big-logo" />
              <img src={LogoIcon} className="small-logo" />
            </a>
          </li>
          {user && (
            <li className="nav-item">
              <Link to="/ESGPortal/admin-surveys"
              className={`text-decoration-none ${isPathActive("/ESGPortal/admin-surveys") ? "active-link" : ""}`}
              >
                <i className="bi bi-file-earmark-text"></i>
                <span className="title">Surveys</span>
              </Link>
            </li>
          )}
          
          {user && (
            <li className="nav-item">
              <Link to="/ESGPortal/admin-questionnaire" 
              className={`text-decoration-none ${isPathActive("/ESGPortal/admin-questionnaire") ? "active-link" : ""}`}
              >
                <i className="bi bi-question-circle"></i>
                <span className="title">Questionnaire</span>
              </Link>
            </li>
          )}
          {user && (
            <li className="nav-item">
              <Link to="/ESGPortal/products"
              className={`text-decoration-none ${isPathActive("/ESGPortal/products") ? "active-link" : ""}`}
              >
                <i className="bi bi-file-earmark-text"></i>
                <span className="title">Products</span>
              </Link>
            </li>
          )}
          {/* {user && (
            <li className="nav-item">
              <Link to="/ESGPortal/external-link"
              className={`text-decoration-none ${isPathActive("/external-link") ? "active-link" : ""}`}
              >
                <i className="bi bi-file-earmark-text"></i>
                <span className="title">External Links</span>
              </Link>
            </li>
          )} */}
        </ul>
        <div className="fold-menu-on-desktop d-none">
          <a className="sidenav-fold-toggler">
            <i className="icon-left"></i>
          </a>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
