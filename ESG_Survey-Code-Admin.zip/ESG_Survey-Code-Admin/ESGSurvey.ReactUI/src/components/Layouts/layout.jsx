// Layout.jsx
import React, { useEffect,useState } from 'react';
import { useSelector } from 'react-redux';

const Layout = ({ children }) => {
  const [data, setData] = useState(new Date());
  const user = useSelector((state) => state.auth.isLoggedIn); 
  console.log(user);
  useEffect(() => {
    setData(new Date());
    // Optional cleanup can be returned from useEffect if needed
    return () => {
    };
  }, [user]); 
  return (
   
        <div className="content">{children}</div>
     
  );
};

export default Layout;
