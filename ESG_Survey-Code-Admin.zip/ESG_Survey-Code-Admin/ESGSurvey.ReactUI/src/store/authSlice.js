// src/store/authSlice.js
import { createSlice } from '@reduxjs/toolkit';

const authSlice = createSlice({
  name: 'auth',
  initialState: {
    accessToken: null,
    refreshToken: null,
    isLoggedIn: false,
    userName:''
  },
  reducers: {
    setTokens: (state, action) => {
      state.accessToken = action.payload.accessToken;
      state.refreshToken = action.payload.refreshToken;
    },
    clearTokens: (state) => {
      state.accessToken = null;
      state.refreshToken = null;
    },
    setLogin: (state, action) => {
      state.isLoggedIn = action.payload.isLoggedIn;
    },
    setUserName: (state, action) => {
      state.userName = action.payload.userName;
    },
  },
});

export const { setTokens, clearTokens, setLogin,setUserName } = authSlice.actions;
export default authSlice.reducer;
