import { combineReducers } from "@reduxjs/toolkit";
import authSlice from "./authSlice";
import loaderSlice from "./loaderSlice";

const rootReducer = combineReducers({
  auth: authSlice,
  loader: loaderSlice
});

export default rootReducer;
