// src/axios/axiosConfig.js
import axios from "axios";
import store from "./store"; // Adjust the import based on your structure
import { setLogin, clearTokens, setUserName } from "./authSlice"; // Import clearTokens action

import { showLoader, hideLoader } from "./loaderSlice"; // Assuming you have loader actions

let requestCount = 0; // This will keep track of the ongoing requests
const apiurl = import.meta.env.VITE_API_BASE_URL;
const apiKey = import.meta.env.VITE_API_KEY;
// Function to show loader
const showLoading = () => {
  if (requestCount === 0) {
    store.dispatch(showLoader());
  }
  requestCount++;
};

// Function to hide loader
const hideLoading = () => {
  requestCount--;
  if (requestCount <= 0) {
    store.dispatch(hideLoader());
    requestCount = 0;
  }
};

const axiosInstance = axios.create({
  baseURL: apiurl, // Replace with your API URL
});

// Request interceptor to add tokens
axiosInstance.interceptors.request.use(
  (config) => {
    const state = store.getState();
    const token = state.auth.accessToken;
    config.headers["ApiKey"] = `${apiKey}`;
    // Show loader
    showLoading();
    if (token) {
      config.headers["Authorization"] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    // Show loader
    showLoading();
    return Promise.reject(error);
  }
);

// Response interceptor to handle token expiration
axiosInstance.interceptors.response.use(
  (response) => {
    // Hide loader on response
    hideLoading();
    return response;
  },
  (error) => {
    // Hide loader in case of error
    hideLoading();
    if (error.response && error.response.status === 401) {
      // Clear tokens if unauthorized
      store.dispatch(clearTokens());
      store.dispatch(setLogin(false));
      store.dispatch(setUserName(""));
    }
    return Promise.reject(error);
  }
);

export default axiosInstance;
