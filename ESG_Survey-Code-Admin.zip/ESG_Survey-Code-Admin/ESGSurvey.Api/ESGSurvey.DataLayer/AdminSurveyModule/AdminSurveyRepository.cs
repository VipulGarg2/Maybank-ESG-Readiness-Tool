﻿using Dapper;
using ESGSurvey.BusinessLayer.DTO.Common;
using ESGSurvey.BusinessLayer.DTO.AdminSurveyModule;
using ESGSurvey.BusinessLayer.Extensions;
using ESGSurvey.BusinessLayer.Interfaces.AdminSurveyModule;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;

using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.DataLayer.AdminSurveyModule
{
    public class AdminSurveyRepository : IAdminSurveyRepository
    {
        private readonly IConfiguration _config;
        public AdminSurveyRepository(IConfiguration config)
        {
            _config = config;
        }
        /// <summary>
        /// get all survey list
        /// </summary>
        /// <param name="requestObjectWrapper"></param>
        /// <returns></returns>
        public async Task<PaginatedResponse<SurveyDto>> GetAdminSurveyGridData(SurveyRequestDto requestObjectWrapper)
        {
            if(requestObjectWrapper.SortBy.Count == 0)
            {
                //requestObjectWrapper.SortBy.Add(new SortByDto()
                //{
                //    Id= "CreatedDate",
                //    Desc = true
                //});
            }
             using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            String strRequestModel = JsonConvert.SerializeObject(requestObjectWrapper);
            PaginatedResponse<SurveyDto> result = new PaginatedResponse<SurveyDto>();
            using (var connection = new SqlConnection(db.ConnectionString))
            {
                using (var multi = await connection.QueryMultipleAsync("sp_esg_AdminSurveyGridSelect",
                     new { RequestModel = strRequestModel }, commandType: CommandType.StoredProcedure))
                {
                    result.RecordsTotal = multi.Read<int>().First();
                    result.Data = multi.Read<SurveyDto>()?.ToList()!;
                    result.RecordsFiltered = result.Data != null ? result.Data.Count() : 0;
                }
            }

            return result;

        }
        /// <summary>
        /// get  Survey details 
        /// </summary>
        /// <param name="reportGuid"></param>
        /// <returns></returns>
        public async Task<AdminSurveyViewResponse> GetSurveyViewSelect(Guid reportGuid)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@ReportGuid", reportGuid);
            using (var multiResultSet = await db.QueryMultipleAsync("sp_esg_SurveyViewSelect", parameters,commandType: CommandType.StoredProcedure))
            {
                var surveyList = await multiResultSet.ReadAsync<AdminSurveyViewSelectDto>();
                return new AdminSurveyViewResponse()
                {
                    SurveyDetailsList = surveyList.ToList()
                };

            }

        }
        /// <summary>
        /// get all pillar list
        /// </summary>
        /// <returns></returns>
        public async Task<PillarDropdownListDto> PillarDropdownSelect()
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            PillarDropdownListDto responseDto = new PillarDropdownListDto();
            using (var multi = await db.QueryMultipleAsync("sp_esg_PillarList", commandType: CommandType.StoredProcedure))
            {
                var List = await multi.ReadAsync<AdminPillarDto>();
               // responseDto.PiilarList = List.ToList();
            }
            return responseDto;
        }
        /// <summary>
        /// get all sector list
        /// </summary>
        /// <returns></returns>
        public async Task<SectorDropdownListDto> SectorDropdownSelect()
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            SectorDropdownListDto responseDto = new SectorDropdownListDto();
            using (var multi = await db.QueryMultipleAsync("sp_esg_OrganizationSectorList", commandType: CommandType.StoredProcedure))
            {
               responseDto.SectorList = multi.Read<AdminSectorDto>().ToList();
            }
            return responseDto;
        }
    }
}
