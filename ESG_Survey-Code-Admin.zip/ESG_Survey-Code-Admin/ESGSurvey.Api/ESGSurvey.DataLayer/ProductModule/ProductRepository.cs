﻿using Dapper;
using ESGSurvey.BusinessLayer.Extensions;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ESGSurvey.BusinessLayer.Interfaces.ProductModule;
using ESGSurvey.BusinessLayer.DTO.ProductModule;

namespace ESGSurvey.DataLayer.ProductModule
{
    public class ProductRepository : IProductRepository
    {
        private readonly IConfiguration _config;
        public ProductRepository(IConfiguration config)
        {
            _config = config;
        }
        /// <summary>
        /// get all survey list
        /// </summary>
        /// <param name="requestObjectWrapper"></param>
        /// <returns></returns>
        public async Task<ProductPaginatedResponse<ProductDto>> ProductGridSelect(ProductRequestDto requestObjectWrapper)
        {
            if(requestObjectWrapper.SortBy.Count == 0)
            {
                requestObjectWrapper.SortBy.Add(new ProductSortByDto()
                {
                    Id= "PillarName",
                    Desc = false
                });
            }
             using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            String strRequestModel = JsonConvert.SerializeObject(requestObjectWrapper);
            ProductPaginatedResponse<ProductDto> result = new ProductPaginatedResponse<ProductDto>();
            using (var connection = new SqlConnection(db.ConnectionString))
            {
                using (var multi = await connection.QueryMultipleAsync("sp_esg_ProductGridSelect",
                     new { RequestModel = strRequestModel }, commandType: CommandType.StoredProcedure))
                {
                    result.RecordsTotal = multi.Read<int>().First();
                    result.Data = multi.Read<ProductDto>()?.ToList()!;
                    result.RecordsFiltered = result.Data != null ? result.Data.Count() : 0;
                }
            }

            return result;

        }
        /// <summary>
        /// get  Survey details 
        /// </summary>
        /// <param name="reportGuid"></param>
        /// <returns></returns>
        public async Task<ProductDto> GetProductSelect(byte ProductId)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@ProductId", ProductId);
            using (var multiResultSet = await db.QueryMultipleAsync("sp_esg_ProductSelect", parameters,commandType: CommandType.StoredProcedure))
            {
                var data = await multiResultSet.ReadFirstOrDefaultAsync<ProductDto>();
                return data == null ? new ProductDto() : data;

            }

        }

        public async Task<int> ProductUpdate(ProductDto ProductObj, int UserId)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@PillarId", ProductObj.PillarId);
            parameters.Add("@ProductName", ProductObj.ProductName);
            parameters.Add("@ProductId", ProductObj.ProductId);
            parameters.Add("@ProductURL", ProductObj.ProductURL);
            parameters.Add("@ProductDescription", ProductObj.ProductDescription);
            parameters.Add("@UserId", UserId);
            return await db.QueryFirstOrDefaultAsync<int>("sp_esg_ProductUpdate", parameters, commandType: CommandType.StoredProcedure);
        }

    }
}
