﻿using Dapper;
using ESGSurvey.BusinessLayer.DTO.AdminQuestionnaireModule;
using ESGSurvey.BusinessLayer.Extensions;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.DataLayer.AdminQuestionnaireModule
{
    public class QuestionnaireRepository : BusinessLayer.Interfaces.AdminQuestionnaireModule.IQuestionnaireRepository
    {
        private readonly IConfiguration _config;
        public QuestionnaireRepository(IConfiguration config)
        {
            _config = config;
        }

        /// <summary>
        /// this method use for Get all Questionnaire List
        /// </summary>
        /// <returns></returns>
        public async Task<QuestionnaireResponseDto> GetQuestionnaireList()
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            using (var multiResultSet = await db.QueryMultipleAsync("sp_esg_AdminQuestionnaireList", commandType: CommandType.StoredProcedure))
            {
                var questionnaireResponseDto = new QuestionnaireResponseDto();
                var result = multiResultSet.Read<QuestionnaireDto>().ToList();
                questionnaireResponseDto.QuestionnaireList = result == null ? new List<QuestionnaireDto>() : result;
                return questionnaireResponseDto;
            }
        }

        /// <summary>
        /// this method use for Questionnaire Select by questionId
        /// </summary>
        /// <param name="QuestionsId"></param>
        /// <returns></returns>
        public async Task<QuestionnaireDto> GetQuestionnaireSelect(byte QuestionsId)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@QuestionsId", QuestionsId);
            var result = await db.QueryFirstOrDefaultAsync<QuestionnaireDto>("sp_esg_QuestionnaireSelect", parameters, commandType: CommandType.StoredProcedure);
            return result == null ? new QuestionnaireDto() : result;
        }

        /// <summary>
        /// this method use for Questionnaire Update
        /// </summary>
        /// <param name="QuestionnaireObj"></param>
        /// <param name="UserId"></param>
        /// <returns></returns>
        public async Task<int> QuestionnaireUpdate(QuestionnaireDto QuestionnaireObj, int UserId)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@QuestionsId", QuestionnaireObj.QuestionsId);
            parameters.Add("@QuestionsName", QuestionnaireObj.QuestionsName);
            parameters.Add("@Guideline", QuestionnaireObj.Guideline);
            parameters.Add("@YesRecommendation", QuestionnaireObj.YesRecommendation);
            parameters.Add("@NoRecommendation", QuestionnaireObj.NoRecommendation);
            parameters.Add("@UserId", UserId);
            return await db.QueryFirstOrDefaultAsync<int>("sp_esg_QuestionnaireUpdate", parameters, commandType: CommandType.StoredProcedure);
        }
    }
}
