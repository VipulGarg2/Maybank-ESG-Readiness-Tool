﻿using Dapper;
using ESGSurvey.BusinessLayer.DTO.Common;
using ESGSurvey.BusinessLayer.DTO.UserModule;
using ESGSurvey.BusinessLayer.Extensions;
using ESGSurvey.BusinessLayer.Interfaces.UserModule;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;

namespace ESGSurvey.DataLayer.UserModule
{
    public class UserRepository: IUserRepository
    {
        #region Constructor & Declaration
        private readonly IConfiguration _config;
        public UserRepository(IConfiguration config)
        {
            _config = config;
        }

        #endregion Constructor & Declaration

        #region Public Methods
        /// <summary>
        /// This method is used to get user password salt by username
        /// </summary>
        /// <param name="Username"></param>
        /// <returns></returns>
        public async Task<string> GetUserPasswordSaltByUsername(string Username)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@Uname", Username);
            var passwordSalt = await db.QueryFirstOrDefaultAsync<string>("sp_esg_UserPasswordSaltSelect", parameters, commandType: CommandType.StoredProcedure);
            return passwordSalt ?? string.Empty;
        }

        /// <summary>
        /// This method is used for checking valid username and hashed password.
        /// If correct then return userid
        /// </summary>
        /// <param name="Username"></param>
        /// <param name="HashedPassword"></param>
        /// <returns></returns>
        public async Task<int?> IsValidUser(string Username, string HashedPassword)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@Uname", Username);
            parameters.Add("@HashPassword", HashedPassword);
            return await db.QueryFirstOrDefaultAsync<int?>("sp_esg_CheckUserValid", parameters, commandType: CommandType.StoredProcedure);


        }

        /// <summary>
        /// This method is used for validating user refresh token request
        /// </summary>
        /// <param name="RequestDto"></param>
        /// <returns></returns>
        public async Task<CustomSuccessResponse> ValidateUserRefreshToken(UserAccessTokenRequestDto RequestDto)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", RequestDto.UserId);
            parameters.Add("@RefreshToken", RequestDto.RefreshToken);
            parameters.Add("@CurrentDate", DateTime.Now);
            var result = await db.QueryFirstOrDefaultAsync<CustomSuccessResponse>("sp_esg_ValidateUserRefreshToken", parameters, commandType: CommandType.StoredProcedure);
            result ??= new CustomSuccessResponse();
            return result;
        }

        /// <summary>
        /// This method is used for updating user refresh token expiry time
        /// </summary>
        /// <param name="RefreshTokenUpdateDto"></param>
        /// <returns></returns>
        public async Task<CustomSuccessResponse> UpdateUserRefreshToken(UserAccessTokenUpdateDto RefreshTokenUpdateDto)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", RefreshTokenUpdateDto.UserId);
            parameters.Add("@RefreshToken", RefreshTokenUpdateDto.RefreshToken);
            parameters.Add("@ExpirationDateTime", RefreshTokenUpdateDto.ExpirationDateTime);
            var result = await db.QueryFirstOrDefaultAsync<CustomSuccessResponse>("sp_esg_UserRefreshTokenUpdate", parameters, commandType: CommandType.StoredProcedure);
            result ??= new CustomSuccessResponse();
            return result;
        }

        /// <summary>
        /// This method is used to get user info with roles and permission
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns></returns>
        public async Task<UserRoleModulePermissionDto> GetUserRoleModulePermissionById(int UserId)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", UserId);
           
            using (var multiResultSet = await db.QueryMultipleAsync("sp_esg_UserInfoSelect", parameters, commandType: CommandType.StoredProcedure))
            {
                var userRoleDetail = await multiResultSet.ReadAsync<UserRoleDetailDBDto>();
                var userModuleDetail = await multiResultSet.ReadAsync<UserModuleDetailDBDto>();
                var userRoleModulePermissionDto = new UserRoleModulePermissionDto();
                if (userRoleDetail != null)
                {
                    userRoleModulePermissionDto.UserId = userRoleDetail.Select(x => x.UserId).First();
                    userRoleModulePermissionDto.Uname = userRoleDetail.Select(x => x.Uname).First();
                    userRoleModulePermissionDto.IsFirstLogin= userRoleDetail.Select(x => x.IsFirstLogin).First();
                    userRoleModulePermissionDto.RoleDetails = userRoleDetail.Select(
                    x => new UserRoleDetailDto
                    {
                        RoleId = x.RoleId,
                        RoleName = x.RoleName,
                        RoleKey = x.RoleKey,
                        AllowedModules = BuildModuleHierarchy(userModuleDetail.Where(x => x.RoleId == x.RoleId)?.ToList() ?? new List<UserModuleDetailDBDto>(), null).ChildModules
                    }).ToList();
                    
                }
                return userRoleModulePermissionDto;
            }


        }

        /// <summary>
        /// Check if user reset password token is valid
        /// </summary>
        /// <param name="Token"></param>
        /// <param name="CurrentDate"></param>
        /// <returns></returns>
        public async Task<int> IsResetPasswordTokenValid(string Token, int Minutes)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@Token", Token);
            parameters.Add("@Minutes", Minutes);
            return await db.QuerySingleOrDefaultAsync<int>("sp_esg_UserResetPasswordTokenValid", parameters, commandType: CommandType.StoredProcedure);

        }

        /// <summary>
        /// Reset User Password
        /// </summary>
        /// <param name="resetPasswordRequestDto"></param>
        /// <returns></returns>
        public async Task<bool> ResetPassword(ResetPasswordRequestDto resetPasswordRequestDto)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@Password", resetPasswordRequestDto.Password);
            parameters.Add("@UserId", resetPasswordRequestDto.UserId);
            parameters.Add("@Token", resetPasswordRequestDto.Token);
            return await db.QuerySingleOrDefaultAsync<bool>("sp_esg_UserPasswordUpdate", parameters, commandType: CommandType.StoredProcedure);

        }

        /// <summary>
        /// This method is used for getting password salt by user Id
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns></returns>
        public async Task<string> GetPasswordSaltByUserId(int UserId)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", UserId);
            var result= await db.QueryFirstOrDefaultAsync<string>("sp_esg_UserPasswordSaltByUserIdSelect", parameters, commandType: CommandType.StoredProcedure);
            result??=string.Empty;
            return result;
        }

        /// <summary>
        /// This method is used for saving reset password detail
        /// </summary>
        /// <param name="resetPasswordSaveDto"></param>
        /// <returns></returns>
        public async Task<bool> SaveResetPasswordDetails(ResetPasswordSaveDto resetPasswordSaveDto)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@UserId", resetPasswordSaveDto.UserId);
            parameters.Add("@Token", resetPasswordSaveDto.Token);
            parameters.Add("@Minutes", resetPasswordSaveDto.ResetTokenExpiryMinutes);
            return await db.QuerySingleOrDefaultAsync<bool>("sp_esg_UserResetPasswordInsert", parameters, commandType: CommandType.StoredProcedure);

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Username"></param>
        /// <returns></returns>
        public async Task<ForgotPasswordDto> IsUsernameValid(string Username)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@Username", Username);
            var result = await db.QueryFirstOrDefaultAsync<ForgotPasswordDto>("sp_esg_UsernameValid", parameters, commandType: CommandType.StoredProcedure);
            return result == null ? new ForgotPasswordDto() : result;
        }
        #endregion Public Methods

        #region Private Methods
        private Module BuildModuleHierarchy(List<UserModuleDetailDBDto> modules, int? parentId)
        {
            Module module = new Module();
            module.ChildModules = new List<Module>();
            var groupByResult = modules.GroupBy(x => x.ModuleId);
            foreach (var item in groupByResult.Where(x => x.First().ParentId == parentId))
            {
                Module child = BuildModuleHierarchy(modules, item.First().ModuleId);
                child.ModuleId = item.First().ModuleId;
                child.ModuleName = item.First().ModuleName;
                child.ModuleKey = item.First().ModuleKey;
                child.MenuUrl = item.First().MenuUrl;
                child.MenuTypeId = item.First().MenuTypeId;
                child.MenuSort = item.First().MenuSort;
                child.MenuIcon = item.First().MenuIcon;
                child.AllowedPermissions = modules.Where(x => x.ModuleId == item.First().ModuleId).Select(x => new Permission
                {
                    PermissionId = x.PermissionId,
                    PermissionName = x.PermissionName,
                    PermissionKey = x.PermissionKey,
                })?.ToList() ?? new List<Permission>();
                module.ChildModules.Add(child);
            }
            return module;
        }

        #endregion Private Methods
    }
}
