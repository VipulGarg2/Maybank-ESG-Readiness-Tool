﻿using Dapper;
using ESGSurvey.BusinessLayer.DTO.Common;
using ESGSurvey.BusinessLayer.DTO.TokenModule;
using ESGSurvey.BusinessLayer.Extensions;
using ESGSurvey.BusinessLayer.Interfaces.TokenModule;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;

using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.DataLayer.TokenModule
{
    public class TokenRepository : ITokenRepository
    {
        private readonly IConfiguration _config;
        public TokenRepository(IConfiguration config)
        {
            _config = config;
        }
        /// <summary>
        /// get all survey list
        /// </summary>
        /// <param name="requestObjectWrapper"></param>
        /// <returns></returns>
        public async Task<TokenPaginatedResponse<TokenDto>> TokenGridSelect(TokenRequestDto requestOjectWrapper)
        {
            if(requestOjectWrapper.SortBy.Count == 0)
            {
                requestOjectWrapper.SortBy.Add(new TokenSortByDto()
                {
                    Id= "TokenKey",
                    Desc = false
                });
            }
             using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            String strRequestModel = JsonConvert.SerializeObject(requestOjectWrapper);
            TokenPaginatedResponse<TokenDto> result = new TokenPaginatedResponse<TokenDto>();
            using (var connection = new SqlConnection(db.ConnectionString))
            {
                using (var multi = await connection.QueryMultipleAsync("sp_esg_TokenGridSelect",
                     new { RequestModel = strRequestModel }, commandType: CommandType.StoredProcedure))
                {
                    result.RecordsTotal = multi.Read<int>().First();
                    result.Data = multi.Read<TokenDto>()?.ToList()!;
                    result.RecordsFiltered = result.Data != null ? result.Data.Count() : 0;
                }
            }

            return result;

        }
        /// <summary>
        /// get  Survey details 
        /// </summary>
        /// <param name="reportGuid"></param>
        /// <returns></returns>
        public async Task<TokenDto> TokenSelect(Int16 TokenId)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@TokenId", TokenId);
            using (var multiResultSet = await db.QueryMultipleAsync("sp_esg_TokenSelect", parameters,commandType: CommandType.StoredProcedure))
            {
                var data = await multiResultSet.ReadFirstOrDefaultAsync<TokenDto>();
                return data == null ? new TokenDto() : data;
            }

        }

        public async Task<int> TokenUpsert(TokenDto TokenObj, int UserId)
        {
            using IDbConnection db = new SqlConnection(_config.GetESGSurveyConnectionString());
            var parameters = new DynamicParameters();
            parameters.Add("@TokenId", TokenObj.TokenId);
            parameters.Add("@TokenValue", TokenObj.TokenValue);
            parameters.Add("@Description", TokenObj.Description);
            parameters.Add("@TokenKey", TokenObj.TokenKey);
            parameters.Add("@UserId", UserId);
            return await db.QueryFirstOrDefaultAsync<int>("sp_esg_TokenUpsert", parameters, commandType: CommandType.StoredProcedure);
        }

      
    }
}
