﻿using Microsoft.Extensions.Configuration;

namespace ESGSurvey.BusinessLayer.Extensions
{
    public static class ConfigurationManagerExtension
    {
        public static string GetESGSurveyConnectionString(this IConfiguration config)
        {
            return config["ConnectionStrings:ESGSurveySQLConnection"] ?? string.Empty;
        }
    }
}
