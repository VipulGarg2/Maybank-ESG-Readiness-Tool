﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer
{
    public static class ESGSurveyConstant
    {
        public static readonly int PASSWORD_WORKFACTOR = 4;
        public static readonly int REFRESH_TOKEN_EXPIRATION_IN_MONTH = 4;
    }
}
