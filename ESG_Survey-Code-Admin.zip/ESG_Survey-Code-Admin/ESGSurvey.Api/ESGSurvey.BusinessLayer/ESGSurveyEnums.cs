﻿using System.ComponentModel;

namespace ESGSurvey.BusinessLayer
{
    public enum CustomSuccessResponseEnums
    {
        [Description("Success")]
        SUCCESS = 200,
        [Description("User Already Exist")]
        USER_ALREADY_EXIST = 101,
        [Description("Refresh Token Expired")]
        REFRESH_TOKEN_EXPIRED = 102,
        [Description("Operation Failed")]
        OPERATION_FAILED = 500,
        [Description("Not Found")]
        NOT_FOUND = 404,

    }
}
