﻿using ESGSurvey.BusinessLayer.DTO.ProductModule;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.Interfaces.ProductModule
{
    public interface IProductRepository
    {
        public Task<ProductDto> GetProductSelect(byte ProductId);
        public Task<int> ProductUpdate(ProductDto productObj, int UserId);
        public Task <ProductPaginatedResponse<ProductDto>> ProductGridSelect(ProductRequestDto requestOjectWrapper);

    }
}
