﻿using ESGSurvey.BusinessLayer.DTO.Common;
using ESGSurvey.BusinessLayer.DTO.MasterModule;
using ESGSurvey.BusinessLayer.DTO.AdminSurveyModule;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.Interfaces.AdminSurveyModule
{
    public interface IAdminSurveyRepository
    {
        /// <summary>
        /// AdminSurveyGridSelect
        /// </summary>
        /// <param name="requestObjectWrapper"></param>
        /// <returns></returns>
         public Task<PaginatedResponse<SurveyDto>> GetAdminSurveyGridData(SurveyRequestDto requestObjectWrapper);
        /// <summary>
        /// SurveyViewSelect
        /// </summary>
        /// <param name="reportGuid"></param>
        /// <returns></returns>
        public Task<AdminSurveyViewResponse> GetSurveyViewSelect(Guid reportGuid);
        /// <summary>
        /// PillarDropdownSelect
        /// </summary>
        /// <returns></returns>
        public Task<PillarDropdownListDto> PillarDropdownSelect();

        /// <summary>
        /// SectorDropdownSelect
        /// </summary>
        /// <returns></returns>
        public Task<SectorDropdownListDto> SectorDropdownSelect();

    }
}
