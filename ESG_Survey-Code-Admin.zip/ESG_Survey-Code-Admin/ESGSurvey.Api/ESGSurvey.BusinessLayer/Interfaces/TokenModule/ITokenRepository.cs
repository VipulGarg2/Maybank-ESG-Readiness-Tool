﻿using ESGSurvey.BusinessLayer.DTO.TokenModule;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.Interfaces.TokenModule
{
    public interface ITokenRepository
    {
        public Task<TokenDto> TokenSelect(Int16 TokenId);
        public Task <TokenPaginatedResponse<TokenDto>> TokenGridSelect(TokenRequestDto requestOjectWrapper);
        public Task<int> TokenUpsert(TokenDto token ,int UserId);

    }
}
