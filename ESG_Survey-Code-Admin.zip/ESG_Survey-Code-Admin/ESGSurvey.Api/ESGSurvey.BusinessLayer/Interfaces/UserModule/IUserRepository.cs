﻿using ESGSurvey.BusinessLayer.DTO.Common;
using ESGSurvey.BusinessLayer.DTO.UserModule;

namespace ESGSurvey.BusinessLayer.Interfaces.UserModule
{
    public interface IUserRepository
    {
        /// <summary>
        /// This method is used to get user password salt by username
        /// </summary>
        /// <param name="Username"></param>
        /// <returns></returns>
        Task<string> GetUserPasswordSaltByUsername(string Username);
        /// <summary>
        /// This method is used for checking valid username and hashed password.
        /// If correct then return userid
        /// </summary>
        /// <param name="Username"></param>
        /// <param name="HashedPassword"></param>
        /// <returns></returns>
        Task<int?> IsValidUser(string Username, string HashedPassword);
    
        /// <summary>
        /// This method is used for validating user refresh token request
        /// </summary>
        /// <param name="RequestDto"></param>
        /// <returns></returns>
        Task<CustomSuccessResponse> ValidateUserRefreshToken(UserAccessTokenRequestDto RequestDto);

        /// <summary>
        /// This method is used for updating user refresh token expiry time
        /// </summary>
        /// <param name="RefreshTokenUpdateDto"></param>
        /// <returns></returns>
        Task<CustomSuccessResponse> UpdateUserRefreshToken(UserAccessTokenUpdateDto RefreshTokenUpdateDto);

        /// <summary>
        /// This method is used to get user info with roles and permission
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns></returns>
        Task<UserRoleModulePermissionDto> GetUserRoleModulePermissionById(int UserId);

        /// <summary>
        /// Check if user reset password token is valid
        /// </summary>
        /// <param name="Token"></param>
        /// <param name="CurrentDate"></param>
        /// <returns></returns>
        Task<int> IsResetPasswordTokenValid(string Token, int Minutes);

        /// <summary>
        /// Reset User Password
        /// </summary>
        /// <param name="resetPasswordRequestDto"></param>
        /// <returns></returns>
        Task<bool> ResetPassword(ResetPasswordRequestDto resetPasswordRequestDto);

        /// <summary>
        /// This method is used for getting password salt by user Id
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns></returns>
        Task<string> GetPasswordSaltByUserId(int UserId);

        /// <summary>
        /// This method is used for saving reset password detail
        /// </summary>
        /// <param name="resetPasswordSaveDto"></param>
        /// <returns></returns>
        Task<bool> SaveResetPasswordDetails(ResetPasswordSaveDto resetPasswordSaveDto);
        /// <summary>
        /// IsUsernameValid
        /// </summary>
        /// <param name="Username"></param>
        /// <returns></returns>
        Task<ForgotPasswordDto> IsUsernameValid(string Username);


    }
}
