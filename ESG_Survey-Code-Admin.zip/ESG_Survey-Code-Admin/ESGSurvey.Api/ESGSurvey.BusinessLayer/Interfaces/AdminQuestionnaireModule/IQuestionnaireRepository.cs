﻿using ESGSurvey.BusinessLayer.DTO.AdminQuestionnaireModule;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.Interfaces.AdminQuestionnaireModule
{
    public interface IQuestionnaireRepository
    {
        /// <summary>
        /// this method use for get Questionnaire List
        /// </summary>
        /// <returns></returns>
        public Task<QuestionnaireResponseDto> GetQuestionnaireList();
        /// <summary>
        /// this method use for Questionnaire Select by questionId
        /// </summary>
        /// <param name="QuestionsId"></param>
        /// <returns></returns>
        public Task<QuestionnaireDto> GetQuestionnaireSelect(byte QuestionsId);
        /// <summary>
        /// this method use for Questionnaire Update
        /// </summary>
        /// <returns></returns>
        public Task<int> QuestionnaireUpdate(QuestionnaireDto QuestionnaireObj, int UserId);

    }
}
