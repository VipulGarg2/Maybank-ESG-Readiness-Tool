﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.DTO.TokenModule
{
    public class TokenRequestDto
    {
        public int Page { get; set; }
        public int PageSize { get; set; }
        public List<TokenSortByDto> SortBy { get; set; } = new List<TokenSortByDto>();
    }
    public class TokenSortByDto
    {
        public string Id { get; set; } = string.Empty;
        public bool Desc { get; set; } = false;
    }
}
