﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.DTO.UserModule
{

    public class UserAccessTokenRequestDto
    {
        public string RefreshToken { get; set; } = string.Empty;
        public int UserId { get; set; }
    }

    public class UserAccessTokenUpdateDto : UserAccessTokenRequestDto
    {
        public DateTime ExpirationDateTime { get; set; }
    }
}
