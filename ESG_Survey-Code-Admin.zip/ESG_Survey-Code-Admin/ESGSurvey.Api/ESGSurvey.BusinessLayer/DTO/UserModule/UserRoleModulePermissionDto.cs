﻿namespace ESGSurvey.BusinessLayer.DTO.UserModule
{
  
    public class UserRoleModulePermissionDto
    {
        public string? LogoUrl { get; set; }
        public int UserId { get; set; }
        public string? Uname { get; set; }
        public string UserFullName { get; set; } = string.Empty;
        public bool IsFirstLogin { get; set; }
        public List<UserRoleDetailDto>? RoleDetails { get; set; }
    }

    public class Permission
    {
        public int PermissionId { get; set; }
        public string? PermissionName { get; set; }
        public string? PermissionKey { get; set; }
    }
    public class Module
    {
        public int ModuleId { get; set; }
        public string? ModuleName { get; set; }
        public string? ModuleKey { get; set; }
        public int? MenuTypeId { get; set; }
        public string? MenuUrl { get; set; }
        public string? MenuIcon { get; set; }
        public int MenuSort { get; set; }
        public List<Permission>? AllowedPermissions { get; set; }
        public List<Module>? ChildModules { get; set; }
    }
    public class UserRoleDetailDto
    {
        public int RoleId { get; set; }
        public string? RoleName { get; set; }
        public string? RoleKey { get; set; }
        public List<Module>? AllowedModules { get; set; }
    }

    public class UserRoleDetailDBDto
    {
        public int UserId { get; set; }
        public int RoleId { get; set; }
        public string? Uname { get; set; }
        public string? RoleName { get; set; }
        public string? RoleKey { get; set; }
        public bool IsFirstLogin { get; set; }
    }


    public class UserModuleDetailDBDto
    {
        public int RoleId { get; set; }
        public int PermissionId { get; set; }
        public string? PermissionName { get; set; }
        public string? PermissionKey { get; set; }
        public int ModuleId { get; set; }
        public string? ModuleName { get; set; }
        public string? ModuleKey { get; set; }
        public int? MenuTypeId { get; set; }
        public string? MenuUrl { get; set; }
        public string? MenuIcon { get; set; }
        public int MenuSort { get; set; }
        public int? ParentId { get; set; }

    }
}
