﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.DTO.UserModule
{
    public class LoginResponseDto
    {
        public int UserId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string RefreshToken { get; set; } = string.Empty;
        public string AccessToken { get; set; } = string.Empty;
        public bool IsFirstLogin { get; set; }
        public ResetPasswordRequestDto ResetPasswordRequestDto { get; set; } = new ResetPasswordRequestDto();
        public UserRoleModulePermissionDto UserRoleModulePermissionDto { get; set; } = new UserRoleModulePermissionDto();
    }
}
