﻿namespace ESGSurvey.BusinessLayer.DTO.UserModule
{
    public class ResetPasswordRequestDto
    {
        public int UserId { get; set; }
        public string Password { get; set; }=string.Empty;
        public string ConfirmPassword { get; set; } = string.Empty;
        public string Token { get; set; } = string.Empty;
    }

    public class ResetPasswordSaveDto
    {
        public string ResetPasswordUrl { get; set; } = string.Empty;
        public string Username { get; set; } = string.Empty;
        public int UserId { get; set; }
        public string Token { get; set; } = string.Empty;
        public DateTime ExpirationDate { get; set; }
        public int ResetTokenExpiryMinutes { get; set; }

    }
}
