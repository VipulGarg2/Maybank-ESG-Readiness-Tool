﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.DTO.UserModule
{
    public class ForgotPasswordDto
    {
        public int UserId { get; set; } = 0;
        public string EmailAddress { get; set; } = string.Empty;
    }
}
