﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.DTO.MasterModule
{
    public class AllQuestionResponseDto
    {
        public string BusinessEntityName { get; set; } = string.Empty;
        public string BusinessUEN { get; set; } = string.Empty;
        public byte CompanyTurnoverId { get; set; } = 0;
        public Int16 OrganizationSectorId { get; set; } = 0;
        public string NameOfPrimaryContact { get; set; } = string.Empty;
        public string RoleOfPrimaryContact { get; set; } = string.Empty;
        public string CorporateEmailAddressPrimaryContact { get; set; } = string.Empty;
        public string PhoneNumberPrimaryContact { get; set; } = string.Empty;
        public bool IsExistingMaybankCustomer { get; set; } = false;
        public bool IsExploringGreenSolution { get; set; } = false;
        public byte ScaleOfTransitionToGreenerSolutions { get; set; } = 0;
        public bool IsConsentTermsAccepted { get; set; } = false;
        public string CaptchaToken { get; set; } = string.Empty;
        public List<PillarDto> Pillers { get; set; } = new List<PillarDto>();
    }

    
    public class PillarDto
    {
        public byte PillarId { get; set; } = 0;
        public string PillarName { get; set; } = string.Empty;
        public List<QuestionsDto> Questions { get; set; } = new List<QuestionsDto>();
    }

   

    public class QuestionsDto
    {
        public byte QuestionsId { get; set; } = 0;
        public string QuestionsName { get; set; } = string.Empty;
        public string Guideline { get; set; } = string.Empty;
        public byte QuestionsTypeId { get; set; } = 0;
        public string QuestionsTypeName { get; set; } = string.Empty;
        public byte PillarId { get; set; } = 0;
        public string PillarName { get; set; } = string.Empty;
        public byte DisplayOrder { get; set; } = 0;
        public List<PredefinedAnswersDto> PredefinedAnswers { get; set; } = new List<PredefinedAnswersDto>();
    }

    public class QuestionsTypeDto
    {
        public byte QuestionsTypeId { get; set; } = 0;
        public string QuestionsTypeName { get; set; } = string.Empty;
    }

    public class PredefinedAnswersDto
    {
        public byte PredefinedAnswersId { get; set; } = 0;
        public byte QuestionsTypeId { get; set; } = 0;
        public string QuestionsTypeName { get; set; } = string.Empty;
        public string AnswerText { get; set; } = string.Empty;
        public byte DisplayOrder { get; set; } = 0;
        public bool IsSelected { get; set; } = false;
    }

    
    public class OrganizationSectorResponseDto
    {
        public List<OrganizationSectorDto> LstOrganizationSector { get; set; } = new List<OrganizationSectorDto>();
    }
    public class OrganizationSectorDto
    {
        public Int16 OrganizationSectorId { get; set; } = 0;
        public string OrganizationSectorName { get; set; } = string.Empty;
    }

    public class CompanyTurnoverResponseDto
    {
        public List<CompanyTurnoverDto> LstCompanyTurnoverDto { get; set; } = new List<CompanyTurnoverDto>();
    }
    public class CompanyTurnoverDto
    {
        public byte CompanyTurnoverId { get; set; } = 0;
        public string CompanyTurnoverName { get; set; } = string.Empty;
    }

    public class GroupedOptionsResponseDto
    {
        public List<SubGroupDropdownDto> LstDropdownData { get; set; } = new List<SubGroupDropdownDto>();
    }
    public class SubGroupDropdownDto
    {
        public string Label { get; set; } = string.Empty;
        public List<CommonDropdownDto> Options { get; set; } = new List<CommonDropdownDto>();
    }
    public class SubGroupDropdownDbDto
    {
        public int Value { get; set; }
        public string Label { get; set; } = string.Empty;
        public int? OrganizationGroupSectorId { get; set; }
    }

    public class CommonDropdownResponseDto
    {
        public List<CommonDropdownDto> LstDropdownData { get; set; }= new List<CommonDropdownDto>();
    }
    public class CommonDropdownDto
    {
        public int Value { get; set; }
        public string Label { get; set; } = string.Empty;
    }
}
