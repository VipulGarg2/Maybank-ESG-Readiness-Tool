﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.DTO.AdminQuestionnaireModule
{
    public class QuestionnaireDto
    {
        public byte QuestionsId { get; set; } = 0;
        public string QuestionsName { get; set; } = string.Empty;
        public string Guideline { get; set; } = string.Empty;
        public byte PillarId { get; set; } = 0;
        public string PillarName { get; set; } = string.Empty;
        public Int16? AnswerRecommendationId { get; set; } = 0;
        public byte PredefinedAnswersId { get; set; } = 0;
        public string YesRecommendation { get; set; } = string.Empty;
        public string NoRecommendation { get; set; } = string.Empty;

        public int UserId { get; set; } = 0;
    }

    public class QuestionnaireResponseDto
    {
        public List<QuestionnaireDto> QuestionnaireList { get; set; }=new List<QuestionnaireDto>();
    }
}
