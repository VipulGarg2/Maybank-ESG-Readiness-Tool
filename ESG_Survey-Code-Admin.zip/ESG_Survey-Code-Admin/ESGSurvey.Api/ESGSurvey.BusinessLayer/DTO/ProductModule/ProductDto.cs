﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.DTO.ProductModule
{
    public class ProductDto
    {
        public short? ProductId { get; set; }
        public byte PillarId { get; set; } = 0;
        public string ProductName { get; set; } = string.Empty;
        public string PillarName { get; set; } = string.Empty;
        public string ProductURL { get; set; } = string.Empty;
        public string ProductDescription { get; set; } = string.Empty;
        public int? UserId { get; set; }
        public bool IsDeleted { get; set; }
    }

    public class ProductSelectResponseDto
    {
        public List<ProductDto> Products { get; set; } = new List<ProductDto>();

    }
}