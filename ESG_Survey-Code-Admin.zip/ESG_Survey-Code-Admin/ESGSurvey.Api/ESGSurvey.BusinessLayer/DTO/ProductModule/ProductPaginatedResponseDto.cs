﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.DTO.ProductModule
{
    public class ProductPaginatedResponse<T>
    {
        public List<T> Data { get; set; } = new List<T>(); // The list of survey data for the current page
        public int RecordsTotal { get; set; } // Total number of records in the dataset
        public int RecordsFiltered { get; set; } // Total records after filtering
    }
}
