﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.DTO.ProductModule
{
    public class ProductRequestDto
    {
        public int Page { get; set; }
        public int PageSize { get; set; }
        public List<ProductSortByDto> SortBy { get; set; } = new List<ProductSortByDto>();
    }
    public class ProductSortByDto
    {
        public string Id { get; set; } = string.Empty;
        public bool Desc { get; set; } = false;
    }
}
