﻿using ESGSurvey.BusinessLayer.Extensions;
using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace ESGSurvey.BusinessLayer.DTO.Common
{
    public class CustomSuccessResponse
    {
        public int? Id { get; set; }
        public CustomSuccessResponseEnums StatusCode { get; set; }
        public string Message
        {
            get
            {
                return StatusCode.Description();
            }
        }
        public string ErrorMessage { get; set; } = string.Empty;
    }

    public class RecaptchaResponse
    {
        public bool success { get; set; }
        public string challenge_ts { get; set; } = string.Empty;
        public string hostname { get; set; } = string.Empty;
        [JsonProperty("error-codes")]
        public List<string> error_codes{get;set;}=new List<string>();
    }
}
