﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.DTO.AdminSurveyModule
{
    public class AdminSurveyGridInternalDto
    {
        public int SurveyId { get; set; }
        public int OrganizationDetailsId { get; set; }
        public string SurveyName { get; set; }=string.Empty;
        public string UserName { get; set; } = string.Empty;
        public string BusinessEntityName { get; set; } = string.Empty;
        public double Score { get; set; }
        public DateTime? SubmittedOn { get; set; }
        public string FormatedSubmittedOn { get; set; } = string.Empty;
        public string CompanySector { get; set; } = string.Empty;
  
    }

    public class AdminSurveyViewSelectDto
    {
        public int OrganizationDetailsId { get; set; } = 0;
        public int QuestionsId { get; set; } = 0;
        public string QuestionsName { get; set; } = string.Empty;
        public int QuestionsTypeId { get; set; } = 0;
        public int PillarId { get; set; } = 0;
        public string PillarName { get; set; } = string.Empty;
        public double Score { get; set; } = 0;
        public int DisplayOrder { get; set; } = 0;
        public int PredefinedAnswersId { get; set; } = 0;
        public string AnswerText { get; set; } = string.Empty;
    }
    public class AdminSurveyViewResponse
    { 
        public List<AdminSurveyViewSelectDto> SurveyDetailsList { get; set; } =new List<AdminSurveyViewSelectDto>();
        

    }
    public class AdminPillarDto
    {
        public int? PillarId { get; set; } 
        public string PillarTitle { get; set; } = string.Empty;
        public string PillarName { get; set; } = string.Empty;
    }
    public class AdminSectorDto
    {
        public int OrganizationSectorId { get; set; } = 0;
        public string OrganizationSectorName { get; set; } = string.Empty;
    }
    public class PillarDropdownListDto
    {
       public List<AdminPillarDto> PiilarList { get; set; } = new List<AdminPillarDto>();

    }
    public class SectorDropdownListDto
    {
         public List<AdminSectorDto> SectorList { get; set; } = new List<AdminSectorDto>();

    }
    public class EsgNgbDateModel
    {
        public int year { get; set; }
        public int month { get; set; }
        public int day { get; set; }

    }

    public class EsgNgbTimeModel
    {
        public int hour { get; set; }
        public int minute { get; set; }
        public int second { get; set; }

    }
}
