﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.DTO.AdminSurveyModule
{
    public class PaginatedResponse<T>
    {
        public List<T> Data { get; set; } = new List<T>();// The list of survey data for the current page
        public int RecordsTotal { get; set; } // Total number of records in the dataset
        public int RecordsFiltered { get; set; } // Total records after filtering
    }

    public class SurveyDto
    {
        public string SurveyName { get; set; } = string.Empty;
        public string BusinessEntityName { get; set; } = string.Empty;
        public string BusinessUEN { get; set; } = string.Empty;
        public string CompanyTurnoverName { get; set; } = string.Empty;
        public string NameOfPrimaryContact { get; set; } = string.Empty;
        public string RoleOfPrimaryContact { get; set; } = string.Empty;
        public string CorporateEmailAddressPrimaryContact { get; set; } = string.Empty;
        public string PhoneNumberPrimaryContact { get; set; } = string.Empty;
        public string IsExistingMaybankCustomer { get; set; } = string.Empty;
        public string CreatedDate { get; set; } = string.Empty;
        public string OrganizationSectorName { get; set; } = string.Empty;
        public int OrganizationSectorId { get; set; }
        public Guid ReportGuid { get; set; }
        public int OrganizationDetailsId { get; set; }
        public decimal Score { get; set; }
        public string MaturityLevel { get; set; } = string.Empty;
        public DateTime? SubmittedOn { get; set; }

    }

    

}
