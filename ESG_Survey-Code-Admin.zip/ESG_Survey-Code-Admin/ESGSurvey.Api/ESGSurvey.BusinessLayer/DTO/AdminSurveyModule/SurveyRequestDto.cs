﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGSurvey.BusinessLayer.DTO.AdminSurveyModule
{
    public class SurveyRequestDto
    {
        public string GlobalSearchText { get; set; } = string.Empty; // Optional search filter by user name
        public int? OrganizationSectorId { get; set; } // Optional search filter by sector
        //public DateTime? SubmittedOn { get; set; } // Optional search filter by submitted date
        public DateTime? FromSubmittedOn { get; set; }
        public DateTime? TillSubmittedOn { get; set; } 
        public int Page { get; set; }
        public int PageSize { get; set; }
        public List<SortByDto> SortBy { get; set; } = new List<SortByDto>();
    }
    public class SortByDto
    {
        public string Id { get; set; } = string.Empty;
        public bool Desc { get; set; } = false;
    }
}
