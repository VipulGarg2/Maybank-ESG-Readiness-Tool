using ESGSurvey.Api.Extensions;
using ESGSurvey.Api.Helper.Implementations;
using ESGSurvey.Api.Helper.Interfaces;
using ESGSurvey.BusinessLayer.Interfaces.AdminQuestionnaireModule;
using ESGSurvey.BusinessLayer.Interfaces.AdminSurveyModule;
using ESGSurvey.DataLayer.AdminSurveyModule;
using ESGSurvey.BusinessLayer.Interfaces.UserModule;
using ESGSurvey.DataLayer.AdminQuestionnaireModule;
using ESGSurvey.DataLayer.UserModule;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Serilog;
using System.Text;
using ESGSurvey.BusinessLayer.Interfaces.TokenModule;
using ESGSurvey.DataLayer.TokenModule;
using ESGSurvey.BusinessLayer.Interfaces.ProductModule;
using ESGSurvey.DataLayer.ProductModule;
var builder = WebApplication.CreateBuilder(args);
var logger = new LoggerConfiguration()
    .ReadFrom.Configuration(builder.Configuration)
    .Enrich.FromLogContext()
    .CreateLogger();

logger.Debug("init main");
try
{
    builder.Logging.ClearProviders();
    builder.Logging.SetMinimumLevel(LogLevel.Warning);
    builder.Host.UseSerilog(logger);
   
    // Retrieve the secret from the configuration
    string? secret = builder.Configuration["JwtSettings:Secret"];

    // Check if the secret is null and handle it accordingly
    if (secret == null)
    {
        throw new InvalidOperationException("JwtSettings:Secret configuration value is not set.");
    }
    byte[] jwtSecretBytes = Encoding.UTF8.GetBytes(secret);
    SymmetricSecurityKey signingKey = new SymmetricSecurityKey(jwtSecretBytes);

    builder.Services.AddCors(options =>
    {
        options.AddPolicy("AllowAll", corsBuilder => corsBuilder
          .AllowAnyOrigin()
          .AllowAnyMethod()
          .AllowAnyHeader()
          .SetPreflightMaxAge(TimeSpan.FromDays(7))
          );
    });

    builder.Services.AddAuthentication(options =>
    {
        options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    })
           .AddJwtBearer(options =>
           {
               options.RequireHttpsMetadata = false;
               options.SaveToken = true;
               options.TokenValidationParameters = new TokenValidationParameters
               {
                   ValidateLifetime = true,
                   ValidateIssuerSigningKey = true,
                   IssuerSigningKey = signingKey,
                   ValidateIssuer = false,
                   ValidateAudience = false,
                   ClockSkew = TimeSpan.FromSeconds(0)
               };
               options.Events = new JwtBearerEvents
               {
                   OnAuthenticationFailed = context =>
                   {
                       var logger = context.HttpContext.RequestServices.GetRequiredService<ILogger<Program>>();
                       logger.LogError("Authentication failed. Exception: {Exception}", context.Exception);
                       return Task.CompletedTask;
                   },
               };
           });
    builder.Services.AddControllersWithViews().AddSessionStateTempDataProvider();
    builder.Services.AddSession();
    builder.Services.AddHttpContextAccessor();
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen(options =>
    {
        options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
        {
            In = ParameterLocation.Header,
            Description = "Please enter a valid token",
            Name = "Authorization",
            Type = SecuritySchemeType.Http,
            BearerFormat = "JWT",
            Scheme = "Bearer"
        });
        options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type=ReferenceType.SecurityScheme,
                    Id="Bearer"
                }
            },
            new string[]{}
        }
    });
    });

    // Add services to the container.
    
    builder.Services.AddScoped<IEmailSender, EmailSender>();
    builder.Services.AddScoped<IUserRepository, UserRepository>();
    builder.Services.AddScoped<IQuestionnaireRepository, QuestionnaireRepository>();
    builder.Services.AddScoped<IAdminSurveyRepository, AdminSurveyRepository>();
	builder.Services.AddScoped<ITokenRepository, TokenRepository>();
	builder.Services.AddScoped<IProductRepository, ProductRepository>();
	builder.Services.AddControllers();

    builder.Services.AddSingleton<CacheHelper>();

    // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen();

    var app = builder.Build();
    var env = app.Environment;
    // Configure the HTTP request pipeline.
   
    app.UseSwagger();
    app.UseSwaggerUI();
    

    app.UseHttpsRedirection();
    app.UseStaticFiles();
    app.UseCors("AllowAll");

    app.UseAuthentication();

    app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
    Rotativa.AspNetCore.RotativaConfiguration.Setup(env.WebRootPath, "Rotativa");

    app.UseAuthorization();

    app.MapControllers();

    app.Run();
}
catch (Exception exception)
{
    // NLog: catch setup errors
    logger.Error(exception, "Stopped program because of exception");
    throw;
}
finally
{
    // Ensure to flush and stop internal timers/threads before application-exit (Avoid segmentation fault on Linux)
    logger.Dispose();
}