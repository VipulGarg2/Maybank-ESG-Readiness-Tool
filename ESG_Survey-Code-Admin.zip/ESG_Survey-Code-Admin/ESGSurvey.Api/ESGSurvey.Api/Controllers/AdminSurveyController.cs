using ESGSurvey.BusinessLayer;
using ESGSurvey.BusinessLayer.DTO.Common;
using ESGSurvey.BusinessLayer.DTO.AdminSurveyModule;
using ESGSurvey.BusinessLayer.DTO.UserModule;
using ESGSurvey.BusinessLayer.Interfaces.AdminSurveyModule;
using ESGSurvey.BusinessLayer.Interfaces.UserModule;
using ESGSurvey.BusinessLayer.Utilities;
using ESGSurvey.DataLayer.UserModule;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using ESGSurvey.Api.Filters;

namespace ESGSurvey.Api.Controllers
{
    [Authorize]
    [ApiController]
    [ApiKeyCheck]
    [Route("[controller]")]
    public class AdminSurveyController : ControllerBase
    {
        #region Declaration & Constructor
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IAdminSurveyRepository _adminSurveyRepository;


        public AdminSurveyController(IConfiguration config, IHttpContextAccessor httpContextAccessor, IAdminSurveyRepository adminSurveyRepository)
        {
            _config = config;
            _httpContextAccessor = httpContextAccessor;
            _adminSurveyRepository = adminSurveyRepository;
        }

        private string GetUploadFolderPath()
        {
            return _config["FileStorage:Path"];
        }

        #endregion Declaration & Constructor

        #region Public Methods
        /// <summary>
        /// This api method is used to get admin Survey Grid Data
        /// </summary>
        /// <param name="Request"></param>
        /// <returns></returns>
        [HttpPost("GetAdminSurveyGridData")]
        public async Task<ActionResult> GetAdminSurveyGridData([FromBody] SurveyRequestDto request)
        {
            if (request.Page < 0 || request.PageSize <= 0)
            {
                return BadRequest("Invalid pagination parameters.");
            }
            var surveyDataList = await _adminSurveyRepository.GetAdminSurveyGridData(request);
            return Ok(surveyDataList);
        }
        /// <summary>
        /// This api method is used to get  Survey Deatils by organizationDetailsId
        /// </summary>
        /// <param name="organizationDetailsId"></param>
        /// <returns></returns>
        [HttpGet("GetSurveyViewSelect")]
        public async Task<ActionResult<AdminSurveyViewResponse>> GetSurveyViewSelect(Guid reportGuid)
        {

            var surveyViewList = await _adminSurveyRepository.GetSurveyViewSelect(reportGuid);
            return Ok(surveyViewList);
        }
        /// <summary>
        /// This api method is used to get  All Pillar List
        /// </summary>
        /// <returns></returns>
        [HttpGet("PillarDropdownSelect")]
        public async Task<ActionResult<PillarDropdownListDto>> PillarDropdownSelect()
        {

          var result = await _adminSurveyRepository.PillarDropdownSelect();
            return Ok(result);

        }
        /// <summary>
        /// This api method is used to get  All Sector List
        /// </summary>
        /// <returns></returns>
        [HttpGet("SectorDropdownSelect")]
        public async Task<ActionResult<SectorDropdownListDto>> SectorDropdownSelect()
        {
            var result = await _adminSurveyRepository.SectorDropdownSelect();
            return Ok(result);
        }

        /// <summary>
        /// Retrieves the ESG Maturity Assessment Report by GUID.
        /// </summary>
        /// <param name="guid">The unique identifier for the report.</param>
        /// <returns>An ActionResult containing the report file if found; otherwise, returns a NotFound result.</returns>
        /// <response code="200">Returns the report file.</response>
        /// <response code="404">If the report file does not exist.</response>
        [HttpGet("GetEsgMaturityAssessmentReport")]
        public async Task<ActionResult> GetEsgMaturityAssessmentReport(string guid)
        {
            try
            {
                if (!Guid.TryParse(guid, out _))
                {
                    return BadRequest("Invalid GUID format.");
                }

                var filePath = Path.Combine(GetUploadFolderPath(), $"ESGReadinessAssessmentReport_{guid}.pdf");
                if (!System.IO.File.Exists(filePath))
                {
                    return NotFound("Report not found.");
                }

                var fileBytes = await System.IO.File.ReadAllBytesAsync(filePath);
                return File(fileBytes, "application/pdf", $"ESGReadinessAssessmentReport.pdf");
            }
            catch (Exception ex)
            {
                // Log the exception (consider using a logging framework)
                Console.WriteLine($"Error retrieving report: {ex.Message}");
                return StatusCode(500, "Internal server error.");
            }
        }
        #endregion Public Methods


    }
}
