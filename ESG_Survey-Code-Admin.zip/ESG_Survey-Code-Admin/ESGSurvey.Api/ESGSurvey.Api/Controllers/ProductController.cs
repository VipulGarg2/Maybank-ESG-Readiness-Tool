﻿using ESGSurvey.Api.Filters;
using ESGSurvey.BusinessLayer.DTO.ProductModule;
using ESGSurvey.BusinessLayer.Interfaces.ProductModule;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ESGSurvey.Api.Controllers
{
    [Authorize]
    [ApiController]
    [ApiKeyCheck]
    [Route("[controller]")]

    public class ProductController : Controller
    {

        #region Declaration & Constructor
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IProductRepository _productRepository;


        public ProductController(IConfiguration config, IHttpContextAccessor httpContextAccessor, IProductRepository productRepository)
        {
            _config = config;
            _httpContextAccessor = httpContextAccessor;
            _productRepository = productRepository;
        }

        #endregion Declaration & Constructor

        #region Public Methods

        [Authorize]
        [HttpPost]
        [Route("ProductGridSelect")]

        public async Task<ActionResult> ProductGridSelect([FromBody] ProductRequestDto productDto)
        {
            if (productDto.Page < 0 || productDto.PageSize <= 0)
            {
                return BadRequest("Invalid pagination parameters.");
            }
            var productList = await _productRepository.ProductGridSelect(productDto);
            return Ok(productList);
        }

        [Authorize]
        [HttpGet]
        [Route("ProductSelect")]
        public async Task<ActionResult<ProductDto>> GetProductSelect(byte ProductId)
        {
            var productList = await _productRepository.GetProductSelect(ProductId);
            return Ok(productList);
        }

        [HttpPost]
        [Route("ProductUpdate")]
        public async Task<ActionResult<int>> ProductUpdate(ProductDto productDto)
        {
            int UserId = Convert.ToInt32(User.Claims.First(x => x.Type == ClaimTypes.NameIdentifier).Value);
            return Ok(await _productRepository.ProductUpdate(productDto, UserId));
        }
        #endregion
    }
}