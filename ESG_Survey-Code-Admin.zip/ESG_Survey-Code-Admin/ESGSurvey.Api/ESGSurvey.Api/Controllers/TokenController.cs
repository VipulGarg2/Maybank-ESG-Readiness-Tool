﻿using ESGSurvey.Api.Filters;
using ESGSurvey.BusinessLayer.DTO.TokenModule;
using ESGSurvey.BusinessLayer.Interfaces.TokenModule;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ESGSurvey.Api.Controllers
{
    [Authorize]
    [ApiController]
    [ApiKeyCheck]
    [Route("[controller]")]
    public class TokenController : ControllerBase
    {
        #region Declaration & Constructor
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ITokenRepository _tokenRepository;


        public TokenController(IConfiguration config, IHttpContextAccessor httpContextAccessor, ITokenRepository tokenRepository)
        {
            _config = config;
            _httpContextAccessor = httpContextAccessor;
            _tokenRepository = tokenRepository;
        }

        #endregion Declaration & Constructor

        #region Public Methods
        [Authorize]
        [HttpPost]
        [Route("TokenGridSelect")]
        public async Task<ActionResult> TokenGridSelect([FromBody] TokenRequestDto tokenDto)
        {
            if (tokenDto.Page < 0 || tokenDto.PageSize <= 0)
            {
                return BadRequest("Invalid pagination parameters.");
            }
            var tokenList = await _tokenRepository.TokenGridSelect(tokenDto);
            return Ok(tokenList);
        }

        [Authorize]
        [HttpGet]
        [Route("TokenSelect")]
        public async Task<ActionResult<TokenDto>> TokenSelect(short TokenId)
        {

            var tokenList = await _tokenRepository.TokenSelect(TokenId);
            return Ok(tokenList);
        }

        [Authorize]
        [HttpPost]
        [Route("TokenUpsert")]
        public async Task<ActionResult<int>> TokenUpsert(TokenDto tokenDto)
        {
            if (_httpContextAccessor.HttpContext != null)
            {
                int UserId = Convert.ToInt32(_httpContextAccessor.HttpContext.User.Claims.First(x => x.Type == ClaimTypes.NameIdentifier).Value);
                var result = await _tokenRepository.TokenUpsert(tokenDto, UserId);
                return Ok(result);
            }
            return Ok(await Task.FromResult(new long()));
        }
        #endregion
    }
}