using ESGSurvey.Api.Filters;
using ESGSurvey.BusinessLayer;
using ESGSurvey.BusinessLayer.DTO.AdminQuestionnaireModule;
using ESGSurvey.BusinessLayer.DTO.Common;
using ESGSurvey.BusinessLayer.DTO.UserModule;
using ESGSurvey.BusinessLayer.Interfaces.UserModule;
using ESGSurvey.BusinessLayer.Utilities;
using ESGSurvey.DataLayer.UserModule;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace ESGSurvey.Api.Controllers
{
    [Authorize]
    [ApiController]
    [ApiKeyCheck]
    [Route("[controller]")]
    public class AdminQuestionnaireController : ControllerBase
    {
        #region Declaration & Constructor
        private readonly IConfiguration _config;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly BusinessLayer.Interfaces.AdminQuestionnaireModule.IQuestionnaireRepository _questionnaireRepository;
        
        public AdminQuestionnaireController(IConfiguration config, IHttpContextAccessor httpContextAccessor,
            BusinessLayer.Interfaces.AdminQuestionnaireModule.IQuestionnaireRepository questionnaireRepository)
        {
            _config = config;
            _httpContextAccessor = httpContextAccessor;
            _questionnaireRepository = questionnaireRepository;
        }

        #endregion Declaration & Constructor

        #region Public Methods
        /// <summary>
        /// this method use for Get all Questionnaire List
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetQuestionnaireList")]
        public async Task<ActionResult<QuestionnaireResponseDto>> GetQuestionnaireList()
        {

            var QuestionnaireList = await _questionnaireRepository.GetQuestionnaireList();
            return Ok(QuestionnaireList);

        }
        /// <summary>
        /// this method use for Questionnaire Select by questionId
        /// </summary>
        /// <param name="QuestionsId"></param>
        /// <returns></returns>
        [HttpGet("GetQuestionnaireSelect")]
        public async Task<ActionResult<QuestionnaireDto>> GetQuestionnaireSelect(byte QuestionsId)
        {
            return Ok(await _questionnaireRepository.GetQuestionnaireSelect(QuestionsId));

        }

        /// <summary>
        /// this meethod use for  Questionnaire Update
        /// </summary>
        /// <param name="QuestionnaireObj"></param>
        /// <param name="UserId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("QuestionnaireUpdate")]
        public async Task<ActionResult<int>> QuestionnaireUpdate(QuestionnaireDto QuestionnaireObj)
        {
            int userId = Convert.ToInt32(User.Claims.First(x => x.Type == ClaimTypes.NameIdentifier).Value);
            return Ok(await _questionnaireRepository.QuestionnaireUpdate(QuestionnaireObj, userId));
        }


        #endregion Public Methods


    }
}
