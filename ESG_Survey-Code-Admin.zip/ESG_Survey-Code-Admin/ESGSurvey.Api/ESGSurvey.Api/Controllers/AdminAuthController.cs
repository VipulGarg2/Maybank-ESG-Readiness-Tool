using ESGSurvey.Api.Extensions;
using ESGSurvey.Api.Filters;
using ESGSurvey.Api.Helper.Interfaces;
using ESGSurvey.BusinessLayer;
using ESGSurvey.BusinessLayer.DTO.UserModule;
using ESGSurvey.BusinessLayer.Interfaces.UserModule;
using ESGSurvey.BusinessLayer.Utilities;
using ESGSurvey.DataLayer.UserModule;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Reflection;
using System.Security.Claims;
using System.Text;

namespace ESGSurvey.Api.Controllers
{
    [ApiController]
    [ApiKeyCheck]
    [Route("[controller]")]
    public class AdminAuthController : Controller
    {
        #region Declaration & Constructor
        private readonly IConfiguration _config;
        private readonly IUserRepository _userRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IEmailSender _emailSender;

        public AdminAuthController(IConfiguration config,IUserRepository userRepository,
            IHttpContextAccessor httpContextAccessor, IEmailSender emailSender)
        {
            _config = config;
            _userRepository = userRepository;
            _httpContextAccessor = httpContextAccessor;
            _emailSender = emailSender;
        }

        #endregion Declaration & Constructor

        #region Public Methods
        /// <summary>
        /// This api method is used to get token for user after successfull authentication of login credentials
        /// </summary>
        /// <param name="loginRequest"></param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpPost("Login")]
        public async Task<ActionResult<LoginResponseDto>> Login([FromBody] LoginDto loginRequest)
        {
            //Get password salt for user
            var passwordSalt = await _userRepository.GetUserPasswordSaltByUsername(loginRequest.Username);
            if (string.IsNullOrEmpty(passwordSalt))
            {
                return Unauthorized();
            }

            //Get userid
            var userId = await _userRepository.IsValidUser(loginRequest.Username, PasswordHelper.HashPassword(loginRequest.Password, passwordSalt));

            if (userId == null)
            {
                return Unauthorized();
            }
            LoginResponseDto response = await GetLoginResponse(userId.Value);
            var userDto = await _userRepository.GetUserRoleModulePermissionById(userId.Value);

            ResetPasswordRequestDto resetPasswordObj = new ResetPasswordRequestDto();
            if (userDto.IsFirstLogin == true)
            {
                ResetPasswordSaveDto resetPasswordSaveDto = new ResetPasswordSaveDto()
                {
                    ExpirationDate = DateTime.UtcNow.AddHours(24),
                    Token = Guid.NewGuid().ToString(),
                    UserId = userId.Value,
                    Username = loginRequest.Username,
                    ResetTokenExpiryMinutes = Convert.ToInt32(_config["ResetToken:ExpirationInMinutes"]!)
                };
                await _userRepository.SaveResetPasswordDetails(resetPasswordSaveDto);
                resetPasswordObj.UserId= userId.Value;
                resetPasswordObj.Token = resetPasswordSaveDto.Token;
                response.ResetPasswordRequestDto = resetPasswordObj;
            }
            response.UserName = loginRequest.Username;
            response.IsFirstLogin = userDto.IsFirstLogin;
            response.UserRoleModulePermissionDto = userDto;
            return Ok(response);
        }


        /// <summary>
        /// This method is used for getting the access token by refresh token
        /// </summary>
        /// <param name="userAccessTokenRequestDto"></param>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpPost("GetAccessToken")]
        public async Task<ActionResult<string>> GetAccessToken([FromBody] UserAccessTokenRequestDto userAccessTokenRequestDto)
        {

            //Validate if refresh token is valid
            var response = await _userRepository.ValidateUserRefreshToken(userAccessTokenRequestDto);
            if (response.StatusCode != CustomSuccessResponseEnums.SUCCESS)
            {
                return Unauthorized(response);
            }
            var token = GetUserAccessToken(userAccessTokenRequestDto.UserId);
            return Ok(token);

        }

        /// <summary>
        /// This method is used to get user info with roles and permission
        /// </summary>
        /// <returns></returns>
        [Authorize]
        [HttpGet("getUserRoleModulePermissionDetail")]
        public async Task<ActionResult<UserRoleModulePermissionDto>> GetUserRoleModulePermissionDetail()
        {
            
            var result = await _userRepository.GetUserRoleModulePermissionById(
                    Convert.ToInt32(User.Claims.First(x => x.Type == ClaimTypes.NameIdentifier).Value)
                   );
              
            return Ok(result);

        }

        [AllowAnonymous]
        [HttpGet("CheckResetTokenStatus")]
        public async Task<ActionResult<bool>> CheckResetTokenStatus(string Token)
        {
            var userId = await _userRepository.IsResetPasswordTokenValid(Token, Convert.ToInt32(_config["ResetToken:ExpirationInMinutes"]!));
            if (userId == 0)
            {
                ModelState.AddModelError("InvalidToken", "Reset Password link has been expired.");
                return BadRequest(ModelState);
            }
            return Ok(true);
        }

        [AllowAnonymous]
        [HttpPost("ChangePassword")]
        public async Task<ActionResult<bool>> ChangePassword([FromBody] ResetPasswordRequestDto resetPasswordRequestDto)
        {
            var userId = await _userRepository.IsResetPasswordTokenValid(resetPasswordRequestDto.Token, Convert.ToInt32(_config["ResetToken:ExpirationInMinutes"]!));
            if (userId > 0)
            {
                var passwordSalt = await _userRepository.GetPasswordSaltByUserId(userId);
                if (string.IsNullOrEmpty(passwordSalt))
                {
                    return Unauthorized();
                }
                resetPasswordRequestDto.UserId = userId;
                resetPasswordRequestDto.Password = PasswordHelper.HashPassword(resetPasswordRequestDto.ConfirmPassword, passwordSalt);
                return Ok(await _userRepository.ResetPassword(resetPasswordRequestDto));
            }
            ModelState.AddModelError("InvalidToken", "Password Reset Token is not valid.");
            return BadRequest(ModelState);
        }

        [AllowAnonymous]
        [HttpPost("ForgotPassword")]
        public async Task<ActionResult<bool>> ForgotPassword([FromBody] LoginDto model)
        {
            //Check if username is valid
            ForgotPasswordDto forgotPassword = await _userRepository.IsUsernameValid(model.Username);
            if (forgotPassword?.UserId > 0)
            {
                //Send reset password link
                ResetPasswordSaveDto resetPasswordSaveDto = new ResetPasswordSaveDto()
                {
                    ExpirationDate = DateTime.UtcNow.AddMinutes(Convert.ToInt32(_config["RefreshToken:ExpirationInMinutes"])),
                    Token = Guid.NewGuid().ToString(),
                    UserId = forgotPassword.UserId,
                    Username = model.Username,
                    ResetPasswordUrl = _config["ResetPasswordUrl"]!,
                    ResetTokenExpiryMinutes = Convert.ToInt32(_config["ResetToken:ExpirationInMinutes"]!)
                };

                await _userRepository.SaveResetPasswordDetails(resetPasswordSaveDto);

                var emailBody = await this.RenderViewToStringAsync("ForgotPassword", resetPasswordSaveDto, TempData);
                await _emailSender.SendEmailAsync(forgotPassword.EmailAddress, "Password Reset Request for Your Admin Account", emailBody);

            }
            return Ok(true);
        }

        #endregion Public Methods

        #region Private Methods
        private async Task<LoginResponseDto> GetLoginResponse(int userId)
        {
            var refreshToken = Guid.NewGuid().ToString();
            UserAccessTokenUpdateDto refreshTokenUpdateDto = new UserAccessTokenUpdateDto
            {
                UserId = userId,
                ExpirationDateTime = DateTime.Now.AddMonths(ESGSurveyConstant.REFRESH_TOKEN_EXPIRATION_IN_MONTH),
                RefreshToken = refreshToken
            };

            await _userRepository.UpdateUserRefreshToken(refreshTokenUpdateDto);

            LoginResponseDto response = new LoginResponseDto()
            {
                UserId = userId,
                RefreshToken = refreshToken,
                AccessToken = GetUserAccessToken(userId)
            };
            return response;
        }

        /// <summary>
        /// This method is used for getting user access token
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private string GetUserAccessToken(int userId)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var secret = _config["JwtSettings:Secret"] ?? string.Empty;
            var key = Encoding.ASCII.GetBytes(secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                new Claim(ClaimTypes.NameIdentifier, userId.ToString())
                }),
                Expires = DateTime.UtcNow.AddMinutes(Convert.ToInt32(_config["JwtSettings:ExpirationInMinutes"])),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            //Generate Token
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        #endregion Private Methods
    }
}
